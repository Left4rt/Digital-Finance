# 上市公司官网产品页采集台

按「官网确认 → 页面发现 → 产品页识别 → 内容抽取 → 证据校验 → 增量更新」流水线实现，
带一个可视化控制台，支持随时中断、随时续跑。

## 一键启动（Windows）

不想敲命令的话，双击 `start.bat` 就行。它会自动检测 Python、装缺的依赖、
载入公司名单、启动服务并弹出浏览器。第一次运行会慢一点（要装依赖），
之后再双击就是秒开。

`start.bat` 本身只是个转发器，真正干活的是 `bootstrap.py`——所有中文提示
都从 Python 打印出来，不依赖 .bat 文件本身的编码，中文系统下不会花屏。
如果双击没反应，打开命令行手动跑一遍能看到具体报错：

```
cd 到这个文件夹
python bootstrap.py
```

## 快速开始（命令行）

```bash
pip install -r requirements.txt
playwright install chromium      # 需要渲染动态页时才装

python run.py init  --csv company_list.csv    # 建库并载入名单
python run.py serve --port 8000               # 打开 http://127.0.0.1:8000
```

控制台上按「开始采集」即可。也可以完全走命令行：

```bash
python run.py crawl --workers 4     # Ctrl+C 随时中断
python run.py crawl                 # 再次运行自动从断点继续
python run.py export                # 导出 Excel / CSV
python run.py status                # 查看进度与失败清单
python selftest.py                  # 离线自检，36 项
```

## 名单与官网域名

CSV 至少要有 `ts_code` 和 `name` 两列，GBK 或 UTF-8 都能读。
如果多一列 `website`（或 `domain`、`url`），程序直接用它，不再猜。

你上传的名单只有代码和简称，所以官网靠两条路径拿到：

1. `data/domain_map.csv` 人工对照表，格式 `ts_code,domain`，优先级最高；
2. 打开 `enable_domain_search` 后用搜索引擎猜候选域名。

无论哪条路径，域名都要过 `verify_domain`：访问首页，用公司全称、简称、ICP 备案号
交叉验证，给出 0 到 1 的置信度。低于 0.5 的会在控制台标出来，建议人工过一遍再跑。
72 家公司里银行券商类官网变动少，建议直接把对照表填满，比自动猜稳得多。

## 断点重连

两级状态都在 SQLite 里，进程被杀不丢进度。

- 公司级：`companies.status` 走 pending → running → done/failed，
  `claim_company` 用一条 UPDATE 原子领取，多线程不会抢到同一家；
- URL 级：`frontier` 表就是队列本身，`UNIQUE(ts_code,url_key)` 保证重复入队幂等；
- 重启时 `reclaim_running_urls` 把上次卡在 running 的 URL 退回 queued；
- 超过 `stale_task_minutes` 还在 running 的公司任务视为僵死，自动重新调度；
- 页面写入是 upsert，重跑同一页只更新不新增；
- 记录 ETag 与 Last-Modified，增量更新时命中 304 直接跳过。

失败的公司在控制台点「重试失败」即可重新入队，已抓过的页面不会重抓。

## 编码与字体

这部分在 `textguard.py`，专门处理中文站的三类坑。

**声明与实际不符。** 解码按 BOM、HTTP 头、meta、charset_normalizer、穷举的顺序取候选，
每个候选都打分再择优。打分看四件事：中文占比、mojibake 特征字符、ASCII 结构是否保住、
汉字是否落在高频字集合里。最后一条是关键：把 GBK 字节按 UTF-16 或 Big5 解码同样不报错，
但会得到一串生僻字，只有高频字比例能识破它。自检里有对应的用例。

**自定义字体反爬。** 检测正文中的私有区码位（U+E000 到 U+F8FF）和内嵌 base64 字体，
命中就把页面标 `font_obfuscated`，产品置信度压到 0.3 以下，控制台上用紫色标出。
程序不会去猜原文，`fetcher.screenshot_element` 留了截图接口，需要时接 OCR。

**全角、零宽、软换行。** 统一 NFKC 归一后再做哈希，避免同一页因空白差异去重失败。

## 产品页识别

规则评分只做粗筛，得分构成写进日志便于回看：

- URL、标题、导航锚文本命中产品词加分，标题权重高于正文；
- 新闻、公告、投资者关系、招聘等负向词扣分；
- JSON-LD 里有 `Product` 直接加 8 分；
- 参数表、产品卡片网格、「功能/特点/应用」文案骨架各有加分。

默认 8 分以上判定产品页，4 到 8 分留作复核，4 分以下丢弃。阈值在 `config.py` 里调。
页面再细分成业务板块页、产品分类页、产品详情页、附件四类，避免把「新能源业务」
当成产品名写进结果。

## 抽取顺序

JSON-LD → DOM 规则 → Trafilatura 正文 → 大模型。前面的拿到就不往下走。

大模型默认关闭，用 `--llm-key` 打开。它只读已清洗的正文，按固定 JSON Schema 输出，
提示词里明确禁止补充页面上没有的内容，并要求每条产品给出原文证据，
返回后还会校验证据能否在正文里找到，找不到就把置信度降到 0.4。

## 稳健性

- 每个域名独立限速和熔断，一个站挂掉不影响别人；
- 429 和 503 自动加倍退避并降速，不硬重试；403 直接记账放弃；
- lxml、trafilatura、PyMuPDF、tldextract 缺任何一个都有兜底路径，不会因为少装一个包跑不动；
- 浏览器渲染是按需降级，正文短于 `render_min_text_len` 才启用；
- 抓取前查 robots.txt，默认遵守。

## 目录

```
prodcrawler/
  config.py     参数与关键词词典
  storage.py    SQLite，断点续爬的全部状态
  textguard.py  编码识别、字体反爬、清洗、SimHash
  fetcher.py    HTTP、限速熔断、Playwright 降级
  discover.py   域名确认、sitemap、导航、限深 BFS
  scoring.py    URL 归一化、产品页评分与分类
  extract.py    JSON-LD、DOM、正文、PDF、大模型
  pipeline.py   调度与落库
  server.py     控制台接口
  static/index.html  控制台页面
run.py          命令行入口
selftest.py     离线自检
```

## 几点提醒

跑之前把 `user_agent` 里的联系邮箱换成你自己的。默认 4 并发、同域 1.5 秒间隔，
72 家公司大概两三个小时跑完一轮，不建议再调快。抽取结果建议按公司抽样复核，
控制台里每条产品都带来源 URL 和原文证据，复核成本不高。
