@echo off
setlocal
cd /d %~dp0
title Product Page Crawler

where python >nul 2>nul
if %errorlevel%==0 (
    python bootstrap.py
    goto :eof
)

where py >nul 2>nul
if %errorlevel%==0 (
    py bootstrap.py
    goto :eof
)

echo ================================================
echo   Python not found.
echo.
echo   If you use Anaconda, please open "Anaconda Prompt",
echo   cd into this folder, and run:  python bootstrap.py
echo.
echo   Otherwise install Python 3.9+ from python.org
echo   and make sure to check "Add python.exe to PATH".
echo ================================================
pause
