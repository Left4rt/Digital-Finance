#!/usr/bin/env python3
"""一键启动引导脚本。

被 start.bat 调用，也可以直接双击（如果系统把 .py 关联到了 python）或者
在命令行里 `python bootstrap.py` 手动跑。

所有面向用户的中文提示都从这里 print 出去——Python 在 Windows 控制台下
用的是系统原生的宽字符输出接口，不看 chcp、不依赖源文件编码，比在 .bat
文件里直接写中文靠谱得多，这也是本文件存在的原因。
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent


def say(msg: str) -> None:
    try:
        print(msg)
    except UnicodeEncodeError:
        # 极少数环境（比如输出被重定向到不支持宽字符的旧终端）会在这里栽跟头，
        # 兜底降级成不含中文的版本，保证脚本不会因为打印失败而崩掉。
        print(msg.encode("ascii", "replace").decode("ascii"))


def pause_and_exit(code: int) -> None:
    try:
        input("\n按回车键关闭窗口…")
    except Exception:
        pass
    sys.exit(code)


def check_python_version() -> None:
    if sys.version_info < (3, 9):
        say(f"[错误] 当前 Python 版本过低（{sys.version.split()[0]}），需要 3.9 及以上。")
        say("请到 https://www.python.org/downloads/ 安装新版本。")
        pause_and_exit(1)


def deps_ready() -> bool:
    try:
        import fastapi, uvicorn, httpx, lxml, trafilatura  # noqa: F401
        return True
    except ImportError:
        return False


def install_deps() -> bool:
    say("[2/4] 依赖不全，正在安装（第一次运行会慢一些，请耐心等待）…")
    req = HERE / "requirements.txt"
    ret = subprocess.call([sys.executable, "-m", "pip", "install", "-r", str(req)])
    if ret != 0:
        say("")
        say("[错误] 依赖安装失败，常见原因是网络问题。可以尝试国内镜像手动安装：")
        say(f'  "{sys.executable}" -m pip install -r requirements.txt '
            f'-i https://pypi.tuna.tsinghua.edu.cn/simple')
        return False
    say("      依赖安装完成")
    return True


def maybe_install_playwright_browser() -> None:
    try:
        import playwright  # noqa: F401
    except ImportError:
        return
    marker_dirs = [
        Path.home() / "AppData" / "Local" / "ms-playwright",
        Path.home() / ".cache" / "ms-playwright",
    ]
    if any(d.exists() for d in marker_dirs):
        return
    say("      首次使用需要下载浏览器渲染内核（约 100MB，用于抓取动态网页）…")
    ret = subprocess.call([sys.executable, "-m", "playwright", "install", "chromium"])
    if ret != 0:
        say("      [提示] 渲染内核下载失败，不影响普通抓取，只是遇到复杂动态网页时效果会差一些。")
        say(f'      之后想补装可以手动运行："{sys.executable}" -m playwright install chromium')


def init_company_list() -> None:
    say("[3/4] 检查公司名单…")
    db = HERE / "data" / "crawl.db"
    if db.exists():
        say("      已有数据库，跳过重新载入（如需重新载入，删掉 data/crawl.db 再运行本脚本）")
        return
    csv_path = HERE / "company_list.csv"
    if not csv_path.exists():
        say("      [提示] 当前目录下没有 company_list.csv。")
        say("      把你的公司名单文件放到这个文件夹并改名成 company_list.csv 再重新运行，")
        say("      或者先跳过，进入网页后在控制台里手动指定路径载入。")
        return
    say("      首次运行，正在载入 company_list.csv…")
    ret = subprocess.call([sys.executable, "run.py", "init", "--csv", "company_list.csv"])
    if ret != 0:
        say("      [提示] 名单载入失败，稍后可以在网页控制台里点“载入 CSV”重试。")


def start_server() -> None:
    say("[4/4] 启动控制台，几秒后会自动打开浏览器…")
    say("      如果没有自动打开，手动访问：http://127.0.0.1:8000")
    say("      要停止程序，直接关闭这个窗口，或按 Ctrl+C")
    say("=" * 50)
    say("")
    ret = subprocess.call([sys.executable, "run.py", "serve", "--port", "8000"])
    if ret != 0:
        say("")
        say("[提示] 服务异常退出，看看上面有没有具体报错信息。")
        say("常见原因：端口 8000 被占用，可以换个端口手动运行：")
        say(f'  "{sys.executable}" run.py serve --port 8001')


def main() -> None:
    say("=" * 50)
    say("  上市公司官网产品页采集台 - 一键启动")
    say("=" * 50)
    say("")
    check_python_version()
    say(f"[1/4] 使用 Python：{sys.version.split()[0]}（{sys.executable}）")
    say("")

    if deps_ready():
        say("[2/4] 依赖已就绪，跳过安装")
    else:
        if not install_deps():
            pause_and_exit(1)
    maybe_install_playwright_browser()
    say("")

    init_company_list()
    say("")

    start_server()
    pause_and_exit(0)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        say("\n已停止。")
        sys.exit(0)
    except Exception as e:  # 任何没预料到的异常也不要让窗口一闪而过
        say(f"\n[错误] 运行时出现未预期的问题：{type(e).__name__}: {e}")
        pause_and_exit(1)
