#!/usr/bin/env python3
"""命令行入口。

    python run.py init      --csv company_list.csv     # 建库并载入名单
    python run.py serve     --port 8000                # 打开可视化控制台
    python run.py crawl     --workers 4                # 无界面直接跑（可随时 Ctrl+C，下次接着跑）
    python run.py export                               # 导出 Excel / CSV
    python run.py status                               # 命令行看进度
"""
from __future__ import annotations

import argparse
import signal
import sys

from prodcrawler.config import Settings
from prodcrawler.pipeline import Pipeline


def build_settings(args) -> Settings:
    s = Settings.load(args.config)
    for key in ("csv_path", "db_path", "export_dir"):
        v = getattr(args, key, None)
        if v:
            setattr(s, key, v)
    if getattr(args, "workers", None):
        s.domain_workers = args.workers
    if getattr(args, "no_render", False):
        s.enable_playwright = False
    if getattr(args, "llm_key", None):
        s.llm_api_key = args.llm_key
        s.llm_enabled = True
    return s


def main() -> int:
    ap = argparse.ArgumentParser(description="上市公司官网产品页采集")
    ap.add_argument("command", choices=["init", "serve", "crawl", "export", "status"])
    ap.add_argument("--csv", dest="csv_path")
    ap.add_argument("--db", dest="db_path")
    ap.add_argument("--out", dest="export_dir")
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--workers", type=int)
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--no-render", action="store_true", help="关闭 Playwright 渲染")
    ap.add_argument("--no-browser", action="store_true", help="serve 时不自动打开浏览器")
    ap.add_argument("--llm-key", help="启用大模型结构化抽取")
    args = ap.parse_args()

    s = build_settings(args)

    if args.command == "serve":
        try:
            import uvicorn
            from prodcrawler.server import create_app
        except ImportError as e:
            print(f"缺少依赖：{e}")
            print("请先运行：pip install -r requirements.txt")
            return 1
        print("=" * 50)
        print(f"控制台启动中，请稍候…")
        print(f"启动后在浏览器打开：http://{args.host}:{args.port}")
        print("这个窗口会一直占用（服务在前台运行），按 Ctrl+C 停止")
        print("=" * 50)

        if not args.no_browser:
            import threading
            import time
            import webbrowser

            def _open_browser():
                time.sleep(1.5)
                host = "127.0.0.1" if args.host in ("0.0.0.0", "127.0.0.1") else args.host
                try:
                    webbrowser.open(f"http://{host}:{args.port}")
                except Exception:
                    pass
            threading.Thread(target=_open_browser, daemon=True).start()

        try:
            # log_level 用 info 而不是 warning，保证终端上能看到
            # "Uvicorn running on ..." 这行确认信息，否则容易被误认为卡住了
            uvicorn.run(create_app(s), host=args.host, port=args.port, log_level="info")
        except OSError as e:
            print(f"\n启动失败：{e}")
            if "10048" in str(e) or "Address already in use" in str(e):
                print(f"端口 {args.port} 已被占用，换个端口试试："
                      f"python run.py serve --port 8001")
            return 1
        return 0

    pipe = Pipeline(s)

    if args.command == "init":
        n = pipe.load_csv()
        print(f"已载入 {n} 家公司 → {s.db_path}")
        return 0

    if args.command == "crawl":
        if not pipe.store.one("SELECT 1 FROM companies LIMIT 1"):
            pipe.load_csv()

        def on_sig(*_):
            print("\n收到中断，正在保存进度并退出（下次运行会从断点继续）…")
            pipe.stop()
        signal.signal(signal.SIGINT, on_sig)
        signal.signal(signal.SIGTERM, on_sig)
        pipe.start(background=False)
        print_status(pipe)
        return 0

    if args.command == "export":
        for k, v in pipe.export().items():
            print(f"{k}: {v}")
        return 0

    print_status(pipe)
    return 0


def print_status(pipe: Pipeline) -> None:
    ov = pipe.store.overview()
    print("公司总数 :", ov["companies_total"])
    for k, v in sorted(ov["by_status"].items()):
        print(f"  {k:<10}{v}")
    print("已抓页面 :", ov["pages"])
    print("产品页   :", ov["product_pages"])
    print("产品条目 :", ov["products"])
    print("待抓 URL :", ov["queued_urls"])
    print("编码/字体待查:", ov["font_flagged"])
    bad = pipe.store.query(
        "SELECT ts_code,name,last_error FROM companies WHERE status IN ('failed','retry') LIMIT 20")
    if bad:
        print("\n需要人工处理：")
        for r in bad:
            print(f"  {r['ts_code']} {r['name']}  {r['last_error'] or ''}")


if __name__ == "__main__":
    sys.exit(main())
