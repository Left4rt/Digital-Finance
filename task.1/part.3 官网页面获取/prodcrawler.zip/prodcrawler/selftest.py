#!/usr/bin/env python3
"""离线自检：不联网，验证编码识别、字体反爬检测、URL 归一、评分、断点续爬。

    python selftest.py
"""
from __future__ import annotations

import tempfile
from pathlib import Path

from prodcrawler.textguard import (decode_html, inspect_fonts, clean_text,
                                   text_fingerprint, simhash, hamming)
from prodcrawler.scoring import (normalize_url, url_key, url_priority,
                                 registrable_domain, score_page, classify_page,
                                 is_crawlable, is_document)
from prodcrawler.extract import parse_page, parse_jsonld, products_from_jsonld
from prodcrawler.storage import Store

ok = fail = 0


def check(name, cond, extra=""):
    global ok, fail
    if cond:
        ok += 1
        print(f"  [通过] {name}")
    else:
        fail += 1
        print(f"  [失败] {name} {extra}")


print("\n[1] 编码识别")
gbk_html = '<html><head><meta charset="utf-8"><title>产品中心</title></head>' \
           '<body>本公司主要产品包括智能支付终端与数据库管理系统。</body></html>'
raw_gbk = gbk_html.encode("gb18030")          # 声明 utf-8 实际是 GBK 的经典坑
d = decode_html(raw_gbk, header_charset="utf-8")
check("错误声明的 GBK 页面能正确解码", "智能支付终端" in d.text, d.encoding)
check("乱码率判定正常", d.mojibake_ratio < 0.05, d.mojibake_ratio)

d2 = decode_html(gbk_html.encode("utf-8"), header_charset="gb2312")
check("错误声明的 UTF-8 页面能纠正", "数据库管理系统" in d2.text, d2.encoding)

d3 = decode_html("产品参数表".encode("utf-8-sig"))
check("BOM 头处理正确", d3.text.strip().startswith("产品"), d3.encoding)

d4 = decode_html("<p>產品規格</p>".encode("big5"))
check("繁体页面不崩", bool(d4.text), d4.encoding)

print("\n[2] 字体反爬检测")
font_html = ('<style>@font-face{font-family:pf;src:url(data:font/woff;base64,AAA)}</style>'
             '<div class="pf">价格 \ue001\ue002\ue003 元</div>')
fr = inspect_fonts(font_html, "价格 \ue001\ue002\ue003 元")
check("识别私有区字符伪装", fr.obfuscated and fr.pua_count == 3, fr.note)
normal = '<style>@font-face{font-family:x;src:url(/f.woff)}</style><div>产品参数 380V</div>'
fr2 = inspect_fonts(normal, "产品参数 380V")
check("常规网页字体不误报", not fr2.obfuscated, fr2.note)

print("\n[3] 文本清洗与去重")
check("全角半角归一", clean_text("产品Ａ１　参数") == "产品A1 参数", clean_text("产品Ａ１　参数"))
check("零宽字符清除", "\u200b" not in clean_text("产\u200b品"))
a = text_fingerprint("智能POS终端 X3 支持多种支付方式")
b = text_fingerprint("智能POS终端 X3  支持多种支付方式\n")
check("正文指纹跨空白一致", a == b)
s1 = simhash("智能支付终端X3支持刷卡扫码NFC等多种方式适用于零售门店")
s2 = simhash("智能支付终端X3支持刷卡扫码NFC等多种方式适用于零售商店")
check("SimHash 近似判重", hamming(s1, s2) <= 8, hamming(s1, s2))

print("\n[4] URL 处理")
check("相对路径补全", normalize_url("../product/1.html", "https://a.com/cn/news/") ==
      "https://a.com/cn/product/1.html", normalize_url("../product/1.html", "https://a.com/cn/news/"))
check("去跟踪参数", normalize_url("https://a.com/p?id=3&utm_source=x") == "https://a.com/p?id=3")
check("去重键忽略 www 与斜杠",
      url_key("https://www.a.com/product/") == url_key("http://a.com/product"))
check("可注册域名", registrable_domain("https://ir.abc.com.cn/x") == "abc.com.cn",
      registrable_domain("https://ir.abc.com.cn/x"))
check("产品链接优先级更高",
      url_priority("/product/list", "产品中心") > url_priority("/news/1", "新闻动态"))
check("静态资源被过滤", not is_crawlable("https://a.com/logo.png"))
check("PDF 识别为附件", is_document("https://a.com/产品手册.pdf"))

print("\n[5] 产品页评分")
detail_text = ("智能POS终端 X3\n产品特点：支持刷卡、扫码、NFC；\n"
               "技术参数：屏幕 5.5 英寸；重量 320g；\n应用场景：零售门店、餐饮、便利店。")
sc, hits = score_page("https://a.com/product/detail/12.html", "智能POS终端X3-产品中心",
                      ["智能POS终端 X3"], detail_text, [], "首页 > 产品中心 > 支付终端", 1, 2)
check("产品详情页得分达标", sc >= 8, sc)
check("类型判为详情页",
      classify_page("https://a.com/product/detail/12.html", "智能POS终端X3", detail_text, sc, 2) == "detail")

news_text = "公司于近日召开董事会会议，审议通过相关议案，具体内容详见公告。"
sc2, _ = score_page("https://a.com/news/2024/01.html", "公司新闻-投资者关系",
                    ["公司新闻"], news_text, [])
check("新闻页被排除", sc2 < 4, sc2)

print("\n[6] JSON-LD 抽取")
ld = '''<script type="application/ld+json">
{"@context":"https://schema.org","@type":"Product","name":"数据库管理系统 V8",
 "description":"面向金融核心系统的关系型数据库","category":"基础软件",
 "additionalProperty":[{"@type":"PropertyValue","name":"并发","value":"10万TPS"}]}
</script><title>产品详情</title><body>数据库管理系统 V8</body>'''
types, prods = parse_jsonld(ld)
check("JSON-LD 类型解析", "Product" in types, types)
pc = parse_page(ld, "https://a.com/p/1")
plist = products_from_jsonld(pc)
check("JSON-LD 产品字段抽取",
      plist and plist[0].product_name == "数据库管理系统 V8"
      and plist[0].specifications.get("并发") == "10万TPS",
      plist)

print("\n[7] 断点续爬")
with tempfile.TemporaryDirectory() as td:
    db = str(Path(td) / "t.db")
    st = Store(db)
    st.upsert_company("000001.SZ", "测试公司")
    row = st.claim_company(30)
    check("公司任务可领取", row is not None and row["ts_code"] == "000001.SZ")
    check("同一任务不会被重复领取", st.claim_company(30) is None)

    st.push_urls("000001.SZ", [
        {"url": "https://a.com/product", "url_key": "a.com/product", "priority": 5},
        {"url": "https://a.com/news", "url_key": "a.com/news", "priority": -3},
    ])
    n_dup = st.push_urls("000001.SZ", [
        {"url": "https://a.com/product", "url_key": "a.com/product", "priority": 5}])
    check("URL 入队幂等", n_dup == 0, n_dup)
    batch = st.claim_urls("000001.SZ", 1)
    check("高优先级先出队", batch[0]["url"].endswith("/product"), batch[0]["url"])

    # 模拟进程被杀：running 的 URL 应被回收
    # 注意：光 del 对象在 CPython 上多数时候能触发 __del__/GC 顺带关闭文件描述符，
    # 但这依赖引用计数时机，在 Windows 上 sqlite3 的文件锁释放尤其不可靠，
    # 必须显式 close()，否则后面 tempfile 清理目录时会报"文件被占用"。
    st.close()
    st2 = Store(db)
    check("重启后 running URL 回收", st2.reclaim_running_urls() == 1)
    check("回收后可再次取到", len(st2.claim_urls("000001.SZ", 5)) == 2)

    st2.write("UPDATE companies SET status='running', claimed_at=0")
    check("僵死公司任务被重新调度", st2.claim_company(30) is not None)

    st2.save_page({"ts_code": "000001.SZ", "url": "https://a.com/product",
                   "url_key": "a.com/product", "page_title": "产品中心",
                   "page_type": "category", "score": 9.0, "text_len": 500,
                   "crawled_at": 0})
    st2.save_page({"ts_code": "000001.SZ", "url": "https://a.com/product",
                   "url_key": "a.com/product", "page_title": "产品中心(更新)",
                   "page_type": "category", "score": 10.0, "text_len": 600,
                   "crawled_at": 1})
    check("同一页面重复写入为更新而非新增", st2.pages_done("000001.SZ") == 1)
    ov = st2.overview()
    check("概览统计可用", ov["pages"] == 1 and ov["companies_total"] == 1, ov)
    st2.close()

print("\n[8] CSV 载入（GBK 名单）")
with tempfile.TemporaryDirectory() as td:
    csv_p = Path(td) / "c.csv"
    csv_p.write_bytes("ts_code,name\r\n002657.SZ,中科金财\r\n300561.SZ,汇金科技\r\n".encode("gbk"))
    from prodcrawler.config import Settings
    from prodcrawler.pipeline import Pipeline
    s = Settings()
    s.db_path = str(Path(td) / "d.db")
    s.export_dir = str(Path(td) / "out")
    s.domain_hint_file = str(Path(td) / "map.csv")
    Path(s.domain_hint_file).write_bytes("ts_code,domain\n002657.SZ,zkjc.com\n".encode("utf-8"))
    p = Pipeline(s)
    n = p.load_csv(str(csv_p))
    check("GBK 名单正确载入", n == 2)
    r = p.store.one("SELECT * FROM companies WHERE ts_code='002657.SZ'")
    check("公司名未乱码", r["name"] == "中科金财", r["name"])
    check("域名对照表生效", r["domain"] == "zkjc.com" and r["domain_source"] == "hint", dict(r))
    n2 = p.load_csv(str(csv_p))
    check("重复载入不产生重复公司", n2 == 2 and p.store.one("SELECT COUNT(*) n FROM companies")["n"] == 2)
    p.store.close()

print(f"\n结果：通过 {ok} 项，失败 {fail} 项")
raise SystemExit(1 if fail else 0)
