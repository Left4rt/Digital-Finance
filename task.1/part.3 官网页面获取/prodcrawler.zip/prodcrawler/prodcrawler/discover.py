"""页面发现：官网域名确认 → sitemap → 首页导航 → 限深度站内爬取。"""
from __future__ import annotations

import csv
import re
from pathlib import Path
from urllib.parse import urlparse

from .config import Settings
from .fetcher import Fetcher
from .scoring import (normalize_url, url_key, url_priority, registrable_domain,
                      same_site, is_crawlable, is_document)
from .textguard import decode_html

NAV_HINTS = ("产品", "解决方案", "业务", "服务", "方案", "product", "solution",
             "business", "service")


# ------------------------------------------------------------------ 域名
def load_domain_hints(path: str) -> dict[str, str]:
    """人工维护的 ts_code,domain 对照表。优先级最高，是纠错的主要手段。"""
    hints: dict[str, str] = {}
    p = Path(path)
    if not p.exists():
        return hints
    raw = p.read_bytes()
    text = decode_html(raw).text
    for row in csv.DictReader(text.splitlines()):
        code = (row.get("ts_code") or "").strip()
        dom = (row.get("domain") or row.get("website") or row.get("url") or "").strip()
        if code and dom:
            hints[code] = dom
    return hints


def verify_domain(fetcher: Fetcher, domain: str, company_name: str) -> tuple[str, float, str]:
    """访问候选域名首页，用公司名/简称匹配确认是不是官网。

    返回 (可用的 base_url, 置信度, 说明)。置信度低的留给人工复核，不直接丢弃。
    """
    if not domain:
        return "", 0.0, "empty"
    base = domain if domain.startswith("http") else f"https://{domain}"
    tried: list[str] = []
    for candidate in (base, base.replace("https://", "http://")):
        tried.append(candidate)
        r = fetcher.fetch(candidate)
        if not r.ok or not r.text:
            continue
        title = extract_title(r.text)
        body = r.text[:60000]
        conf = 0.35
        core = re.sub(r"(股份有限公司|有限公司|集团|股份|公司|ST|\*)", "", company_name).strip()
        if company_name and company_name in body:
            conf += 0.35
        if core and len(core) >= 2 and core in title:
            conf += 0.25
        elif core and len(core) >= 2 and core in body:
            conf += 0.15
        if re.search(r"(ICP备|京ICP|沪ICP|粤ICP|公网安备)", body):
            conf += 0.1
        if re.search(r"(投资者关系|证券代码|股票代码)", body):
            conf += 0.05
        return normalize_url(r.final_url or candidate), round(min(conf, 0.99), 2), title
    return "", 0.0, f"unreachable:{','.join(tried)}"


def search_official_site(fetcher: Fetcher, company_name: str, settings: Settings) -> list[str]:
    """可选：用搜索引擎猜官网。默认关闭，结果必须再经 verify_domain 确认。"""
    if not settings.enable_domain_search:
        return []
    from urllib.parse import quote
    url = settings.search_endpoint.format(q=quote(f"{company_name} 官网"))
    r = fetcher.fetch(url)
    if not r.ok:
        return []
    hrefs = re.findall(r'href="(https?://[^"]+)"', r.text)
    out, seen = [], set()
    bad = ("bing.com", "baidu.com", "google.", "microsoft.com", "zhihu.com",
           "sina.com", "eastmoney.com", "10jqka", "sohu.com", "163.com",
           "wikipedia", "qcc.com", "tianyancha")
    for h in hrefs:
        d = registrable_domain(h)
        if not d or d in seen or any(b in d for b in bad):
            continue
        seen.add(d)
        out.append(d)
        if len(out) >= 6:
            break
    return out


# ------------------------------------------------------------------ 解析
def extract_title(html_text: str) -> str:
    m = re.search(r"(?is)<title[^>]*>(.*?)</title>", html_text or "")
    return re.sub(r"\s+", " ", m.group(1)).strip()[:200] if m else ""


def extract_links(html_text: str, base_url: str) -> list[tuple[str, str]]:
    """返回 [(绝对url, 锚文本)]。优先用 lxml，失败退回正则，保证不会因解析崩掉。"""
    out: list[tuple[str, str]] = []
    try:
        from lxml import html as lhtml
        doc = lhtml.fromstring(html_text)
        for a in doc.xpath("//a[@href]"):
            href = (a.get("href") or "").strip()
            anchor = re.sub(r"\s+", " ", (a.text_content() or "")).strip()[:120]
            u = normalize_url(href, base_url)
            if u:
                out.append((u, anchor))
        return out
    except Exception:
        pass
    for m in re.finditer(r'(?is)<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', html_text or ""):
        u = normalize_url(m.group(1), base_url)
        if u:
            anchor = re.sub(r"<[^>]+>", "", m.group(2))
            out.append((u, re.sub(r"\s+", " ", anchor).strip()[:120]))
    return out


# ------------------------------------------------------------------ sitemap
def parse_sitemap(fetcher: Fetcher, sm_url: str, depth: int = 0,
                  limit: int = 3000) -> list[dict]:
    """递归解析 sitemap / sitemap index，返回 [{url, lastmod}]。"""
    if depth > 2:
        return []
    r = fetcher.fetch(sm_url)
    if not r.ok:
        return []
    body = r.text
    if not body and r.content[:2] == b"\x1f\x8b":       # .xml.gz
        import gzip
        try:
            body = decode_html(gzip.decompress(r.content)).text
        except Exception:
            return []
    if not body:
        return []

    # sitemap.txt：一行一个 URL
    if sm_url.endswith(".txt") or ("<urlset" not in body and "<sitemapindex" not in body):
        urls = [{"url": normalize_url(l.strip()), "lastmod": ""}
                for l in body.splitlines() if l.strip().startswith("http")]
        return [u for u in urls if u["url"]][:limit]

    out: list[dict] = []
    if "<sitemapindex" in body:
        for loc in re.findall(r"(?is)<sitemap>.*?<loc>(.*?)</loc>", body)[:50]:
            out.extend(parse_sitemap(fetcher, normalize_url(loc.strip()), depth + 1, limit))
            if len(out) >= limit:
                break
        return out[:limit]

    for block in re.findall(r"(?is)<url>(.*?)</url>", body):
        loc = re.search(r"(?is)<loc>(.*?)</loc>", block)
        if not loc:
            continue
        u = normalize_url(loc.group(1).strip())
        if not u:
            continue
        lm = re.search(r"(?is)<lastmod>(.*?)</lastmod>", block)
        out.append({"url": u, "lastmod": lm.group(1).strip() if lm else ""})
        if len(out) >= limit:
            break
    return out


def seed_urls(fetcher: Fetcher, base_url: str, settings: Settings) -> list[dict]:
    """产出初始队列：sitemap 命中的产品相关 URL + 首页导航里的产品入口。"""
    root = registrable_domain(base_url)
    p = urlparse(base_url)
    origin = f"{p.scheme}://{p.netloc}"
    seeds: dict[str, dict] = {}

    def add(u: str, *, depth: int, source: str, anchor: str = "", bonus: int = 0):
        u = normalize_url(u, base_url)
        if not u or not same_site(u, root) or not is_crawlable(u):
            return
        k = url_key(u)
        if not k or k in seeds:
            return
        seeds[k] = {"url": u, "url_key": k, "depth": depth, "source": source,
                    "anchor": anchor, "priority": url_priority(u, anchor) + bonus}

    add(base_url, depth=0, source="home", bonus=5)

    # 1) sitemap
    sm_candidates = fetcher.sitemaps_from_robots(origin) or []
    sm_candidates += [f"{origin}/sitemap.xml", f"{origin}/sitemap_index.xml",
                      f"{origin}/sitemap.txt", f"{origin}/sitemap/sitemap.xml"]
    seen_sm = set()
    for sm in sm_candidates:
        if not sm or sm in seen_sm:
            continue
        seen_sm.add(sm)
        for item in parse_sitemap(fetcher, sm, limit=settings.sitemap_url_limit):
            pr = url_priority(item["url"])
            if pr > 0 or len(seeds) < 60:
                add(item["url"], depth=1, source="sitemap", bonus=max(pr, 0))
        if len(seeds) > 400:
            break

    # 2) 首页导航
    home = fetcher.fetch(base_url, allow_render=True)
    if home.ok and home.text:
        for u, anchor in extract_links(home.text, home.final_url or base_url):
            if not same_site(u, root):
                continue
            hit = any(h in anchor.lower() or h in u.lower() for h in NAV_HINTS)
            add(u, depth=1, source="nav" if hit else "link", anchor=anchor,
                bonus=6 if hit else 0)
    return sorted(seeds.values(), key=lambda x: -x["priority"])


def expand_links(html_text: str, current_url: str, root_domain: str,
                 depth: int, settings: Settings) -> list[dict]:
    """从已抓页面里扩展下一层链接。"""
    if depth >= settings.max_depth:
        return []
    out: dict[str, dict] = {}
    for u, anchor in extract_links(html_text, current_url):
        if not same_site(u, root_domain):
            continue
        if is_document(u):
            if not settings.enable_pdf:
                continue
            pr = url_priority(u, anchor) + 3
            src = "doc"
        elif not is_crawlable(u):
            continue
        else:
            pr = url_priority(u, anchor)
            src = "link"
        # 深层页面只放产品相关的进来，避免把整站新闻拖下来
        if depth >= 2 and pr <= 0:
            continue
        k = url_key(u)
        if k and k not in out:
            out[k] = {"url": u, "url_key": k, "depth": depth + 1,
                      "source": src, "anchor": anchor, "priority": pr}
    return list(out.values())
