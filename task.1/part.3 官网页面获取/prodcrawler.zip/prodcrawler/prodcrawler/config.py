"""全局配置。所有可调参数集中在这里，避免散落在各模块。"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path


# ---------------------------------------------------------------- 关键词词典
# 正向：出现在 URL / 标题 / 导航锚文本 / 正文中，提升产品页得分
POSITIVE_KEYWORDS: dict[str, int] = {
    "产品中心": 5, "产品介绍": 5, "产品与服务": 5, "产品详情": 5, "产品列表": 4,
    "我们的产品": 4, "核心产品": 4, "产品体系": 4, "产品矩阵": 4,
    "解决方案": 3, "行业方案": 3, "业务介绍": 2, "主营业务": 2, "业务板块": 2,
    "技术参数": 4, "规格参数": 4, "产品特点": 4, "功能特性": 3, "应用场景": 3,
    "适用范围": 2, "型号": 2, "系列产品": 3,
    "/product": 4, "/products": 4, "/solution": 3, "/solutions": 3,
    "/pro/": 2, "/cp/": 2, "/chanpin": 4, "/business": 1, "/service": 1,
    "product center": 4, "our products": 4, "solutions": 2, "specifications": 3,
}

# 负向：新闻、公告、投关等非产品页
NEGATIVE_KEYWORDS: dict[str, int] = {
    "新闻中心": -4, "新闻动态": -4, "公司新闻": -4, "媒体报道": -3, "行业资讯": -3,
    "投资者关系": -6, "投资者": -4, "临时公告": -6, "定期报告": -6, "股票行情": -5,
    "社会责任": -4, "党建": -4, "招聘": -4, "人才招聘": -5, "加入我们": -4,
    "联系我们": -3, "公司简介": -3, "关于我们": -3, "发展历程": -3, "企业文化": -3,
    "领导致辞": -4, "组织架构": -3, "友情链接": -2, "网站地图": -2, "隐私政策": -3,
    "法律声明": -3, "登录": -3, "注册": -3, "下载中心": -1,
    "/news": -4, "/investor": -6, "/ir/": -5, "/about": -3, "/contact": -3,
    "/job": -4, "/career": -4, "/recruit": -4, "/login": -4, "/search": -3,
}

# 站内爬取时直接丢弃的 URL 片段
URL_BLOCKLIST: tuple[str, ...] = (
    "javascript:", "mailto:", "tel:", "#",
    "/login", "/logout", "/register", "/search", "/share", "/print",
    "wp-login", "/comment", "/tag/", "/author/", "utm_source=",
    "sina.com", "weibo.com", "qq.com/", "beian.miit", "baidu.com",
)

# 认为是"可下载产品资料"的扩展名
DOC_EXTENSIONS: tuple[str, ...] = (".pdf", ".doc", ".docx", ".ppt", ".pptx")

# 直接跳过的静态资源扩展名
SKIP_EXTENSIONS: tuple[str, ...] = (
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".svg", ".ico",
    ".css", ".js", ".zip", ".rar", ".7z", ".exe", ".apk", ".mp4", ".mp3",
    ".xls", ".xlsx", ".txt", ".xml.gz",
)


@dataclass
class Settings:
    # 输入输出
    csv_path: str = "company_list.csv"
    csv_encoding: str = "auto"          # auto 时按 GB18030 / UTF-8 依次尝试
    db_path: str = "data/crawl.db"
    export_dir: str = "data/export"

    # 网络
    user_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 "
        "ProductPageBot/1.0 (+research use; contact: you@example.com)"
    )
    timeout: float = 20.0
    max_retries: int = 3
    retry_backoff: float = 2.0          # 秒，指数退避基数
    per_domain_delay: float = 1.5       # 同域名请求最小间隔
    respect_robots: bool = True
    verify_ssl: bool = False            # 大量国内官网证书链不全，默认关闭校验

    # 并发
    domain_workers: int = 4             # 同时处理几家公司
    page_concurrency: int = 3           # 单家公司内并发页数

    # 爬取边界
    max_depth: int = 3
    max_pages_per_site: int = 220
    max_product_pages: int = 60         # 单公司保留的产品页上限
    sitemap_url_limit: int = 3000

    # 打分阈值
    score_accept: int = 8               # >= 判定产品页
    score_review: int = 4               # [review, accept) 进人工/模型复核

    # 渲染降级
    enable_playwright: bool = True
    render_min_text_len: int = 300      # 正文短于此值触发浏览器渲染
    render_timeout: float = 25.0

    # 附件
    enable_pdf: bool = True
    max_pdf_bytes: int = 20 * 1024 * 1024

    # 字体 / 编码
    enable_font_guard: bool = True
    enable_ocr: bool = False            # 需要额外安装 paddleocr 或 tesseract

    # 大模型结构化抽取（可选，不配置则只落规则抽取结果）
    llm_enabled: bool = False
    llm_base_url: str = "https://api.anthropic.com/v1/messages"
    llm_model: str = "claude-sonnet-4-6"
    llm_api_key: str = ""
    llm_max_chars: int = 12000

    # 断点续爬
    resume: bool = True
    stale_task_minutes: int = 30        # running 状态超过该时长视为僵死，重新入队

    # 域名解析（CSV 无官网列时）
    domain_hint_file: str = "data/domain_map.csv"   # ts_code,domain 人工维护/复核
    enable_domain_search: bool = False              # 打开后用搜索引擎猜官网
    search_endpoint: str = "https://www.bing.com/search?q={q}"

    keywords_positive: dict = field(default_factory=lambda: dict(POSITIVE_KEYWORDS))
    keywords_negative: dict = field(default_factory=lambda: dict(NEGATIVE_KEYWORDS))

    @classmethod
    def load(cls, path: str | None = None) -> "Settings":
        s = cls()
        if path and Path(path).exists():
            raw = json.loads(Path(path).read_text(encoding="utf-8"))
            for k, v in raw.items():
                if hasattr(s, k):
                    setattr(s, k, v)
        return s

    def dump(self, path: str) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(
            json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding="utf-8"
        )
