"""主流水线。

调度模型：公司级任务 + 公司内 URL 前沿队列，两级状态都落在 SQLite。
任意时刻杀进程，重启后 running 状态会被回收重入队，已完成的页面不会重抓。
"""
from __future__ import annotations

import csv
import hashlib
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .config import Settings
from .discover import (load_domain_hints, verify_domain, search_official_site,
                       seed_urls, expand_links)
from .extract import (parse_page, products_from_jsonld, products_from_dom,
                      llm_extract, extract_pdf, dedup_key, Product, PageContent)
from .fetcher import Fetcher
from .scoring import (normalize_url, url_key, registrable_domain, score_page,
                      classify_page, is_document)
from .storage import Store
from .textguard import decode_html, clean_text, text_fingerprint


class Pipeline:
    def __init__(self, settings: Settings):
        self.s = settings
        self.store = Store(settings.db_path)
        self.fetcher = Fetcher(settings, logger=self._log)
        self.stop_flag = threading.Event()
        self.pause_flag = threading.Event()
        self._running = False
        self._thread: threading.Thread | None = None
        self.text_dir = Path(self.s.export_dir) / "pages"
        self.text_dir.mkdir(parents=True, exist_ok=True)

    # ---------------------------------------------------------------- 日志
    def _log(self, message: str, level: str = "info", ts_code: str = None, **payload):
        self.store.log(level, message, ts_code, payload or None)

    # ---------------------------------------------------------------- 载入
    def load_csv(self, path: str | None = None) -> int:
        """读取本地 CSV。自动处理 GBK/UTF-8，可选列 website/domain/url。"""
        path = path or self.s.csv_path
        raw = Path(path).read_bytes()
        if self.s.csv_encoding == "auto":
            text = decode_html(raw).text
        else:
            text = raw.decode(self.s.csv_encoding, errors="replace")
        text = text.lstrip("\ufeff")
        hints = load_domain_hints(self.s.domain_hint_file)

        n = 0
        for row in csv.DictReader(text.splitlines()):
            row = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
            code = row.get("ts_code") or row.get("code") or row.get("股票代码")
            name = row.get("name") or row.get("公司名称") or row.get("简称")
            if not code or not name:
                continue
            dom = (row.get("website") or row.get("domain") or row.get("url")
                   or hints.get(code, ""))
            src = "csv" if (row.get("website") or row.get("domain") or row.get("url")) else (
                "hint" if hints.get(code) else None)
            self.store.upsert_company(code, name, dom or None, src)
            n += 1
        self._log(f"已载入 {n} 家公司", "info")
        return n

    # ---------------------------------------------------------------- 运行
    def start(self, background: bool = True) -> None:
        if self._running:
            return
        self.stop_flag.clear()
        self.pause_flag.clear()
        self._running = True
        self.store.set_meta("run_started_at", str(time.time()))
        if background:
            self._thread = threading.Thread(target=self._run_all, daemon=True)
            self._thread.start()
        else:
            self._run_all()

    def stop(self) -> None:
        self.stop_flag.set()

    def pause(self) -> None:
        self.pause_flag.set()

    def resume(self) -> None:
        self.pause_flag.clear()

    @property
    def running(self) -> bool:
        return self._running

    def _run_all(self) -> None:
        try:
            reclaimed = self.store.reclaim_running_urls()
            if reclaimed:
                self._log(f"断点恢复：{reclaimed} 条 URL 重新入队", "warn")
            with ThreadPoolExecutor(max_workers=self.s.domain_workers) as pool:
                futures = [pool.submit(self._worker, i) for i in range(self.s.domain_workers)]
                for f in futures:
                    f.result()
        except Exception as e:
            self._log(f"调度器异常：{type(e).__name__}: {e}", "error")
        finally:
            self._running = False
            self.fetcher.close()
            self._log("本轮运行结束", "info")

    def _worker(self, wid: int) -> None:
        while not self.stop_flag.is_set():
            while self.pause_flag.is_set() and not self.stop_flag.is_set():
                time.sleep(0.5)
            row = self.store.claim_company(self.s.stale_task_minutes)
            if row is None:
                return
            code, name = row["ts_code"], row["name"]
            try:
                self.process_company(code, name, row["domain"])
            except Exception as e:
                self.store.set_company(code, status="retry", last_error=f"{type(e).__name__}: {e}"[:300])
                self._log(f"{name} 处理异常：{type(e).__name__}: {e}", "error", code)

    # ---------------------------------------------------------------- 单公司
    def process_company(self, code: str, name: str, domain: str | None) -> None:
        self.store.set_company(code, stage="resolving")
        base_url, conf = self._resolve_site(code, name, domain)
        if not base_url:
            self.store.set_company(code, status="failed", stage="no_domain",
                                   last_error="未能确认官网域名", finished_at=time.time())
            self._log(f"{name} 未能确认官网，请在 domain_map.csv 中补录", "warn", code)
            return

        root = registrable_domain(base_url)
        self.store.set_company(code, domain=base_url, domain_confidence=conf,
                               stage="discovering")

        # 种子只在第一次生成；续跑时队列已在库里
        counts = self.store.frontier_counts(code)
        if not counts:
            seeds = seed_urls(self.fetcher, base_url, self.s)
            self.store.push_urls(code, seeds)
            self._log(f"{name} 发现种子 URL {len(seeds)} 条", "info", code,
                      domain=base_url, confidence=conf)

        self.store.set_company(code, stage="crawling")
        pages_done = self.store.pages_done(code)
        while not self.stop_flag.is_set() and pages_done < self.s.max_pages_per_site:
            while self.pause_flag.is_set() and not self.stop_flag.is_set():
                time.sleep(0.5)
            batch = self.store.claim_urls(code, self.s.page_concurrency)
            if not batch:
                break
            with ThreadPoolExecutor(max_workers=self.s.page_concurrency) as pool:
                list(pool.map(lambda r: self._process_url(code, name, root, r), batch))
            pages_done = self.store.pages_done(code)
            self.store.set_company(code, pages_seen=pages_done)

        stats = self.store.one(
            """SELECT COUNT(*) pages,
                      SUM(CASE WHEN page_type IN ('detail','category') THEN 1 ELSE 0 END) pp
               FROM pages WHERE ts_code=?""", (code,))
        prod = self.store.one("SELECT COUNT(*) n FROM products WHERE ts_code=?", (code,))
        self.store.set_company(
            code, status="done", stage="finished", finished_at=time.time(),
            pages_seen=stats["pages"] or 0, product_pages=stats["pp"] or 0,
            products=prod["n"] or 0,
        )
        self._log(f"{name} 完成：页面 {stats['pages']}，产品页 {stats['pp'] or 0}，"
                  f"产品 {prod['n']}", "success", code)

    def _resolve_site(self, code: str, name: str, domain: str | None) -> tuple[str, float]:
        candidates: list[str] = []
        if domain:
            candidates.append(domain)
        if not candidates and self.s.enable_domain_search:
            candidates += search_official_site(self.fetcher, name, self.s)
        best, best_conf = "", 0.0
        for cand in candidates[:6]:
            url, conf, note = verify_domain(self.fetcher, cand, name)
            if url and conf > best_conf:
                best, best_conf = url, conf
            if best_conf >= 0.7:
                break
        return best, best_conf

    # ---------------------------------------------------------------- 单页面
    def _process_url(self, code: str, name: str, root: str, row) -> None:
        fid, url, depth = row["id"], row["url"], row["depth"]
        prev = self.store.page_seen(code, row["url_key"])
        etag = prev["etag"] if prev else ""
        lm = prev["last_modified"] if prev else ""

        try:
            res = self.fetcher.fetch(url, etag=etag, last_modified=lm,
                                     allow_render=(depth <= 2))
        except Exception as e:
            self.store.requeue_url(fid, f"{type(e).__name__}: {e}")
            return

        if res.error == "not_modified":
            self.store.finish_url(fid, "done")
            return
        if not res.ok:
            if res.error in ("robots_disallow", "domain_circuit_open", "forbidden"):
                self.store.finish_url(fid, "skipped", res.error)
            else:
                self.store.requeue_url(fid, res.error)
            return

        try:
            if res.is_pdf or is_document(url):
                self._handle_document(code, name, url, res)
            else:
                self._handle_html(code, name, root, url, depth, res)
            self.store.finish_url(fid, "done")
        except Exception as e:
            self.store.finish_url(fid, "failed", f"{type(e).__name__}: {e}")
            self._log(f"{name} 解析失败 {url}：{type(e).__name__}: {e}", "error", code)

    def _handle_html(self, code: str, name: str, root: str, url: str,
                     depth: int, res) -> None:
        pc: PageContent = parse_page(res.text, res.final_url or url)
        score, hits = score_page(
            res.final_url or url, pc.title, pc.headings, pc.text,
            pc.jsonld_types, pc.breadcrumb, len(pc.tables), pc.card_count)
        page_type = classify_page(url, pc.title, pc.text, score,
                                  pc.card_count, pc.jsonld_types)

        text_path = ""
        if score >= self.s.score_review and pc.text:
            text_path = self._dump_text(code, url, pc.text)

        canonical = self._canonical(res.text, res.final_url or url)
        self.store.save_page({
            "ts_code": code, "url": url, "final_url": res.final_url or url,
            "url_key": url_key(url), "canonical": canonical,
            "page_title": pc.title, "page_type": page_type,
            "crawl_method": res.method, "http_status": res.status,
            "encoding": res.encoding, "encoding_source": res.encoding_source,
            "mojibake_ratio": round(res.mojibake_ratio, 4),
            "font_obfuscated": int(pc.font_obfuscated), "font_note": pc.font_note,
            "score": score, "confidence": min(max(score / 16, 0), 1),
            "text_len": len(pc.text), "content_hash": text_fingerprint(pc.text),
            "etag": res.etag, "last_modified": res.last_modified,
            "text_path": text_path, "crawled_at": time.time(),
        })

        if pc.font_obfuscated:
            self._log(f"{name} 页面疑似字体反爬：{url}（{pc.font_note}）", "warn", code)
        if res.mojibake_ratio > 0.05:
            self._log(f"{name} 页面编码可疑（{res.encoding}，乱码率 "
                      f"{res.mojibake_ratio:.0%}）：{url}", "warn", code)

        # 扩展链接
        new_links = expand_links(res.text, res.final_url or url, root, depth, self.s)
        if new_links:
            self.store.push_urls(code, new_links)

        # 达标才抽取产品
        if score >= self.s.score_accept and page_type in ("detail", "category"):
            self._extract_products(code, name, url, pc, page_type, score, hits)

    def _handle_document(self, code: str, name: str, url: str, res) -> None:
        if not self.s.enable_pdf or len(res.content) > self.s.max_pdf_bytes:
            return
        text = extract_pdf(res.content)
        scanned = len(text) < 100
        self.store.save_page({
            "ts_code": code, "url": url, "final_url": res.final_url or url,
            "url_key": url_key(url), "page_title": Path(url).name,
            "page_type": "doc", "crawl_method": "pdf", "http_status": res.status,
            "encoding": "pdf", "encoding_source": "pdf",
            "mojibake_ratio": 0.0, "font_obfuscated": int(scanned),
            "font_note": "疑似扫描版 PDF，需 OCR" if scanned else "",
            "score": 6.0, "confidence": 0.5, "text_len": len(text),
            "content_hash": text_fingerprint(text), "etag": res.etag,
            "last_modified": res.last_modified,
            "text_path": self._dump_text(code, url, text) if text else "",
            "crawled_at": time.time(),
        })
        if scanned:
            self._log(f"{name} 附件可能是扫描件，未取到文字：{url}", "warn", code)

    def _extract_products(self, code: str, name: str, url: str, pc: PageContent,
                          page_type: str, score: float, hits: dict) -> None:
        products: list[Product] = products_from_jsonld(pc)
        if not products:
            products = products_from_dom(pc, page_type)
        if self.s.llm_enabled and page_type == "detail":
            llm = llm_extract(self.s, name, url, pc.title, pc.text)
            if llm:
                products = llm

        saved = 0
        for p in products:
            if not (p.product_name or p.product_category):
                continue
            if pc.font_obfuscated:
                p.confidence = min(p.confidence, 0.3)
            row = p.as_row()
            row.update({
                "ts_code": code, "company_name": name, "source_url": url,
                "dedup_key": dedup_key(code, p), "created_at": time.time(),
            })
            if self.store.save_product(row):
                saved += 1
        if saved:
            self.store.bump_company(code, "products", saved)
            self._log(f"{name} 抽到 {saved} 条产品（score={score}）：{url}",
                      "success", code, hits=list(hits)[:8])

    # ---------------------------------------------------------------- 工具
    @staticmethod
    def _canonical(html_text: str, base: str) -> str:
        import re
        m = re.search(r'(?is)<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']+)',
                      html_text or "")
        return normalize_url(m.group(1), base) if m else ""

    def _dump_text(self, code: str, url: str, text: str) -> str:
        h = hashlib.md5(url.encode()).hexdigest()[:12]
        d = self.text_dir / code
        d.mkdir(parents=True, exist_ok=True)
        p = d / f"{h}.txt"
        p.write_text(f"{url}\n{'-' * 60}\n{clean_text(text)}", encoding="utf-8")
        return str(p)

    # ---------------------------------------------------------------- 导出
    def export(self) -> dict:
        out = Path(self.s.export_dir)
        out.mkdir(parents=True, exist_ok=True)
        pages = self.store.query(
            """SELECT ts_code, url, final_url, page_title, page_type, crawl_method,
                      http_status, encoding, mojibake_ratio, font_obfuscated,
                      score, confidence, text_len, crawled_at
               FROM pages ORDER BY ts_code, score DESC""")
        products = self.store.query(
            """SELECT ts_code, company_name, product_name, business_segment,
                      product_category, product_summary, core_features,
                      application_scenarios, specifications, source_url,
                      evidence_text, extraction_method, confidence
               FROM products ORDER BY ts_code, confidence DESC""")
        paths = {}
        try:
            import pandas as pd
            xlsx = out / "product_pages.xlsx"
            with pd.ExcelWriter(xlsx, engine="openpyxl") as w:
                pd.DataFrame([dict(r) for r in pages]).to_excel(w, "页面", index=False)
                pd.DataFrame([dict(r) for r in products]).to_excel(w, "产品", index=False)
            paths["xlsx"] = str(xlsx)
        except Exception:
            pass
        headers = {
            "pages.csv": ["ts_code", "url", "final_url", "page_title", "page_type",
                          "crawl_method", "http_status", "encoding", "mojibake_ratio",
                          "font_obfuscated", "score", "confidence", "text_len", "crawled_at"],
            "products.csv": ["ts_code", "company_name", "product_name", "business_segment",
                             "product_category", "product_summary", "core_features",
                             "application_scenarios", "specifications", "source_url",
                             "evidence_text", "extraction_method", "confidence"],
        }
        for fname, rows in (("pages.csv", pages), ("products.csv", products)):
            fp = out / fname
            # Excel 打开中文 CSV 依赖 BOM，这里固定用 utf-8-sig
            with open(fp, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows
                                   else headers[fname])
                w.writeheader()
                w.writerows([dict(r) for r in rows])
            paths[fname] = str(fp)
        self._log(f"导出完成：页面 {len(pages)} 条，产品 {len(products)} 条", "info")
        return paths
