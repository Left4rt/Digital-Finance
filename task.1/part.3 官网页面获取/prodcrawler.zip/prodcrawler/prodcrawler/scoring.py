"""URL 归一化 + 产品页规则评分。

评分只做粗筛：把明显不是产品页的挡掉，把明显是产品页的直接放行，
中间地带交给大模型或人工复核。不追求一次判准。
"""
from __future__ import annotations

import re
from urllib.parse import urljoin, urlparse, urlunparse, parse_qsl, urlencode

from .config import (POSITIVE_KEYWORDS, NEGATIVE_KEYWORDS, URL_BLOCKLIST,
                     SKIP_EXTENSIONS, DOC_EXTENSIONS)

_TRACK_PARAMS = re.compile(r"^(utm_|from|spm|share|ref|_t|timestamp|rand)", re.I)


def normalize_url(url: str, base: str = "") -> str:
    """归一化：补全相对路径、去 fragment、去跟踪参数、排序 query、统一末尾斜杠。"""
    if not url:
        return ""
    url = url.strip().replace("\n", "").replace("\t", "")
    if base:
        url = urljoin(base, url)
    try:
        p = urlparse(url)
    except ValueError:
        return ""
    if p.scheme not in ("http", "https"):
        return ""
    netloc = p.netloc.lower()
    if netloc.endswith(":80"):
        netloc = netloc[:-3]
    elif netloc.endswith(":443"):
        netloc = netloc[:-4]
    q = [(k, v) for k, v in parse_qsl(p.query, keep_blank_values=False)
         if not _TRACK_PARAMS.match(k)]
    q.sort()
    path = re.sub(r"/{2,}", "/", p.path) or "/"
    return urlunparse((p.scheme, netloc, path, "", urlencode(q), ""))


def url_key(url: str) -> str:
    """去重键：忽略协议、www 前缀和末尾斜杠。"""
    n = normalize_url(url)
    if not n:
        return ""
    p = urlparse(n)
    host = p.netloc[4:] if p.netloc.startswith("www.") else p.netloc
    path = p.path.rstrip("/") or "/"
    return f"{host}{path}?{p.query}" if p.query else f"{host}{path}"


def registrable_domain(host_or_url: str) -> str:
    """取可注册域名。有 tldextract 用它，没有就用简易规则兜底。"""
    host = host_or_url
    if "://" in host_or_url:
        host = urlparse(host_or_url).netloc
    host = host.split(":")[0].lower().lstrip(".")
    try:
        import tldextract
        ext = tldextract.extract(host)
        if ext.domain and ext.suffix:
            return f"{ext.domain}.{ext.suffix}"
    except Exception:
        pass
    parts = host.split(".")
    if len(parts) <= 2:
        return host
    two = {"com.cn", "net.cn", "org.cn", "gov.cn", "co.uk", "com.hk"}
    if ".".join(parts[-2:]) in two and len(parts) >= 3:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


def same_site(url: str, root_domain: str) -> bool:
    d = registrable_domain(url)
    return bool(d) and d == root_domain


def is_crawlable(url: str) -> bool:
    low = url.lower()
    if any(b in low for b in URL_BLOCKLIST):
        return False
    path = urlparse(low).path
    if path.endswith(SKIP_EXTENSIONS):
        return False
    return True


def is_document(url: str) -> bool:
    return urlparse(url.lower()).path.endswith(DOC_EXTENSIONS)


# ------------------------------------------------------------------ 打分
def url_priority(url: str, anchor: str = "") -> int:
    """入队优先级：产品相关的先爬，保证有限预算花在正确的地方。"""
    blob = f"{url} {anchor}".lower()
    score = 0
    for kw, w in POSITIVE_KEYWORDS.items():
        if kw.lower() in blob:
            score += w
    for kw, w in NEGATIVE_KEYWORDS.items():
        if kw.lower() in blob:
            score += w
    return score


def score_page(url: str, title: str, headings: list[str], text: str,
               jsonld_types: list[str] | None = None,
               breadcrumb: str = "", table_count: int = 0,
               card_count: int = 0) -> tuple[float, dict]:
    """返回 (得分, 命中明细)。明细写进日志，方便回看为什么判成了产品页。"""
    jsonld_types = jsonld_types or []
    hits: dict[str, float] = {}
    score = 0.0

    url_l = url.lower()
    head_blob = f"{title} {' '.join(headings[:6])} {breadcrumb}".lower()
    body_blob = text[:4000].lower()

    for kw, w in POSITIVE_KEYWORDS.items():
        k = kw.lower()
        gained = 0.0
        if k in url_l:
            gained += w * 1.0
        if k in head_blob:
            gained += w * 1.2          # 标题/导航命中权重更高
        elif k in body_blob:
            gained += w * 0.4
        if gained:
            score += gained
            hits[f"+{kw}"] = round(gained, 2)

    for kw, w in NEGATIVE_KEYWORDS.items():
        k = kw.lower()
        if k in url_l or k in head_blob:
            score += w
            hits[f"-{kw}"] = w

    if any(t in ("Product", "ProductModel", "IndividualProduct", "Offer") for t in jsonld_types):
        score += 8
        hits["jsonld:Product"] = 8

    # 结构特征：参数表、产品卡片列表
    if table_count >= 1 and re.search(r"参数|规格|型号|specification", text[:6000], re.I):
        score += 3
        hits["spec_table"] = 3
    if card_count >= 4:
        score += 2
        hits["card_grid"] = 2

    # 正文里成套出现"功能/特点/应用"这类产品文案骨架
    frame = sum(1 for kw in ("功能", "特点", "优势", "应用", "规格", "参数", "适用")
                if kw in text[:6000])
    if frame >= 3:
        score += 2
        hits["product_frame"] = 2

    if len(re.sub(r"\s+", "", text)) < 120:
        score -= 3
        hits["too_short"] = -3

    return round(score, 2), hits


def classify_page(url: str, title: str, text: str, score: float,
                  card_count: int, jsonld_types: list[str] | None = None) -> str:
    """区分 业务板块页 / 产品分类页 / 产品详情页 / 资料附件 / 其他。"""
    if is_document(url):
        return "doc"
    jsonld_types = jsonld_types or []
    if "Product" in jsonld_types:
        return "detail"
    detail_signal = sum(1 for kw in ("技术参数", "规格参数", "产品特点", "型号",
                                     "订货", "选型", "specification")
                        if kw in (title + text[:5000]))
    if card_count >= 6 and detail_signal <= 1:
        return "category"
    if detail_signal >= 2:
        return "detail"
    if re.search(r"(业务|板块|产业|业务领域|主营)", title):
        return "business"
    if score >= 8:
        return "detail"
    if score >= 4:
        return "category"
    return "other"
