"""抓取层：HTTP 优先，必要时降级到浏览器渲染。

稳健性设计要点：
- 每个域名独立限速 + 独立熔断，一个站点挂掉不影响其他公司；
- 429/403 自动退避并降速，而不是硬重试；
- 超时、连接错误、SSL 错误分类处理，错误信息落库便于事后排查；
- 浏览器渲染是"按需降级"，只在正文明显不足时启用。
"""
from __future__ import annotations

import random
import threading
import time
from dataclasses import dataclass, field
from urllib.parse import urlparse
from urllib.robotparser import RobotFileParser

from .config import Settings
from .textguard import decode_html


@dataclass
class FetchResult:
    url: str
    final_url: str = ""
    status: int = 0
    ok: bool = False
    content: bytes = b""
    text: str = ""
    encoding: str = ""
    encoding_source: str = ""
    mojibake_ratio: float = 0.0
    content_type: str = ""
    etag: str = ""
    last_modified: str = ""
    method: str = "http"
    error: str = ""
    elapsed: float = 0.0

    @property
    def is_html(self) -> bool:
        return "html" in self.content_type or (not self.content_type and bool(self.text))

    @property
    def is_pdf(self) -> bool:
        return "pdf" in self.content_type or self.final_url.lower().endswith(".pdf")


@dataclass
class DomainState:
    """单域名的限速与健康状态。"""
    last_request: float = 0.0
    delay: float = 1.5
    consecutive_errors: int = 0
    blocked_until: float = 0.0
    lock: threading.Lock = field(default_factory=threading.Lock)


class Fetcher:
    def __init__(self, settings: Settings, logger=None):
        self.s = settings
        self.log = logger or (lambda *a, **k: None)
        self._domains: dict[str, DomainState] = {}
        self._domains_lock = threading.Lock()
        self._robots: dict[str, RobotFileParser | None] = {}
        self._client = None
        self._browser = None
        self._pw = None
        self._browser_lock = threading.Lock()

    # ---------------------------------------------------------------- client
    @property
    def client(self):
        if self._client is None:
            import httpx
            self._client = httpx.Client(
                headers={
                    "User-Agent": self.s.user_agent,
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
                },
                timeout=self.s.timeout,
                follow_redirects=True,
                verify=self.s.verify_ssl,
                limits=__import__("httpx").Limits(max_connections=40, max_keepalive_connections=20),
            )
        return self._client

    def _state(self, host: str) -> DomainState:
        with self._domains_lock:
            st = self._domains.get(host)
            if st is None:
                st = DomainState(delay=self.s.per_domain_delay)
                self._domains[host] = st
            return st

    def _throttle(self, host: str) -> None:
        st = self._state(host)
        with st.lock:
            now = time.time()
            if st.blocked_until > now:
                time.sleep(min(st.blocked_until - now, 30))
            wait = st.last_request + st.delay - time.time()
            if wait > 0:
                time.sleep(wait + random.uniform(0, 0.4))
            st.last_request = time.time()

    def domain_healthy(self, host: str) -> bool:
        st = self._state(host)
        return st.consecutive_errors < 8 and st.blocked_until < time.time()

    # ---------------------------------------------------------------- robots
    def robots_allowed(self, url: str) -> bool:
        if not self.s.respect_robots:
            return True
        p = urlparse(url)
        key = f"{p.scheme}://{p.netloc}"
        if key not in self._robots:
            rp = RobotFileParser()
            try:
                r = self.client.get(f"{key}/robots.txt", timeout=10)
                if r.status_code == 200:
                    body = decode_html(r.content).text
                    rp.parse(body.splitlines())
                else:
                    rp = None
            except Exception:
                rp = None
            self._robots[key] = rp
        rp = self._robots[key]
        if rp is None:
            return True
        try:
            return rp.can_fetch(self.s.user_agent, url)
        except Exception:
            return True

    def sitemaps_from_robots(self, base: str) -> list[str]:
        p = urlparse(base)
        key = f"{p.scheme}://{p.netloc}"
        out: list[str] = []
        try:
            r = self.client.get(f"{key}/robots.txt", timeout=10)
            if r.status_code == 200:
                for line in decode_html(r.content).text.splitlines():
                    if line.lower().startswith("sitemap:"):
                        out.append(line.split(":", 1)[1].strip())
        except Exception:
            pass
        return out

    # ---------------------------------------------------------------- fetch
    def fetch(self, url: str, *, etag: str = "", last_modified: str = "",
              allow_render: bool = False) -> FetchResult:
        host = urlparse(url).netloc
        res = FetchResult(url=url)
        if not self.domain_healthy(host):
            res.error = "domain_circuit_open"
            return res
        if not self.robots_allowed(url):
            res.error = "robots_disallow"
            res.status = -1
            return res

        headers = {}
        if etag:
            headers["If-None-Match"] = etag
        if last_modified:
            headers["If-Modified-Since"] = last_modified

        st = self._state(host)
        t0 = time.time()
        for attempt in range(self.s.max_retries):
            self._throttle(host)
            try:
                r = self.client.get(url, headers=headers)
                res.status = r.status_code
                res.final_url = str(r.url)
                res.content_type = (r.headers.get("content-type") or "").lower()
                res.etag = r.headers.get("etag", "")
                res.last_modified = r.headers.get("last-modified", "")

                if r.status_code == 304:            # 增量更新命中
                    res.ok, res.error = True, "not_modified"
                    st.consecutive_errors = 0
                    break
                if r.status_code in (429, 503):     # 降速而不是猛冲
                    with st.lock:
                        st.delay = min(st.delay * 2, 20)
                        st.blocked_until = time.time() + min(30 * (attempt + 1), 120)
                    res.error = f"throttled_{r.status_code}"
                    continue
                if r.status_code == 403:
                    st.consecutive_errors += 1
                    res.error = "forbidden"
                    break
                if r.status_code >= 500:
                    res.error = f"server_{r.status_code}"
                    time.sleep(self.s.retry_backoff ** attempt)
                    continue
                if r.status_code >= 400:
                    res.error = f"http_{r.status_code}"
                    break

                res.content = r.content
                if "pdf" in res.content_type or url.lower().endswith(".pdf"):
                    res.ok = True
                else:
                    dec = decode_html(r.content, _charset_of(res.content_type))
                    res.text = dec.text
                    res.encoding = dec.encoding
                    res.encoding_source = dec.encoding_source
                    res.mojibake_ratio = dec.mojibake_ratio
                    res.ok = True
                st.consecutive_errors = 0
                with st.lock:
                    st.delay = max(self.s.per_domain_delay, st.delay * 0.9)
                break
            except Exception as e:
                res.error = f"{type(e).__name__}: {e}"[:200]
                st.consecutive_errors += 1
                time.sleep(self.s.retry_backoff ** attempt + random.uniform(0, 1))

        res.elapsed = time.time() - t0

        # 正文过短 → 疑似前端渲染，降级到浏览器
        if allow_render and self.s.enable_playwright and res.ok and res.is_html:
            if _visible_len(res.text) < self.s.render_min_text_len:
                rendered = self.render(url)
                if rendered.ok and _visible_len(rendered.text) > _visible_len(res.text):
                    rendered.etag, rendered.last_modified = res.etag, res.last_modified
                    return rendered
        return res

    # ---------------------------------------------------------------- 渲染
    def _ensure_browser(self):
        if self._browser is not None:
            return self._browser
        with self._browser_lock:
            if self._browser is None:
                from playwright.sync_api import sync_playwright
                self._pw = sync_playwright().start()
                self._browser = self._pw.chromium.launch(
                    args=["--disable-blink-features=AutomationControlled", "--no-sandbox"]
                )
        return self._browser

    def render(self, url: str) -> FetchResult:
        """Playwright 渲染。失败不抛异常，只返回带 error 的结果。"""
        res = FetchResult(url=url, method="playwright")
        ctx = page = None
        try:
            browser = self._ensure_browser()
            ctx = browser.new_context(
                user_agent=self.s.user_agent, locale="zh-CN",
                viewport={"width": 1440, "height": 900}, ignore_https_errors=True,
            )
            page = ctx.new_page()
            page.route("**/*.{png,jpg,jpeg,gif,webp,mp4,woff,woff2}",
                       lambda route: route.abort())
            resp = page.goto(url, wait_until="domcontentloaded",
                             timeout=self.s.render_timeout * 1000)
            try:
                page.wait_for_load_state("networkidle", timeout=6000)
            except Exception:
                pass
            page.wait_for_timeout(800)
            res.status = resp.status if resp else 0
            res.final_url = page.url
            res.text = page.content()
            res.content = res.text.encode("utf-8", "ignore")
            res.encoding, res.encoding_source = "utf-8", "playwright"
            res.content_type = "text/html"
            res.ok = bool(res.text)
        except Exception as e:
            res.error = f"render_failed: {type(e).__name__}: {e}"[:200]
        finally:
            for obj in (page, ctx):
                try:
                    obj and obj.close()
                except Exception:
                    pass
        return res

    def screenshot_element(self, url: str, selector: str, out_path: str) -> bool:
        """给字体反爬页面留的 OCR 入口：截图指定区域，再交给 OCR。"""
        ctx = page = None
        try:
            browser = self._ensure_browser()
            ctx = browser.new_context(user_agent=self.s.user_agent, locale="zh-CN",
                                      ignore_https_errors=True)
            page = ctx.new_page()
            page.goto(url, wait_until="networkidle", timeout=self.s.render_timeout * 1000)
            page.locator(selector).first.screenshot(path=out_path)
            return True
        except Exception:
            return False
        finally:
            for obj in (page, ctx):
                try:
                    obj and obj.close()
                except Exception:
                    pass

    def close(self) -> None:
        for closer in (
            lambda: self._client and self._client.close(),
            lambda: self._browser and self._browser.close(),
            lambda: self._pw and self._pw.stop(),
        ):
            try:
                closer()
            except Exception:
                pass


def _charset_of(content_type: str) -> str | None:
    if "charset=" in content_type:
        return content_type.split("charset=", 1)[1].split(";")[0].strip()
    return None


def _visible_len(html_text: str) -> int:
    import re
    body = re.sub(r"(?is)<(script|style|noscript).*?</\1>", " ", html_text or "")
    body = re.sub(r"(?s)<[^>]+>", " ", body)
    return len(re.sub(r"\s+", "", body))
