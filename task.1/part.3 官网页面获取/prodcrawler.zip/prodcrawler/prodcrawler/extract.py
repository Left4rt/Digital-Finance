"""内容抽取：结构化数据 → DOM 规则 → 正文清洗 → 大模型（可选）。

原则：大模型只负责理解已经清洗好的正文，不负责发现页面，也不允许补充
页面上没有的内容。每条产品记录都带 source_url 和原文证据。
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from typing import Any

from .config import Settings
from .textguard import clean_text, inspect_fonts

_JSONLD = re.compile(r'(?is)<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>')


@dataclass
class PageContent:
    title: str = ""
    headings: list[str] = field(default_factory=list)
    breadcrumb: str = ""
    text: str = ""
    tables: list[list[list[str]]] = field(default_factory=list)
    jsonld_types: list[str] = field(default_factory=list)
    jsonld_products: list[dict] = field(default_factory=list)
    card_count: int = 0
    font_obfuscated: bool = False
    font_note: str = ""


@dataclass
class Product:
    product_name: str = ""
    business_segment: str = ""
    product_category: str = ""
    product_summary: str = ""
    core_features: list[str] = field(default_factory=list)
    application_scenarios: list[str] = field(default_factory=list)
    specifications: dict = field(default_factory=dict)
    evidence_text: str = ""
    extraction_method: str = "dom"
    confidence: float = 0.5

    def as_row(self) -> dict:
        d = asdict(self)
        d["core_features"] = json.dumps(self.core_features, ensure_ascii=False)
        d["application_scenarios"] = json.dumps(self.application_scenarios, ensure_ascii=False)
        d["specifications"] = json.dumps(self.specifications, ensure_ascii=False)
        return d


# ------------------------------------------------------------------ HTML
def parse_page(html_text: str, url: str) -> PageContent:
    pc = PageContent()
    if not html_text:
        return pc
    pc.jsonld_types, pc.jsonld_products = parse_jsonld(html_text)

    doc = None
    try:
        from lxml import html as lhtml
        doc = lhtml.fromstring(html_text)
        for bad in doc.xpath("//script|//style|//noscript"):
            bad.getparent().remove(bad)
    except Exception:
        doc = None

    if doc is not None:
        t = doc.xpath("//title/text()")
        pc.title = clean_text(t[0])[:200] if t else ""
        pc.headings = [clean_text(h.text_content())[:120]
                       for h in doc.xpath("//h1|//h2|//h3")][:20]
        crumbs = doc.xpath(
            "//*[contains(@class,'crumb') or contains(@class,'bread') or "
            "contains(@class,'position') or contains(@class,'location')]")
        if crumbs:
            pc.breadcrumb = clean_text(crumbs[0].text_content())[:200]
        pc.tables = [_table_rows(tb) for tb in doc.xpath("//table")[:12]]
        pc.card_count = len(doc.xpath(
            "//*[contains(@class,'product') or contains(@class,'item') or "
            "contains(@class,'card') or contains(@class,'list-item')]"))
    else:
        m = re.search(r"(?is)<title[^>]*>(.*?)</title>", html_text)
        pc.title = clean_text(re.sub(r"<[^>]+>", "", m.group(1)))[:200] if m else ""

    pc.text = extract_main_text(html_text, url, doc)

    fr = inspect_fonts(html_text, pc.text)
    pc.font_obfuscated, pc.font_note = fr.obfuscated, fr.note
    return pc


def _table_rows(table) -> list[list[str]]:
    rows = []
    for tr in table.xpath(".//tr")[:60]:
        cells = [clean_text(td.text_content())[:120] for td in tr.xpath("./td|./th")]
        if any(cells):
            rows.append(cells)
    return rows


def extract_main_text(html_text: str, url: str, doc=None) -> str:
    """正文提取：优先 trafilatura，失败则用 DOM 兜底，再失败用正则。"""
    try:
        import trafilatura
        out = trafilatura.extract(
            html_text, url=url, output_format="markdown", include_tables=True,
            include_links=False, favor_precision=True, no_fallback=False,
        )
        if out and len(clean_text(out)) > 120:
            return clean_text(out)
    except Exception:
        pass

    if doc is not None:
        try:
            best, best_len = None, 0
            for node in doc.xpath(
                "//*[contains(@class,'content') or contains(@class,'detail') or "
                "contains(@class,'article') or contains(@class,'main') or "
                "contains(@id,'content') or contains(@id,'main')]"
            ):
                txt = clean_text(node.text_content())
                if len(txt) > best_len:
                    best, best_len = txt, len(txt)
            if best and best_len > 120:
                return best
            body = doc.xpath("//body")
            if body:
                return clean_text(body[0].text_content())
        except Exception:
            pass

    stripped = re.sub(r"(?is)<(script|style|noscript).*?</\1>", " ", html_text or "")
    return clean_text(re.sub(r"(?s)<[^>]+>", " ", stripped))


def parse_jsonld(html_text: str) -> tuple[list[str], list[dict]]:
    types: list[str] = []
    products: list[dict] = []

    def walk(node: Any):
        if isinstance(node, list):
            for x in node:
                walk(x)
        elif isinstance(node, dict):
            t = node.get("@type")
            tl = [t] if isinstance(t, str) else (t if isinstance(t, list) else [])
            types.extend(tl)
            if any(x in ("Product", "ProductModel", "IndividualProduct") for x in tl):
                products.append(node)
            for v in node.values():
                if isinstance(v, (dict, list)):
                    walk(v)

    for block in _JSONLD.findall(html_text or ""):
        raw = block.strip()
        try:
            walk(json.loads(raw))
        except Exception:
            try:  # 常见尾逗号 / 单引号问题，做一次宽松修复
                walk(json.loads(re.sub(r",\s*([}\]])", r"\1", raw)))
            except Exception:
                continue
    return list(dict.fromkeys(types)), products


# ------------------------------------------------------------------ 产品抽取
_SEC_PATTERNS = {
    "features": r"(产品特点|核心功能|功能特性|主要功能|产品优势|技术优势|特点|优势)",
    "scenarios": r"(应用场景|适用范围|应用领域|典型应用|使用场景)",
    "specs": r"(技术参数|规格参数|产品参数|技术指标|主要参数)",
}


def products_from_jsonld(pc: PageContent) -> list[Product]:
    out = []
    for node in pc.jsonld_products:
        name = _s(node.get("name"))
        if not name:
            continue
        specs = {}
        for ap in node.get("additionalProperty", []) or []:
            if isinstance(ap, dict) and ap.get("name"):
                specs[_s(ap["name"])] = _s(ap.get("value"))
        brand = node.get("brand")
        brand = _s(brand.get("name")) if isinstance(brand, dict) else _s(brand)
        out.append(Product(
            product_name=name,
            product_category=_s(node.get("category")),
            product_summary=_s(node.get("description"))[:1200],
            specifications=specs,
            business_segment=brand,
            evidence_text=_s(node.get("description"))[:400],
            extraction_method="jsonld",
            confidence=0.9,
        ))
    return out


def products_from_dom(pc: PageContent, page_type: str) -> list[Product]:
    """规则抽取：产品详情页取 H1 + 分节正文；分类页只登记分类名。"""
    text = pc.text or ""
    if page_type == "category":
        name = pc.headings[0] if pc.headings else pc.title
        if not name:
            return []
        return [Product(
            product_name="", product_category=_trim_title(name),
            business_segment=_segment_from_crumb(pc.breadcrumb),
            product_summary=text[:600], evidence_text=text[:300],
            extraction_method="dom-category", confidence=0.4,
        )]

    name = pc.headings[0] if pc.headings else _trim_title(pc.title)
    name = _trim_title(name)
    if not name or len(name) > 80:
        return []

    p = Product(
        product_name=name,
        product_category=_category_from_crumb(pc.breadcrumb),
        business_segment=_segment_from_crumb(pc.breadcrumb),
        product_summary=_summary(text),
        core_features=_section_items(text, _SEC_PATTERNS["features"]),
        application_scenarios=_section_items(text, _SEC_PATTERNS["scenarios"]),
        specifications=_specs_from_tables(pc.tables) or _specs_from_text(text),
        evidence_text=text[:400],
        extraction_method="dom",
        confidence=0.6,
    )
    if p.core_features or p.specifications:
        p.confidence = 0.75
    return [p]


def _summary(text: str) -> str:
    body = re.sub(r"^#+\s*", "", text, flags=re.M)
    paras = [p.strip() for p in body.split("\n") if len(p.strip()) >= 30]
    return " ".join(paras[:3])[:800] if paras else body[:400]


def _section_items(text: str, pattern: str) -> list[str]:
    m = re.search(pattern, text)
    if not m:
        return []
    seg = text[m.end(): m.end() + 1500]
    seg = re.split(r"\n\s*\n", seg)[0] if "\n\n" in seg else seg
    items = re.split(r"[\n；;•·]|(?<=[。！])", seg)
    out = [clean_text(i).lstrip("-*·0123456789.、 ") for i in items]
    out = [i for i in out if 4 <= len(i) <= 120]
    return out[:12]


def _specs_from_tables(tables: list[list[list[str]]]) -> dict:
    for rows in tables:
        kv = {}
        for r in rows:
            if len(r) == 2 and r[0] and r[1] and len(r[0]) <= 30:
                kv[r[0]] = r[1]
        if len(kv) >= 3:
            return kv
    return {}


def _specs_from_text(text: str) -> dict:
    m = re.search(_SEC_PATTERNS["specs"], text)
    if not m:
        return {}
    seg = text[m.end(): m.end() + 1200]
    kv = {}
    for line in seg.split("\n"):
        mm = re.match(r"^\s*([\u4e00-\u9fffA-Za-z][^:：]{1,24})[:：]\s*(.{1,80})$", line.strip())
        if mm:
            kv[mm.group(1).strip()] = mm.group(2).strip()
    return kv


def _trim_title(title: str) -> str:
    t = re.split(r"[-_|—–]{1,2}|\s\|\s", title or "")[0].strip()
    return re.sub(r"(产品详情|产品中心|详情页?)$", "", t).strip()


def _category_from_crumb(crumb: str) -> str:
    parts = [p for p in re.split(r"[>》/›|→\-]+", crumb or "") if p.strip()]
    parts = [p.strip() for p in parts if p.strip() not in ("首页", "当前位置", "Home", "您的位置")]
    return parts[-1][:60] if parts else ""


def _segment_from_crumb(crumb: str) -> str:
    parts = [p.strip() for p in re.split(r"[>》/›|→\-]+", crumb or "") if p.strip()]
    parts = [p for p in parts if p not in ("首页", "当前位置", "Home", "您的位置")]
    return parts[0][:60] if parts else ""


def _s(v) -> str:
    if v is None:
        return ""
    if isinstance(v, (list, tuple)):
        return " ".join(_s(x) for x in v)[:1200]
    if isinstance(v, dict):
        return _s(v.get("name") or v.get("@value") or "")
    return clean_text(str(v))


# ------------------------------------------------------------------ PDF
def extract_pdf(content: bytes, max_pages: int = 30) -> str:
    """PDF 文本抽取。PyMuPDF 优先，pdfminer 兜底；扫描件返回空串并交给上层标记。"""
    try:
        import fitz  # PyMuPDF
        with fitz.open(stream=content, filetype="pdf") as doc:
            parts = [doc[i].get_text() for i in range(min(len(doc), max_pages))]
        return clean_text("\n".join(parts))
    except Exception:
        pass
    try:
        import io
        from pdfminer.high_level import extract_text
        return clean_text(extract_text(io.BytesIO(content), maxpages=max_pages))
    except Exception:
        return ""


# ------------------------------------------------------------------ 大模型
LLM_SYSTEM = """你是产品信息抽取器。只能使用给定网页正文中明确出现的信息。
找不到的字段返回 null 或空数组，禁止根据公司行业或常识补充任何内容。
每个产品必须给出一段来自正文的原文证据。只输出 JSON，不要任何解释和代码块标记。"""

LLM_SCHEMA = """输出格式：
{"products":[{"product_name":"","business_segment":null,"product_category":null,
"product_summary":"","core_features":[],"application_scenarios":[],
"technical_parameters":{},"evidence":"","confidence":0.0}]}
若正文不是产品介绍，返回 {"products":[]}。"""


def llm_extract(settings: Settings, company: str, url: str, title: str,
                text: str) -> list[Product]:
    if not settings.llm_enabled or not settings.llm_api_key:
        return []
    import httpx
    body = {
        "model": settings.llm_model,
        "max_tokens": 2000,
        "system": LLM_SYSTEM,
        "messages": [{"role": "user", "content":
                      f"{LLM_SCHEMA}\n\n公司：{company}\n页面标题：{title}\n"
                      f"页面地址：{url}\n\n正文：\n{text[:settings.llm_max_chars]}"}],
    }
    try:
        r = httpx.post(settings.llm_base_url, json=body, timeout=90, headers={
            "x-api-key": settings.llm_api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        })
        r.raise_for_status()
        raw = "".join(b.get("text", "") for b in r.json().get("content", []))
        raw = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M).strip()
        data = json.loads(raw)
    except Exception:
        return []

    out = []
    for item in data.get("products", [])[:20]:
        name = _s(item.get("product_name"))
        if not name:
            continue
        ev = _s(item.get("evidence"))
        if ev and ev[:20] and ev[:20] not in text:   # 证据必须能在正文里找到
            conf = 0.4
        else:
            conf = float(item.get("confidence") or 0.7)
        out.append(Product(
            product_name=name,
            business_segment=_s(item.get("business_segment")),
            product_category=_s(item.get("product_category")),
            product_summary=_s(item.get("product_summary"))[:1200],
            core_features=[_s(x) for x in (item.get("core_features") or [])][:15],
            application_scenarios=[_s(x) for x in (item.get("application_scenarios") or [])][:15],
            specifications={_s(k): _s(v) for k, v in
                            (item.get("technical_parameters") or {}).items()},
            evidence_text=ev[:400],
            extraction_method="llm",
            confidence=round(min(max(conf, 0.0), 0.95), 2),
        ))
    return out


def dedup_key(company: str, product: Product) -> str:
    import hashlib
    base = f"{company}|{product.product_name}|{product.product_category}".lower()
    base = re.sub(r"[\s\-_（）()【】\[\]]+", "", base)
    return hashlib.md5(base.encode("utf-8")).hexdigest()
