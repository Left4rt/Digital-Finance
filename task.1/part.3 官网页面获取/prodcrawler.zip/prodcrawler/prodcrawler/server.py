"""可视化控制台：FastAPI + 轮询接口。

面板负责三件事：看清楚现在跑到哪、看清楚哪家出了问题、能停能续。
"""
from __future__ import annotations

import json
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

from .config import Settings
from .pipeline import Pipeline

STATIC = Path(__file__).parent / "static"


class LoadReq(BaseModel):
    csv_path: str | None = None


class RetryReq(BaseModel):
    ts_code: str | None = None      # 为空则重试全部失败公司


def create_app(settings: Settings) -> FastAPI:
    app = FastAPI(title="上市公司产品页采集控制台")
    pipe = Pipeline(settings)

    @app.get("/", response_class=HTMLResponse)
    def index():
        return (STATIC / "index.html").read_text(encoding="utf-8")

    @app.get("/api/status")
    def status(last_event: int = 0):
        ov = pipe.store.overview()
        companies = [dict(r) for r in pipe.store.query(
            """SELECT ts_code, name, domain, domain_confidence, status, stage,
                      pages_seen, product_pages, products, last_error, attempts
               FROM companies ORDER BY rowid""")]
        events = [dict(r) for r in pipe.store.events_after(last_event, 120)]
        return {
            "running": pipe.running,
            "paused": pipe.pause_flag.is_set(),
            "overview": ov,
            "companies": companies,
            "events": events,
            "last_event": events[-1]["id"] if events else last_event,
        }

    @app.get("/api/company/{ts_code}")
    def company_detail(ts_code: str):
        c = pipe.store.one("SELECT * FROM companies WHERE ts_code=?", (ts_code,))
        pages = [dict(r) for r in pipe.store.query(
            """SELECT url, page_title, page_type, score, http_status, crawl_method,
                      encoding, mojibake_ratio, font_obfuscated, text_len
               FROM pages WHERE ts_code=? ORDER BY score DESC LIMIT 60""", (ts_code,))]
        products = [dict(r) for r in pipe.store.query(
            """SELECT product_name, product_category, business_segment, product_summary,
                      core_features, application_scenarios, source_url,
                      extraction_method, confidence
               FROM products WHERE ts_code=? ORDER BY confidence DESC LIMIT 100""",
            (ts_code,))]
        return {"company": dict(c) if c else None,
                "frontier": pipe.store.frontier_counts(ts_code),
                "pages": pages, "products": products}

    @app.post("/api/load")
    def load(req: LoadReq):
        n = pipe.load_csv(req.csv_path)
        return {"loaded": n}

    @app.post("/api/start")
    def start():
        pipe.start(background=True)
        return {"running": pipe.running}

    @app.post("/api/pause")
    def pause():
        pipe.pause()
        return {"paused": True}

    @app.post("/api/resume")
    def resume():
        pipe.resume()
        return {"paused": False}

    @app.post("/api/stop")
    def stop():
        pipe.stop()
        return {"stopping": True}

    @app.post("/api/retry")
    def retry(req: RetryReq):
        if req.ts_code:
            pipe.store.set_company(req.ts_code, status="pending", attempts=0,
                                   last_error=None, claimed_at=None)
            pipe.store.reclaim_running_urls(req.ts_code)
            n = 1
        else:
            n = pipe.store.write(
                "UPDATE companies SET status='pending', attempts=0, claimed_at=NULL "
                "WHERE status IN ('failed','retry')").rowcount
            pipe.store.reclaim_running_urls()
        return {"requeued": n}

    @app.post("/api/export")
    def export():
        return pipe.export()

    @app.get("/api/settings")
    def get_settings():
        from dataclasses import asdict
        d = asdict(settings)
        d.pop("llm_api_key", None)
        return JSONResponse(json.loads(json.dumps(d, ensure_ascii=False)))

    return app
