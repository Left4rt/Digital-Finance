"""SQLite 存储层。

断点续爬的全部状态都落在这里：公司任务状态机、URL 前沿队列、页面记录、
产品记录、事件日志。进程被杀掉后重启，只要数据库还在就能接着跑。
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA busy_timeout=15000;

-- 公司级任务状态机：pending -> resolving -> discovering -> extracting -> done / failed
CREATE TABLE IF NOT EXISTS companies (
    ts_code         TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    domain          TEXT,
    domain_source   TEXT,          -- csv / hint / search / manual
    domain_confidence REAL DEFAULT 0,
    status          TEXT NOT NULL DEFAULT 'pending',
    stage           TEXT,
    attempts        INTEGER DEFAULT 0,
    pages_seen      INTEGER DEFAULT 0,
    product_pages   INTEGER DEFAULT 0,
    products        INTEGER DEFAULT 0,
    last_error      TEXT,
    claimed_at      REAL,
    started_at      REAL,
    finished_at     REAL,
    updated_at      REAL
);

-- URL 前沿队列（断点续爬的核心）：重启后直接从 queued 里继续取
CREATE TABLE IF NOT EXISTS frontier (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts_code     TEXT NOT NULL,
    url         TEXT NOT NULL,
    url_key     TEXT NOT NULL,      -- 归一化后的去重键
    depth       INTEGER DEFAULT 0,
    priority    INTEGER DEFAULT 0,  -- 越大越先爬
    source      TEXT,               -- sitemap / nav / link / doc
    anchor      TEXT,
    state       TEXT DEFAULT 'queued',  -- queued / running / done / failed / skipped
    attempts    INTEGER DEFAULT 0,
    error       TEXT,
    updated_at  REAL,
    UNIQUE(ts_code, url_key)
);
CREATE INDEX IF NOT EXISTS idx_frontier_pick ON frontier(ts_code, state, priority DESC, depth);

-- 页面表
CREATE TABLE IF NOT EXISTS pages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ts_code         TEXT NOT NULL,
    url             TEXT NOT NULL,
    final_url       TEXT,
    url_key         TEXT NOT NULL,
    canonical       TEXT,
    page_title      TEXT,
    page_type       TEXT,           -- business / category / detail / doc / other
    crawl_method    TEXT,           -- http / playwright / pdf
    http_status     INTEGER,
    encoding        TEXT,
    encoding_source TEXT,
    mojibake_ratio  REAL,
    font_obfuscated INTEGER DEFAULT 0,
    font_note       TEXT,
    score           REAL,
    confidence      REAL,
    text_len        INTEGER,
    content_hash    TEXT,
    etag            TEXT,
    last_modified   TEXT,
    text_path       TEXT,           -- 正文落盘路径
    crawled_at      REAL,
    UNIQUE(ts_code, url_key)
);
CREATE INDEX IF NOT EXISTS idx_pages_company ON pages(ts_code, score DESC);

-- 产品表
CREATE TABLE IF NOT EXISTS products (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    ts_code               TEXT NOT NULL,
    company_name          TEXT,
    product_name          TEXT,
    business_segment      TEXT,
    product_category      TEXT,
    product_summary       TEXT,
    core_features         TEXT,     -- JSON array
    application_scenarios TEXT,     -- JSON array
    specifications        TEXT,     -- JSON object
    source_url            TEXT,
    evidence_text         TEXT,
    extraction_method     TEXT,     -- jsonld / dom / trafilatura / llm
    confidence            REAL,
    dedup_key             TEXT,
    created_at            REAL,
    UNIQUE(ts_code, dedup_key)
);
CREATE INDEX IF NOT EXISTS idx_products_company ON products(ts_code);

-- 事件流，给可视化面板用
CREATE TABLE IF NOT EXISTS events (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    ts        REAL,
    level     TEXT,
    ts_code   TEXT,
    message   TEXT,
    payload   TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_id ON events(id DESC);

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);
"""


class Store:
    def __init__(self, db_path: str):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._write_lock = threading.Lock()
        self._conns_lock = threading.Lock()
        self._all_conns: list[sqlite3.Connection] = []
        with self.conn() as c:
            c.executescript(SCHEMA)

    # ---------------------------------------------------------------- 基础
    def _get_conn(self) -> sqlite3.Connection:
        if getattr(self._local, "conn", None) is None:
            conn = sqlite3.connect(self.db_path, timeout=30, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA busy_timeout=15000")
            self._local.conn = conn
            with self._conns_lock:
                self._all_conns.append(conn)
        return self._local.conn

    def close(self) -> None:
        """关闭本 Store 打开过的所有连接。

        Windows 上 sqlite3 文件句柄不关闭会一直占着文件，临时目录/数据库文件删不掉，
        表现为 PermissionError: 另一个程序正在使用此文件。用完 Store（尤其是测试里
        用 tempfile.TemporaryDirectory 时）要显式调这个方法。
        """
        with self._conns_lock:
            conns, self._all_conns = self._all_conns, []
        for c in conns:
            try:
                c.close()
            except Exception:
                pass
        if getattr(self._local, "conn", None) is not None:
            self._local.conn = None

    @contextmanager
    def conn(self):
        c = self._get_conn()
        try:
            yield c
            c.commit()
        except Exception:
            c.rollback()
            raise

    def write(self, sql: str, params: Iterable = ()) -> sqlite3.Cursor:
        with self._write_lock, self.conn() as c:
            return c.execute(sql, tuple(params))

    def query(self, sql: str, params: Iterable = ()) -> list[sqlite3.Row]:
        with self.conn() as c:
            return c.execute(sql, tuple(params)).fetchall()

    def one(self, sql: str, params: Iterable = ()) -> sqlite3.Row | None:
        rows = self.query(sql, params)
        return rows[0] if rows else None

    # ---------------------------------------------------------------- 公司
    def upsert_company(self, ts_code: str, name: str, domain: str | None = None,
                       domain_source: str | None = None) -> None:
        now = time.time()
        self.write(
            """INSERT INTO companies(ts_code, name, domain, domain_source, updated_at)
               VALUES(?,?,?,?,?)
               ON CONFLICT(ts_code) DO UPDATE SET
                 name=excluded.name,
                 domain=COALESCE(companies.domain, excluded.domain),
                 domain_source=COALESCE(companies.domain_source, excluded.domain_source),
                 updated_at=excluded.updated_at""",
            (ts_code, name, domain, domain_source, now),
        )

    def claim_company(self, stale_minutes: int) -> sqlite3.Row | None:
        """原子地领取一家待处理公司。running 超时的任务会被回收，实现崩溃恢复。"""
        cutoff = time.time() - stale_minutes * 60
        with self._write_lock, self.conn() as c:
            c.execute(
                """UPDATE companies SET status='pending', stage='reclaimed'
                   WHERE status='running' AND (claimed_at IS NULL OR claimed_at < ?)""",
                (cutoff,),
            )
            row = c.execute(
                """SELECT * FROM companies
                   WHERE status IN ('pending','retry') AND attempts < 3
                   ORDER BY attempts ASC, rowid ASC LIMIT 1"""
            ).fetchone()
            if not row:
                return None
            now = time.time()
            c.execute(
                """UPDATE companies SET status='running', claimed_at=?, started_at=COALESCE(started_at,?),
                   attempts=attempts+1, updated_at=? WHERE ts_code=?""",
                (now, now, now, row["ts_code"]),
            )
            return row

    def set_company(self, ts_code: str, **fields: Any) -> None:
        if not fields:
            return
        fields["updated_at"] = time.time()
        cols = ", ".join(f"{k}=?" for k in fields)
        self.write(f"UPDATE companies SET {cols} WHERE ts_code=?",
                   (*fields.values(), ts_code))

    def bump_company(self, ts_code: str, field: str, n: int = 1) -> None:
        self.write(f"UPDATE companies SET {field}={field}+?, updated_at=? WHERE ts_code=?",
                   (n, time.time(), ts_code))

    # ---------------------------------------------------------------- 前沿
    def push_urls(self, ts_code: str, items: list[dict]) -> int:
        """批量入队，已存在的 url_key 直接忽略（天然幂等，支持重跑）。"""
        if not items:
            return 0
        now = time.time()
        rows = [
            (ts_code, it["url"], it["url_key"], it.get("depth", 0),
             it.get("priority", 0), it.get("source", "link"),
             (it.get("anchor") or "")[:200], now)
            for it in items
        ]
        with self._write_lock, self.conn() as c:
            cur = c.executemany(
                """INSERT OR IGNORE INTO frontier
                   (ts_code,url,url_key,depth,priority,source,anchor,updated_at)
                   VALUES(?,?,?,?,?,?,?,?)""",
                rows,
            )
            return cur.rowcount or 0

    def claim_urls(self, ts_code: str, limit: int) -> list[sqlite3.Row]:
        with self._write_lock, self.conn() as c:
            rows = c.execute(
                """SELECT * FROM frontier
                   WHERE ts_code=? AND state='queued'
                   ORDER BY priority DESC, depth ASC, id ASC LIMIT ?""",
                (ts_code, limit),
            ).fetchall()
            if rows:
                c.executemany(
                    "UPDATE frontier SET state='running', updated_at=? WHERE id=?",
                    [(time.time(), r["id"]) for r in rows],
                )
            return rows

    def finish_url(self, fid: int, state: str, error: str | None = None) -> None:
        self.write("UPDATE frontier SET state=?, error=?, updated_at=? WHERE id=?",
                   (state, (error or "")[:500], time.time(), fid))

    def requeue_url(self, fid: int, error: str) -> None:
        self.write(
            """UPDATE frontier
               SET state=CASE WHEN attempts+1>=3 THEN 'failed' ELSE 'queued' END,
                   attempts=attempts+1, error=?, updated_at=? WHERE id=?""",
            ((error or "")[:500], time.time(), fid),
        )

    def reclaim_running_urls(self, ts_code: str | None = None) -> int:
        sql = "UPDATE frontier SET state='queued' WHERE state='running'"
        params: tuple = ()
        if ts_code:
            sql += " AND ts_code=?"
            params = (ts_code,)
        return self.write(sql, params).rowcount

    def frontier_counts(self, ts_code: str) -> dict:
        rows = self.query(
            "SELECT state, COUNT(*) n FROM frontier WHERE ts_code=? GROUP BY state", (ts_code,)
        )
        return {r["state"]: r["n"] for r in rows}

    def pages_done(self, ts_code: str) -> int:
        r = self.one("SELECT COUNT(*) n FROM pages WHERE ts_code=?", (ts_code,))
        return r["n"] if r else 0

    def page_seen(self, ts_code: str, url_key: str) -> sqlite3.Row | None:
        return self.one("SELECT * FROM pages WHERE ts_code=? AND url_key=?", (ts_code, url_key))

    # ---------------------------------------------------------------- 页面 / 产品
    def save_page(self, rec: dict) -> None:
        cols = ", ".join(rec)
        marks = ", ".join("?" for _ in rec)
        updates = ", ".join(f"{k}=excluded.{k}" for k in rec if k not in ("ts_code", "url_key"))
        self.write(
            f"""INSERT INTO pages({cols}) VALUES({marks})
                ON CONFLICT(ts_code,url_key) DO UPDATE SET {updates}""",
            tuple(rec.values()),
        )

    def save_product(self, rec: dict) -> bool:
        cols = ", ".join(rec)
        marks = ", ".join("?" for _ in rec)
        cur = self.write(
            f"INSERT OR IGNORE INTO products({cols}) VALUES({marks})", tuple(rec.values())
        )
        return bool(cur.rowcount)

    # ---------------------------------------------------------------- 事件
    def log(self, level: str, message: str, ts_code: str | None = None,
            payload: dict | None = None) -> None:
        self.write(
            "INSERT INTO events(ts,level,ts_code,message,payload) VALUES(?,?,?,?,?)",
            (time.time(), level, ts_code, message[:500],
             json.dumps(payload, ensure_ascii=False) if payload else None),
        )

    def events_after(self, last_id: int, limit: int = 200) -> list[sqlite3.Row]:
        return self.query(
            "SELECT * FROM events WHERE id>? ORDER BY id ASC LIMIT ?", (last_id, limit)
        )

    # ---------------------------------------------------------------- 概览
    def overview(self) -> dict:
        st = {r["status"]: r["n"] for r in self.query(
            "SELECT status, COUNT(*) n FROM companies GROUP BY status")}
        tot = self.one("SELECT COUNT(*) n FROM companies")["n"]
        pages = self.one("SELECT COUNT(*) n FROM pages")["n"]
        prod_pages = self.one("SELECT COUNT(*) n FROM pages WHERE page_type IN ('detail','category')")["n"]
        products = self.one("SELECT COUNT(*) n FROM products")["n"]
        queued = self.one("SELECT COUNT(*) n FROM frontier WHERE state='queued'")["n"]
        garbled = self.one("SELECT COUNT(*) n FROM pages WHERE font_obfuscated=1 OR mojibake_ratio>0.05")["n"]
        return {
            "companies_total": tot, "by_status": st, "pages": pages,
            "product_pages": prod_pages, "products": products,
            "queued_urls": queued, "font_flagged": garbled,
        }

    def set_meta(self, key: str, value: str) -> None:
        self.write("INSERT INTO meta(key,value) VALUES(?,?) "
                   "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))

    def get_meta(self, key: str, default: str = "") -> str:
        r = self.one("SELECT value FROM meta WHERE key=?", (key,))
        return r["value"] if r else default
