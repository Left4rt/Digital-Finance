"""编码识别与字体反爬处理。

国内上市公司官网在文字上主要有三类坑：

1. 声明 UTF-8 实际是 GBK/GB2312（或反过来），直接 response.text 会得到乱码；
2. 页面用自定义 woff 字体做反爬，正文里是私有区码位（U+E000–U+F8FF），
   浏览器里看着正常，抓下来全是方块；
3. 全角半角、软换行、零宽字符混杂，影响后续去重和抽取。

这个模块负责把字节流稳定地变成可用文本，并把不可靠的部分显式标出来，
而不是悄悄地把乱码写进数据库。
"""
from __future__ import annotations

import html
import re
import unicodedata
from dataclasses import dataclass

# 常见中文编码，顺序即尝试优先级。GB18030 是 GBK/GB2312 的超集，放在前面兜底。
# utf-16 只在检测到 BOM 时使用：没有 BOM 时它会把 GBK 字节"成功"解成一堆生僻汉字，
# 严格解码不报错，是最容易误判的陷阱。
CN_ENCODINGS = ("utf-8", "gb18030", "big5", "cp1252", "latin-1")

_META_CHARSET = re.compile(
    rb"""<meta[^>]+charset\s*=\s*["']?\s*([a-zA-Z0-9_\-]+)""", re.I)
_META_HTTP_EQUIV = re.compile(
    rb"""<meta[^>]+content\s*=\s*["'][^"']*charset\s*=\s*([a-zA-Z0-9_\-]+)""", re.I)
_FONT_FACE = re.compile(r"@font-face\s*{[^}]*}", re.I | re.S)
_FONT_SRC = re.compile(r"url\(['\"]?([^'\")]+\.(?:woff2?|ttf|otf|eot)[^'\")]*)", re.I)
_BASE64_FONT = re.compile(r"data:(?:font|application)/[^;]+;base64,", re.I)

# 私有使用区（自定义字体反爬最常落的区段）
_PUA_RANGES = ((0xE000, 0xF8FF), (0xF0000, 0xFFFFD), (0x100000, 0x10FFFD))
# 典型 mojibake 特征字符：UTF-8 被按 latin-1/cp1252 解出来的产物
_MOJIBAKE_CHARS = set("ÃÂÐÑ×ØÙÚÛÜåæçèéêëìíîïðñòóôõöøùúûüýþÿ¦§¨©ª«¬®¯°±²³´µ¶·¸¹º»¼½¾")


@dataclass
class DecodedText:
    text: str
    encoding: str
    encoding_source: str          # http-header / bom / meta / detector / fallback
    mojibake_ratio: float         # 0~1，越高越可疑
    replacement_ratio: float      # U+FFFD 占比
    ok: bool                      # 是否认为可用


@dataclass
class FontReport:
    obfuscated: bool
    pua_count: int
    pua_ratio: float
    font_faces: int
    font_urls: list[str]
    note: str


# ------------------------------------------------------------------ 编码
def _charset_from_bom(data: bytes) -> str | None:
    if data.startswith(b"\xef\xbb\xbf"):
        return "utf-8-sig"
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return "utf-16"
    return None


def _charset_from_meta(data: bytes) -> str | None:
    head = data[:8192]
    for pat in (_META_CHARSET, _META_HTTP_EQUIV):
        m = pat.search(head)
        if m:
            return m.group(1).decode("ascii", "ignore").lower()
    return None


def normalize_charset(name: str | None) -> str | None:
    if not name:
        return None
    n = name.strip().lower().replace("_", "-")
    alias = {
        "gb2312": "gb18030", "gbk": "gb18030", "gb-2312": "gb18030",
        "iso-8859-1": "latin-1", "windows-1252": "cp1252",
        "utf8": "utf-8", "utf-8-sig": "utf-8-sig", "big5-hkscs": "big5hkscs",
        "x-gbk": "gb18030", "ansi": "gb18030",
    }
    return alias.get(n, n)


def mojibake_ratio(text: str) -> float:
    """粗略估计乱码程度：疑似 mojibake 字符 + 替换符 占非 ASCII 字符的比例。"""
    sample = text[:20000]
    if not sample:
        return 0.0
    non_ascii = [ch for ch in sample if ord(ch) > 127]
    if not non_ascii:
        return 0.0
    bad = sum(1 for ch in non_ascii if ch in _MOJIBAKE_CHARS or ch == "\ufffd")
    return bad / len(non_ascii)


def cjk_ratio(text: str) -> float:
    sample = text[:20000]
    if not sample:
        return 0.0
    cjk = sum(1 for ch in sample if "\u4e00" <= ch <= "\u9fff")
    return cjk / len(sample)


# 误解码后常见的"假中文"伴生字符：拉丁扩展、修饰符、私有区
_ODD_RANGES = ((0x0180, 0x024F), (0x02B0, 0x02FF), (0x0370, 0x1CFF),
               (0xE000, 0xF8FF), (0x3130, 0x318F))


# 现代汉语高频字（用于判别"看似成功但其实解错"的编码）。
# 正确解码的中文页面，绝大多数汉字落在这一小撮里；误解码会得到一堆生僻字。
_COMMON_CJK = frozenset(
    "的一是不了在人有我他这个们中来上大为和国地到以说时要就出会可也你对生能而子那得于着下自之年过发后作里用道行所然家种事成方多经么去法学如都同现当没动面起看定天分还进好小部其些主样理心她本前开但因只从想实日军者意无力它与长把机十民第公此已工使情明性知全三又关点正业外将两高间由问很最重并物手应战向头文体政美相见被利什二等产或新己制身果加西斯月话合回特代内信表化老给世位次度门任常先海通教儿原东声提立及比员解水名真论处走义各入几口认条平系气题活尔更别打女变四神总何电数安少报才结反受目太量再感建务做接必场件计管期市直德资命山金指克许统区保至队形社便空决治展马科司五基眼书非则听白却界达光放强即像难且权思王象完设式色路记南品住告类求据程北边死张该交规万取拉格望觉术领共确传师观清今切院让识候带导争运笑飞风步改收根干造言联持组每济车亲极林服快办议往元英士证近失转夫令准布始怎呼"
)


def common_cjk_ratio(text: str) -> float:
    sample = text[:20000]
    cjk = [ch for ch in sample if "\u4e00" <= ch <= "\u9fff"]
    if len(cjk) < 4:
        return 1.0
    return sum(1 for ch in cjk if ch in _COMMON_CJK) / len(cjk)


def _odd_ratio(text: str) -> float:
    sample = text[:20000]
    if not sample:
        return 0.0
    n = sum(1 for ch in sample
            if any(lo <= ord(ch) <= hi for lo, hi in _ODD_RANGES))
    return n / len(sample)


def _ascii_keep_ratio(text: str, data: bytes) -> float:
    """正确的中文解码会保留原始的 ASCII 字符（标签、逗号、数字）。

    把 GBK 字节按 UTF-16 解码同样不会报错，但 ASCII 结构会被整体吃掉，
    这个比值是识别这类"看似成功"的误解码最可靠的信号。
    """
    ascii_bytes = sum(1 for b in data[:20000] if b < 0x80)
    if ascii_bytes < 8:
        return 1.0
    ascii_chars = sum(1 for ch in text[:20000] if ord(ch) < 0x80)
    return min(ascii_chars / ascii_bytes, 1.0)


def _score_decode(text: str, data: bytes = b"") -> float:
    """给一种解码结果打分：中文越多越好；乱码、生僻字堆积、ASCII 结构丢失扣分。"""
    score = cjk_ratio(text) * 2.0
    score -= mojibake_ratio(text) * 3.0
    score -= (text.count("\ufffd") / max(len(text), 1)) * 5.0
    score -= _odd_ratio(text) * 4.0
    score += (common_cjk_ratio(text) - 0.5) * 2.0 * min(cjk_ratio(text) * 8, 1.0)
    if data:
        score -= (1.0 - _ascii_keep_ratio(text, data)) * 6.0
    return score


def decode_html(data: bytes, header_charset: str | None = None) -> DecodedText:
    """多路解码 + 打分选优。顺序：BOM > HTTP 头 > meta > 探测器 > 穷举。"""
    if not data:
        return DecodedText("", "utf-8", "empty", 0.0, 0.0, False)

    candidates: list[tuple[str, str]] = []
    bom = _charset_from_bom(data)
    if bom:
        candidates.append((bom, "bom"))
    hdr = normalize_charset(header_charset)
    if hdr:
        candidates.append((hdr, "http-header"))
    meta = normalize_charset(_charset_from_meta(data))
    if meta:
        candidates.append((meta, "meta"))
    try:  # charset_normalizer 有就用，没有不影响主流程
        from charset_normalizer import from_bytes
        best = from_bytes(data[:200000]).best()
        if best and best.encoding:
            candidates.append((normalize_charset(best.encoding) or best.encoding, "detector"))
    except Exception:
        pass
    for enc in CN_ENCODINGS:
        candidates.append((enc, "fallback"))

    best_result: DecodedText | None = None
    seen: set[str] = set()
    for enc, source in candidates:
        if not enc or enc in seen:
            continue
        seen.add(enc)
        try:
            text = data.decode(enc, errors="strict")
        except (UnicodeDecodeError, LookupError):
            continue
        mr = mojibake_ratio(text)
        result = DecodedText(text, enc, source, mr,
                             text.count("\ufffd") / max(len(text), 1),
                             mr < 0.05)
        # 声明来源可信、解码干净、且 ASCII 结构完好，直接采用
        if (source in ("bom", "http-header", "meta") and mr < 0.02
                and _ascii_keep_ratio(text, data) > 0.85 and _odd_ratio(text) < 0.05
                and common_cjk_ratio(text) > 0.35):
            return result
        if (best_result is None
                or _score_decode(text, data) > _score_decode(best_result.text, data)):
            best_result = result

    if best_result is None:  # 全部严格解码失败，容错解码
        text = data.decode("gb18030", errors="replace")
        alt = data.decode("utf-8", errors="replace")
        if _score_decode(alt, data) > _score_decode(text, data):
            text = alt
        mr = mojibake_ratio(text)
        best_result = DecodedText(text, "gb18030/utf-8(replace)", "fallback", mr,
                                  text.count("\ufffd") / max(len(text), 1), False)
    return best_result


# ------------------------------------------------------------------ 字体
def _is_pua(ch: str) -> bool:
    o = ord(ch)
    return any(lo <= o <= hi for lo, hi in _PUA_RANGES)


def inspect_fonts(html_text: str, visible_text: str | None = None) -> FontReport:
    """检测自定义字体反爬。

    判定依据：正文中出现私有区码位，或页面内嵌 base64 字体且正文有异常字符。
    只做标记，不擅自"猜"原文，避免把错误数据写进结果。
    """
    faces = _FONT_FACE.findall(html_text or "")
    urls: list[str] = []
    for f in faces:
        urls.extend(_FONT_SRC.findall(f))
    inline_b64 = bool(_BASE64_FONT.search(html_text or ""))

    probe = visible_text if visible_text is not None else html_text or ""
    sample = probe[:30000]
    pua = sum(1 for ch in sample if _is_pua(ch))
    ratio = pua / max(len(sample), 1)

    obfuscated = pua >= 3 or (inline_b64 and pua >= 1)
    if obfuscated:
        note = f"检测到私有区字符 {pua} 个，疑似自定义字体映射，文本不可直接采信"
    elif faces and inline_b64:
        note = "页面内嵌 base64 字体，但正文未见异常字符"
    elif faces:
        note = f"存在 {len(faces)} 处 @font-face，属常规网页字体"
    else:
        note = ""
    return FontReport(obfuscated, pua, ratio, len(faces), urls[:5], note)


# ------------------------------------------------------------------ 清洗
_ZERO_WIDTH = dict.fromkeys(map(ord, "\u200b\u200c\u200d\ufeff\u2060"), None)
_WS = re.compile(r"[ \t\u00a0\u3000]+")
_NL = re.compile(r"\n{3,}")


def clean_text(text: str) -> str:
    """统一全角半角、去零宽字符、压缩空白。让哈希去重更稳定。"""
    if not text:
        return ""
    t = html.unescape(text)
    t = unicodedata.normalize("NFKC", t)
    t = t.translate(_ZERO_WIDTH)
    t = t.replace("\r\n", "\n").replace("\r", "\n")
    t = _WS.sub(" ", t)
    t = "\n".join(line.strip() for line in t.split("\n"))
    return _NL.sub("\n\n", t).strip()


def text_fingerprint(text: str) -> str:
    """正文指纹，用于跨 URL 去重（中英文页面、移动版页面常常正文一致）。"""
    import hashlib
    body = re.sub(r"[^\w\u4e00-\u9fff]+", "", clean_text(text).lower())
    return hashlib.sha1(body[:20000].encode("utf-8")).hexdigest()


def simhash(text: str, bits: int = 64) -> int:
    """简易 SimHash，用于近似重复判断（阈值建议汉明距离 <= 3）。"""
    import hashlib
    tokens = re.findall(r"[\u4e00-\u9fff]{2}|[a-zA-Z0-9]+", clean_text(text).lower())
    if not tokens:
        return 0
    vec = [0] * bits
    for tok in tokens:
        h = int(hashlib.md5(tok.encode("utf-8")).hexdigest(), 16)
        for i in range(bits):
            vec[i] += 1 if (h >> i) & 1 else -1
    out = 0
    for i in range(bits):
        if vec[i] > 0:
            out |= 1 << i
    return out


def hamming(a: int, b: int) -> int:
    return bin(a ^ b).count("1")
