Tushare Token Validator - Windows Instructions

1. Extract the ZIP file completely.
2. Double-click start_web.bat.
3. On first launch, required Python packages will be installed.
4. Enter the token in the browser page.
5. Click the batch test button.

If start_web.bat does not work:

Open CMD in this folder and run:

    py -m pip install -r requirements_tushare_web.txt
    py -m streamlit run tushare_validator_web.py

If the "py" command is unavailable, use:

    python -m pip install -r requirements_tushare_web.txt
    python -m streamlit run tushare_validator_web.py

The local page is normally:

    http://localhost:8501
