@echo off
cd /d "%~dp0"
python -m streamlit run tushare_validator_web.py
pause
