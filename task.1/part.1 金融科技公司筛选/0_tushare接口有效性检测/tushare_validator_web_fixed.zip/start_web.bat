@echo off
setlocal
cd /d "%~dp0"
title Tushare Token Validator

where py >nul 2>nul
if not errorlevel 1 (
    set "PY_CMD=py"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo.
        echo ERROR: Python was not found.
        echo Install Python 3.9 or newer and enable "Add Python to PATH".
        echo.
        pause
        exit /b 1
    )
    set "PY_CMD=python"
)

echo.
echo Checking Python...
%PY_CMD% --version
if errorlevel 1 (
    echo.
    echo ERROR: Python cannot be started.
    pause
    exit /b 1
)

%PY_CMD% -c "import streamlit, requests, tushare, pandas" >nul 2>nul
if errorlevel 1 (
    echo.
    echo Installing required packages...
    %PY_CMD% -m pip install -r requirements_tushare_web.txt
    if errorlevel 1 (
        echo.
        echo ERROR: Package installation failed.
        echo Try this command manually:
        echo %PY_CMD% -m pip install -r requirements_tushare_web.txt
        echo.
        pause
        exit /b 1
    )
)

echo.
echo Starting the web page...
echo The browser should open automatically.
echo If it does not open, use the Local URL shown below.
echo Keep this window open while using the page.
echo.

%PY_CMD% -m streamlit run tushare_validator_web.py

echo.
echo The web page has stopped.
pause
endlocal
