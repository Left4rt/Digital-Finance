#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tushare Token 可视化检测页面

启动：
    python -m streamlit run tushare_validator_web.py

也可以在 Windows 上双击：
    启动可视化检测页面.bat
"""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any

import pandas as pd
import requests
import streamlit as st

from tushare_token_validator import (
    BUILTIN_TESTS,
    HARD_FAILURE_STATUSES,
    SUCCESS_STATUSES,
    RateLimiter,
    TestCase,
    TestResult,
    create_sdk_client,
    run_http_test,
    run_sdk_test,
)


DEFAULT_ENDPOINT = "https://ts.gyzcloud.top/api"

STATUS_LABELS = {
    "PASS": "正常",
    "EMPTY": "调用成功 / 空数据",
    "WARN_FIELDS": "成功 / 字段缺失",
    "AUTH_ERROR": "Token 鉴权失败",
    "PERMISSION_DENIED": "接口无权限",
    "RATE_LIMITED": "触发限频",
    "API_ERROR": "接口错误",
    "HTTP_ERROR": "网络或 HTTP 错误",
    "INVALID_JSON": "返回内容不是 JSON",
    "SCHEMA_ERROR": "返回结构异常",
    "SDK_ERROR": "SDK 错误",
}

STATUS_ICONS = {
    "PASS": "✅",
    "EMPTY": "🟡",
    "WARN_FIELDS": "🟠",
    "AUTH_ERROR": "🔴",
    "PERMISSION_DENIED": "🔒",
    "RATE_LIMITED": "⏱️",
    "API_ERROR": "❌",
    "HTTP_ERROR": "🌐",
    "INVALID_JSON": "📄",
    "SCHEMA_ERROR": "🧩",
    "SDK_ERROR": "🛠️",
}


def configure_page() -> None:
    st.set_page_config(
        page_title="Tushare Token 有效性检测",
        page_icon="🩺",
        layout="wide",
    )
    st.markdown(
        """
        <style>
        div[data-testid="stMetric"] {
            border: 1px solid rgba(128, 128, 128, 0.22);
            border-radius: 14px;
            padding: 12px 14px;
        }
        .small-note {
            opacity: 0.75;
            font-size: 0.9rem;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def token_fingerprint(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:12]


def result_to_display_row(result: TestResult) -> dict[str, Any]:
    return {
        "状态": f"{STATUS_ICONS.get(result.status, '•')} {STATUS_LABELS.get(result.status, result.status)}",
        "调用方式": result.mode.upper(),
        "分类": result.category,
        "测试项目": result.name,
        "接口": result.api_name,
        "返回行数": result.rows,
        "耗时(ms)": result.elapsed_ms,
        "HTTP状态": result.http_status,
        "API代码": result.api_code,
        "说明": result.message,
    }


def results_dataframe(results: list[TestResult]) -> pd.DataFrame:
    return pd.DataFrame([result_to_display_row(result) for result in results])


def build_report(results: list[TestResult], endpoint: str, rpm: int, token: str) -> dict[str, Any]:
    counts = Counter(result.status for result in results)
    successful = sum(result.status in SUCCESS_STATUSES for result in results)
    hard_failures = sum(result.status in HARD_FAILURE_STATUSES for result in results)
    auth_errors = sum(result.status == "AUTH_ERROR" for result in results)

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "endpoint": endpoint,
        "token_fingerprint_sha256": token_fingerprint(token),
        "requests_per_minute": rpm,
        "summary": {
            "total": len(results),
            "successful_calls": successful,
            "hard_failures": hard_failures,
            "token_valid": successful > 0 and auth_errors == 0,
            "status_counts": dict(counts),
        },
        "results": [asdict(result) for result in results],
    }


def show_summary(results: list[TestResult]) -> None:
    total = len(results)
    success = sum(result.status in SUCCESS_STATUSES for result in results)
    permission_denied = sum(result.status == "PERMISSION_DENIED" for result in results)
    failures = sum(result.status in HARD_FAILURE_STATUSES for result in results)
    avg_ms = round(sum(result.elapsed_ms for result in results) / total) if total else 0
    auth_error = any(result.status == "AUTH_ERROR" for result in results)

    if success > 0 and not auth_error:
        st.success("Token 至少成功调用了一个接口，综合判断为有效。")
    elif auth_error:
        st.error("检测到了 Token 鉴权失败。请检查 Token 是否正确、是否已过期。")
    else:
        st.warning("暂时无法确认 Token 有效性，请查看每个接口的错误说明。")

    cols = st.columns(4)
    cols[0].metric("成功调用", f"{success}/{total}")
    cols[1].metric("无权限接口", permission_denied)
    cols[2].metric("失败调用", failures)
    cols[3].metric("平均耗时", f"{avg_ms} ms")


def render_result_table(results: list[TestResult], key_prefix: str) -> None:
    if not results:
        return

    status_options = sorted({result.status for result in results})
    mode_options = sorted({result.mode.upper() for result in results})

    filter_cols = st.columns(2)
    selected_statuses = filter_cols[0].multiselect(
        "筛选状态",
        status_options,
        default=status_options,
        format_func=lambda value: STATUS_LABELS.get(value, value),
        key=f"{key_prefix}_status_filter",
    )
    selected_modes = filter_cols[1].multiselect(
        "筛选调用方式",
        mode_options,
        default=mode_options,
        key=f"{key_prefix}_mode_filter",
    )

    filtered = [
        result
        for result in results
        if result.status in selected_statuses and result.mode.upper() in selected_modes
    ]

    st.dataframe(
        results_dataframe(filtered),
        use_container_width=True,
        hide_index=True,
    )

    st.subheader("接口详情")
    for index, result in enumerate(filtered):
        title = (
            f"{STATUS_ICONS.get(result.status, '•')} "
            f"{result.api_name} · {result.mode.upper()} · "
            f"{STATUS_LABELS.get(result.status, result.status)}"
        )
        with st.expander(title, expanded=False):
            left, right = st.columns(2)
            left.write(f"**测试项目：** {result.name}")
            left.write(f"**分类：** {result.category}")
            left.write(f"**耗时：** {result.elapsed_ms} ms")
            right.write(f"**返回行数：** {result.rows if result.rows is not None else '-'}")
            right.write(f"**HTTP 状态：** {result.http_status if result.http_status is not None else '-'}")
            right.write(f"**API 代码：** {result.api_code if result.api_code is not None else '-'}")
            st.write(f"**说明：** {result.message}")

            if result.missing_fields:
                st.warning("缺少字段：" + ", ".join(result.missing_fields))
            if result.returned_fields:
                st.write("**返回字段：**")
                st.code(", ".join(result.returned_fields), language="text")
            if result.sample is not None:
                st.write("**第一条数据样例：**")
                st.json(result.sample)


def download_reports(results: list[TestResult], endpoint: str, rpm: int, token: str, key_prefix: str) -> None:
    if not results:
        return

    report = build_report(results, endpoint, rpm, token)
    table = results_dataframe(results)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_bytes = table.to_csv(index=False).encode("utf-8-sig")
    json_bytes = json.dumps(report, ensure_ascii=False, indent=2, default=str).encode("utf-8")

    cols = st.columns(2)
    cols[0].download_button(
        "下载 CSV 报告",
        data=csv_bytes,
        file_name=f"tushare_validation_{timestamp}.csv",
        mime="text/csv",
        use_container_width=True,
        key=f"{key_prefix}_download_csv",
    )
    cols[1].download_button(
        "下载 JSON 报告",
        data=json_bytes,
        file_name=f"tushare_validation_{timestamp}.json",
        mime="application/json",
        use_container_width=True,
        key=f"{key_prefix}_download_json",
    )


def run_batch(
    token: str,
    endpoint: str,
    modes: list[str],
    tests: list[TestCase],
    rpm: int,
    timeout: float,
    stop_on_auth_error: bool,
) -> list[TestResult]:
    results: list[TestResult] = []
    total_steps = len(modes) * len(tests)
    completed = 0

    progress = st.progress(0, text="准备检测…")
    current = st.empty()
    live_table = st.empty()

    limiter = RateLimiter(rpm)
    session = requests.Session()
    sdk_client = None

    if "sdk" in modes:
        try:
            sdk_client = create_sdk_client(token, endpoint)
        except Exception as exc:
            st.error(f"SDK 初始化失败：{exc}")
            modes = [mode for mode in modes if mode != "sdk"]

    for mode in modes:
        for test in tests:
            current.info(f"正在检测：{test.name}（{test.api_name} / {mode.upper()}）")

            if mode == "http":
                result = run_http_test(
                    session=session,
                    endpoint=endpoint,
                    token=token,
                    test=test,
                    timeout=timeout,
                    limiter=limiter,
                )
            else:
                result = run_sdk_test(
                    pro=sdk_client,
                    token=token,
                    test=test,
                    limiter=limiter,
                )

            results.append(result)
            completed += 1
            progress.progress(
                min(completed / max(total_steps, 1), 1.0),
                text=f"已完成 {completed}/{total_steps}",
            )
            live_table.dataframe(
                results_dataframe(results),
                use_container_width=True,
                hide_index=True,
            )

            if stop_on_auth_error and result.status == "AUTH_ERROR":
                current.error("检测到 Token 鉴权失败，已停止后续请求。")
                progress.progress(1.0, text="检测提前结束")
                return results

    current.success("检测完成。")
    progress.progress(1.0, text="检测完成")
    return results


def render_batch_tab(token: str, endpoint: str) -> None:
    st.subheader("批量接口检测")

    settings_left, settings_right = st.columns(2)
    mode_label = settings_left.radio(
        "调用方式",
        ["HTTP + SDK", "仅 HTTP", "仅 SDK"],
        horizontal=True,
    )
    suite_label = settings_right.radio(
        "测试范围",
        ["核心接口", "全部内置接口"],
        horizontal=True,
    )

    modes = {
        "HTTP + SDK": ["http", "sdk"],
        "仅 HTTP": ["http"],
        "仅 SDK": ["sdk"],
    }[mode_label]

    candidate_tests = (
        [test for test in BUILTIN_TESTS if test.core]
        if suite_label == "核心接口"
        else list(BUILTIN_TESTS)
    )

    categories = sorted({test.category for test in candidate_tests})
    selected_categories = st.multiselect(
        "接口分类",
        categories,
        default=categories,
    )
    visible_tests = [test for test in candidate_tests if test.category in selected_categories]

    selected_names = st.multiselect(
        "检测项目",
        options=[test.name for test in visible_tests],
        default=[test.name for test in visible_tests],
        help="可以取消不需要检测的项目。",
    )
    tests = [test for test in visible_tests if test.name in selected_names]

    advanced = st.expander("高级设置")
    with advanced:
        col1, col2, col3 = st.columns(3)
        rpm = col1.slider("每分钟最大请求数", min_value=10, max_value=150, value=120, step=10)
        timeout = col2.number_input("HTTP 超时（秒）", min_value=3.0, max_value=120.0, value=20.0, step=1.0)
        stop_on_auth_error = col3.checkbox("鉴权失败后停止", value=True)

    run_clicked = st.button(
        "开始批量检测",
        type="primary",
        use_container_width=True,
        disabled=not bool(tests),
    )

    if run_clicked:
        if not token:
            st.error("请先在页面上方输入 Token。")
        elif not endpoint:
            st.error("API 地址不能为空。")
        else:
            try:
                st.session_state["batch_results"] = run_batch(
                    token=token,
                    endpoint=endpoint,
                    modes=list(modes),
                    tests=tests,
                    rpm=int(rpm),
                    timeout=float(timeout),
                    stop_on_auth_error=stop_on_auth_error,
                )
                st.session_state["batch_rpm"] = int(rpm)
                st.session_state["batch_endpoint"] = endpoint
                st.session_state["batch_token_fp"] = token_fingerprint(token)
            except Exception as exc:
                st.exception(exc)

    results = st.session_state.get("batch_results", [])
    if results:
        st.divider()
        show_summary(results)
        render_result_table(results, "batch")
        download_reports(
            results,
            st.session_state.get("batch_endpoint", endpoint),
            st.session_state.get("batch_rpm", 120),
            token,
            "batch",
        )


def render_single_tab(token: str, endpoint: str) -> None:
    st.subheader("自定义单接口检测")
    st.caption("适合测试文档中的其他 api_name、参数和字段。")

    col1, col2 = st.columns(2)
    api_name = col1.text_input("API 名称", value="stock_basic")
    mode_label = col2.radio("调用方式", ["HTTP", "SDK"], horizontal=True, key="single_mode")

    params_text = st.text_area(
        "请求参数（JSON）",
        value='{"list_status": "L"}',
        height=120,
    )
    fields = st.text_input(
        "返回字段（逗号分隔）",
        value="ts_code,name,list_date",
    )

    settings = st.columns(2)
    rpm = settings[0].slider(
        "请求频率",
        min_value=10,
        max_value=150,
        value=120,
        step=10,
        key="single_rpm",
    )
    timeout = settings[1].number_input(
        "HTTP 超时（秒）",
        min_value=3.0,
        max_value=120.0,
        value=20.0,
        step=1.0,
        key="single_timeout",
    )

    if st.button("检测这个接口", type="primary", use_container_width=True):
        if not token:
            st.error("请先在页面上方输入 Token。")
            return
        if not api_name.strip():
            st.error("API 名称不能为空。")
            return

        try:
            params = json.loads(params_text or "{}")
            if not isinstance(params, dict):
                raise ValueError("请求参数必须是 JSON 对象，例如：{\"list_status\": \"L\"}")
        except (json.JSONDecodeError, ValueError) as exc:
            st.error(f"请求参数格式错误：{exc}")
            return

        test = TestCase(
            name=f"自定义：{api_name.strip()}",
            api_name=api_name.strip(),
            params=params,
            fields=fields.strip(),
            category="自定义",
            core=False,
        )
        limiter = RateLimiter(int(rpm))

        try:
            if mode_label == "HTTP":
                result = run_http_test(
                    session=requests.Session(),
                    endpoint=endpoint,
                    token=token,
                    test=test,
                    timeout=float(timeout),
                    limiter=limiter,
                )
            else:
                pro = create_sdk_client(token, endpoint)
                result = run_sdk_test(
                    pro=pro,
                    token=token,
                    test=test,
                    limiter=limiter,
                )
            st.session_state["single_results"] = [result]
        except Exception as exc:
            st.exception(exc)

    results = st.session_state.get("single_results", [])
    if results:
        st.divider()
        show_summary(results)
        render_result_table(results, "single")
        download_reports(results, endpoint, int(rpm), token, "single")


def render_help_tab() -> None:
    st.subheader("使用说明")
    st.markdown(
        """
        1. 在页面上方输入 Token。密码框不会直接显示明文。
        2. API 地址默认使用代理地址，一般不需要修改。
        3. 在“批量检测”中选择 HTTP、SDK 或两者同时检测。
        4. 第一次建议选择“核心接口”；正常后再检测全部接口。
        5. `正常` 表示接口成功返回数据；`调用成功 / 空数据` 也表示 Token 和接口调用链路正常。
        6. `接口无权限` 通常表示 Token 有效，但套餐没有开放该接口。
        7. `Token 鉴权失败` 表示需要检查 Token、有效期或服务商账号状态。
        """
    )
    st.info(
        "本地启动时，Token 仅用于当前检测请求，不会写入下载报告。"
        "报告只记录 Token 的 SHA-256 指纹前 12 位。"
    )


def main() -> None:
    configure_page()

    st.title("🩺 Tushare Token 有效性检测")
    st.write("批量验证 Token、代理地址、接口权限、返回字段和响应速度。")

    token_col, endpoint_col = st.columns([1, 1.4])
    token = token_col.text_input(
        "Token",
        type="password",
        placeholder="在此粘贴 Token",
        help="页面不会把明文 Token 写入检测报告。",
    )
    endpoint = endpoint_col.text_input(
        "API 地址",
        value=DEFAULT_ENDPOINT,
    )

    if token:
        st.caption(f"当前 Token 指纹：sha256:{token_fingerprint(token)}")
    else:
        st.caption("请输入 Token 后开始检测。")

    batch_tab, single_tab, help_tab = st.tabs(
        ["批量检测", "自定义接口", "使用说明"]
    )
    with batch_tab:
        render_batch_tab(token.strip(), endpoint.strip())
    with single_tab:
        render_single_tab(token.strip(), endpoint.strip())
    with help_tab:
        render_help_tab()


if __name__ == "__main__":
    main()
