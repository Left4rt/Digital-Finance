#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tushare Token / Proxy API 批量有效性检测工具

功能：
1. 同时支持 HTTP 直连和 Tushare Python SDK。
2. 批量测试股票、行情、指数、基金、财务等常用接口。
3. 区分 Token 无效、接口无权限、触发限频、空数据、字段异常等情况。
4. 自动限速，默认 120 次/分钟。
5. 输出 CSV 和 JSON 报告，不在报告中保存明文 Token。

安装：
    pip install requests tushare pandas

推荐用环境变量传入 Token：
    macOS / Linux:
        export TUSHARE_TOKEN="你的Token"

    Windows PowerShell:
        $env:TUSHARE_TOKEN="你的Token"

运行：
    python tushare_token_validator.py --mode both --suite core
    python tushare_token_validator.py --mode http --suite full
"""

from __future__ import annotations

import argparse
import csv
import getpass
import hashlib
import json
import os
import sys
import time
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Optional

import requests


DEFAULT_ENDPOINT = "https://ts.gyzcloud.top/api"


@dataclass(frozen=True)
class TestCase:
    name: str
    api_name: str
    params: dict[str, Any]
    fields: str
    category: str
    core: bool = False


@dataclass
class TestResult:
    mode: str
    name: str
    api_name: str
    category: str
    status: str
    ok: bool
    rows: Optional[int]
    elapsed_ms: int
    http_status: Optional[int]
    api_code: Optional[Any]
    message: str
    returned_fields: list[str]
    missing_fields: list[str]
    sample: Optional[dict[str, Any]]


BUILTIN_TESTS: list[TestCase] = [
    TestCase(
        name="A股基础列表",
        api_name="stock_basic",
        params={"list_status": "L"},
        fields="ts_code,name,list_date",
        category="股票基础",
        core=True,
    ),
    TestCase(
        name="交易日历",
        api_name="trade_cal",
        params={"exchange": "SSE", "start_date": "20240101", "end_date": "20240110"},
        fields="exchange,cal_date,is_open",
        category="股票基础",
        core=True,
    ),
    TestCase(
        name="A股日线",
        api_name="daily",
        params={"ts_code": "000001.SZ", "start_date": "20240102", "end_date": "20240131"},
        fields="ts_code,trade_date,close,vol",
        category="股票行情",
        core=True,
    ),
    TestCase(
        name="每日基本面指标",
        api_name="daily_basic",
        params={"ts_code": "000001.SZ", "start_date": "20240102", "end_date": "20240131"},
        fields="ts_code,trade_date,turnover_rate,total_mv",
        category="股票行情",
        core=True,
    ),
    TestCase(
        name="复权因子",
        api_name="adj_factor",
        params={"ts_code": "000001.SZ", "start_date": "20240102", "end_date": "20240131"},
        fields="ts_code,trade_date,adj_factor",
        category="股票行情",
        core=True,
    ),
    TestCase(
        name="指数基础信息",
        api_name="index_basic",
        params={"market": "SSE"},
        fields="ts_code,name,market,publisher",
        category="指数",
        core=True,
    ),
    TestCase(
        name="上证指数日线",
        api_name="index_daily",
        params={"ts_code": "000001.SH", "start_date": "20240102", "end_date": "20240131"},
        fields="ts_code,trade_date,close",
        category="指数",
        core=True,
    ),
    TestCase(
        name="场内基金列表",
        api_name="fund_basic",
        params={"market": "E", "status": "L"},
        fields="ts_code,name,management,list_date",
        category="基金",
        core=True,
    ),
    TestCase(
        name="ETF日线",
        api_name="fund_daily",
        params={"ts_code": "510300.SH", "start_date": "20240102", "end_date": "20240131"},
        fields="ts_code,trade_date,close",
        category="基金",
    ),
    TestCase(
        name="上市公司信息",
        api_name="stock_company",
        params={"exchange": "SSE"},
        fields="ts_code,chairman,manager,employees",
        category="股票基础",
    ),
    TestCase(
        name="IPO新股",
        api_name="new_share",
        params={"start_date": "20230101", "end_date": "20231231"},
        fields="ts_code,name,ipo_date,issue_date",
        category="股票基础",
    ),
    TestCase(
        name="股票曾用名",
        api_name="namechange",
        params={"ts_code": "000001.SZ"},
        fields="ts_code,name,start_date,end_date,change_reason",
        category="股票基础",
    ),
    TestCase(
        name="沪股通成分",
        api_name="hs_const",
        params={"hs_type": "SH"},
        fields="ts_code,hs_type,in_date,out_date,is_new",
        category="互联互通",
    ),
    TestCase(
        name="利润表",
        api_name="income",
        params={"ts_code": "000001.SZ", "period": "20231231"},
        fields="ts_code,ann_date,end_date,revenue,n_income",
        category="财务",
    ),
    TestCase(
        name="资产负债表",
        api_name="balancesheet",
        params={"ts_code": "000001.SZ", "period": "20231231"},
        fields="ts_code,ann_date,end_date,total_assets,total_liab",
        category="财务",
    ),
    TestCase(
        name="现金流量表",
        api_name="cashflow",
        params={"ts_code": "000001.SZ", "period": "20231231"},
        fields="ts_code,ann_date,end_date,n_cashflow_act",
        category="财务",
    ),
    TestCase(
        name="财务指标",
        api_name="fina_indicator",
        params={"ts_code": "000001.SZ", "period": "20231231"},
        fields="ts_code,ann_date,end_date,roe,netprofit_margin",
        category="财务",
    ),
    TestCase(
        name="个股资金流向",
        api_name="moneyflow",
        params={"ts_code": "000001.SZ", "start_date": "20240102", "end_date": "20240131"},
        fields="ts_code,trade_date,buy_sm_amount,sell_sm_amount",
        category="资金",
    ),
    TestCase(
        name="沪深300权重",
        api_name="index_weight",
        params={"index_code": "000300.SH", "start_date": "20240101", "end_date": "20240331"},
        fields="index_code,con_code,trade_date,weight",
        category="指数",
    ),
]


SUCCESS_STATUSES = {"PASS", "EMPTY", "WARN_FIELDS"}
HARD_FAILURE_STATUSES = {
    "AUTH_ERROR",
    "PERMISSION_DENIED",
    "RATE_LIMITED",
    "API_ERROR",
    "HTTP_ERROR",
    "INVALID_JSON",
    "SCHEMA_ERROR",
    "SDK_ERROR",
}


class RateLimiter:
    def __init__(self, requests_per_minute: int) -> None:
        if requests_per_minute <= 0:
            raise ValueError("requests_per_minute 必须大于 0")
        self.interval = 60.0 / requests_per_minute
        self._last_call: Optional[float] = None

    def wait(self) -> None:
        now = time.monotonic()
        if self._last_call is not None:
            sleep_for = self.interval - (now - self._last_call)
            if sleep_for > 0:
                time.sleep(sleep_for)
        self._last_call = time.monotonic()


def requested_fields(fields: str) -> list[str]:
    return [field.strip() for field in fields.split(",") if field.strip()]


def safe_message(value: Any, token: str, limit: int = 500) -> str:
    text = "" if value is None else str(value)
    if token:
        text = text.replace(token, "***TOKEN***")
    return text[:limit]


def classify_error(message: str) -> str:
    lowered = message.lower()

    auth_words = ("token", "认证", "鉴权", "invalid key", "非法用户", "无效用户")
    permission_words = ("权限", "permission", "积分", "未开通", "没有访问")
    rate_words = ("频率", "限频", "rate limit", "too many", "每分钟")

    if any(word in lowered for word in auth_words):
        return "AUTH_ERROR"
    if any(word in lowered for word in permission_words):
        return "PERMISSION_DENIED"
    if any(word in lowered for word in rate_words):
        return "RATE_LIMITED"
    return "API_ERROR"


def row_to_sample(fields: list[str], row: Any) -> Optional[dict[str, Any]]:
    if row is None:
        return None
    if isinstance(row, dict):
        return row
    if isinstance(row, (list, tuple)):
        return dict(zip(fields, row))
    return {"value": row}


def run_http_test(
    session: requests.Session,
    endpoint: str,
    token: str,
    test: TestCase,
    timeout: float,
    limiter: RateLimiter,
) -> TestResult:
    limiter.wait()
    started = time.perf_counter()
    payload = {
        "api_name": test.api_name,
        "token": token,
        "params": test.params,
        "fields": test.fields,
    }

    try:
        response = session.post(
            endpoint,
            json=payload,
            headers={
                "Accept": "application/json",
                "Accept-Encoding": "gzip",
                "User-Agent": "tushare-token-validator/1.0",
            },
            timeout=timeout,
        )
    except requests.RequestException as exc:
        elapsed = int((time.perf_counter() - started) * 1000)
        return TestResult(
            mode="http",
            name=test.name,
            api_name=test.api_name,
            category=test.category,
            status="HTTP_ERROR",
            ok=False,
            rows=None,
            elapsed_ms=elapsed,
            http_status=None,
            api_code=None,
            message=safe_message(exc, token),
            returned_fields=[],
            missing_fields=[],
            sample=None,
        )

    elapsed = int((time.perf_counter() - started) * 1000)

    if response.status_code != 200:
        return TestResult(
            mode="http",
            name=test.name,
            api_name=test.api_name,
            category=test.category,
            status="HTTP_ERROR",
            ok=False,
            rows=None,
            elapsed_ms=elapsed,
            http_status=response.status_code,
            api_code=None,
            message=safe_message(response.text, token),
            returned_fields=[],
            missing_fields=[],
            sample=None,
        )

    try:
        body = response.json()
    except ValueError:
        return TestResult(
            mode="http",
            name=test.name,
            api_name=test.api_name,
            category=test.category,
            status="INVALID_JSON",
            ok=False,
            rows=None,
            elapsed_ms=elapsed,
            http_status=response.status_code,
            api_code=None,
            message=safe_message(response.text, token),
            returned_fields=[],
            missing_fields=[],
            sample=None,
        )

    api_code = body.get("code")
    message = safe_message(body.get("msg", ""), token)

    code_is_success = api_code == 0 or str(api_code) == "0"
    if not code_is_success:
        status = classify_error(message)
        return TestResult(
            mode="http",
            name=test.name,
            api_name=test.api_name,
            category=test.category,
            status=status,
            ok=False,
            rows=None,
            elapsed_ms=elapsed,
            http_status=response.status_code,
            api_code=api_code,
            message=message,
            returned_fields=[],
            missing_fields=[],
            sample=None,
        )

    data = body.get("data")
    if not isinstance(data, dict):
        return TestResult(
            mode="http",
            name=test.name,
            api_name=test.api_name,
            category=test.category,
            status="SCHEMA_ERROR",
            ok=False,
            rows=None,
            elapsed_ms=elapsed,
            http_status=response.status_code,
            api_code=api_code,
            message="响应 code=0，但 data 不是对象",
            returned_fields=[],
            missing_fields=[],
            sample=None,
        )

    fields = data.get("fields") or []
    items = data.get("items") or []
    if not isinstance(fields, list) or not isinstance(items, list):
        return TestResult(
            mode="http",
            name=test.name,
            api_name=test.api_name,
            category=test.category,
            status="SCHEMA_ERROR",
            ok=False,
            rows=None,
            elapsed_ms=elapsed,
            http_status=response.status_code,
            api_code=api_code,
            message="data.fields 或 data.items 的类型异常",
            returned_fields=[],
            missing_fields=[],
            sample=None,
        )

    wanted = requested_fields(test.fields)
    missing = [field for field in wanted if field not in fields]
    rows = len(items)

    if missing:
        status = "WARN_FIELDS"
        result_message = f"调用成功，但缺少字段: {', '.join(missing)}"
    elif rows == 0:
        status = "EMPTY"
        result_message = "调用成功，但当前测试条件未返回记录"
    else:
        status = "PASS"
        result_message = "调用成功并返回数据"

    return TestResult(
        mode="http",
        name=test.name,
        api_name=test.api_name,
        category=test.category,
        status=status,
        ok=True,
        rows=rows,
        elapsed_ms=elapsed,
        http_status=response.status_code,
        api_code=api_code,
        message=result_message,
        returned_fields=[str(x) for x in fields],
        missing_fields=missing,
        sample=row_to_sample(fields, items[0]) if items else None,
    )


def create_sdk_client(token: str, endpoint: str) -> Any:
    try:
        import tushare as ts
    except ImportError as exc:
        raise RuntimeError("未安装 tushare，请运行: pip install tushare pandas") from exc

    # 直接传入 token，避免调用 ts.set_token() 将明文 Token 持久化到本地配置。
    pro = ts.pro_api(token)
    pro._DataApi__http_url = endpoint
    return pro


def run_sdk_test(
    pro: Any,
    token: str,
    test: TestCase,
    limiter: RateLimiter,
) -> TestResult:
    limiter.wait()
    started = time.perf_counter()

    try:
        frame = pro.query(test.api_name, fields=test.fields, **test.params)
    except Exception as exc:  # SDK 会将服务端错误包装成不同异常类型
        elapsed = int((time.perf_counter() - started) * 1000)
        message = safe_message(exc, token)
        status = classify_error(message)
        if status == "API_ERROR":
            status = "SDK_ERROR"
        return TestResult(
            mode="sdk",
            name=test.name,
            api_name=test.api_name,
            category=test.category,
            status=status,
            ok=False,
            rows=None,
            elapsed_ms=elapsed,
            http_status=None,
            api_code=None,
            message=message,
            returned_fields=[],
            missing_fields=[],
            sample=None,
        )

    elapsed = int((time.perf_counter() - started) * 1000)

    if frame is None or not hasattr(frame, "columns"):
        return TestResult(
            mode="sdk",
            name=test.name,
            api_name=test.api_name,
            category=test.category,
            status="SCHEMA_ERROR",
            ok=False,
            rows=None,
            elapsed_ms=elapsed,
            http_status=None,
            api_code=0,
            message="SDK 未返回 DataFrame",
            returned_fields=[],
            missing_fields=[],
            sample=None,
        )

    columns = [str(column) for column in frame.columns]
    wanted = requested_fields(test.fields)
    missing = [field for field in wanted if field not in columns]
    rows = int(len(frame))

    if missing:
        status = "WARN_FIELDS"
        message = f"调用成功，但缺少字段: {', '.join(missing)}"
    elif rows == 0:
        status = "EMPTY"
        message = "调用成功，但当前测试条件未返回记录"
    else:
        status = "PASS"
        message = "调用成功并返回数据"

    sample: Optional[dict[str, Any]] = None
    if rows:
        first = frame.iloc[0].to_dict()
        sample = {
            str(key): (None if _is_null(value) else _json_safe(value))
            for key, value in first.items()
        }

    return TestResult(
        mode="sdk",
        name=test.name,
        api_name=test.api_name,
        category=test.category,
        status=status,
        ok=True,
        rows=rows,
        elapsed_ms=elapsed,
        http_status=None,
        api_code=0,
        message=message,
        returned_fields=columns,
        missing_fields=missing,
        sample=sample,
    )


def _is_null(value: Any) -> bool:
    try:
        import pandas as pd
        result = pd.isna(value)
        return bool(result) if not hasattr(result, "__len__") else False
    except Exception:
        return value is None


def _json_safe(value: Any) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if hasattr(value, "item"):
        try:
            return value.item()
        except Exception:
            pass
    if hasattr(value, "isoformat"):
        try:
            return value.isoformat()
        except Exception:
            pass
    return str(value)


def load_custom_tests(path: Path) -> list[TestCase]:
    with path.open("r", encoding="utf-8") as file:
        raw = json.load(file)

    if not isinstance(raw, list):
        raise ValueError("自定义测试文件顶层必须是 JSON 数组")

    tests: list[TestCase] = []
    for index, item in enumerate(raw, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"第 {index} 项不是 JSON 对象")
        try:
            tests.append(
                TestCase(
                    name=str(item["name"]),
                    api_name=str(item["api_name"]),
                    params=dict(item.get("params", {})),
                    fields=str(item.get("fields", "")),
                    category=str(item.get("category", "自定义")),
                    core=bool(item.get("core", False)),
                )
            )
        except KeyError as exc:
            raise ValueError(f"第 {index} 项缺少字段: {exc}") from exc
    return tests


def select_tests(
    suite: str,
    only: Optional[str],
    custom_tests: Optional[Path],
) -> list[TestCase]:
    tests = load_custom_tests(custom_tests) if custom_tests else list(BUILTIN_TESTS)

    if suite == "core":
        tests = [test for test in tests if test.core]

    if only:
        names = {part.strip() for part in only.split(",") if part.strip()}
        tests = [
            test for test in tests
            if test.api_name in names or test.name in names or test.category in names
        ]

    if not tests:
        raise ValueError("没有匹配到任何测试项")
    return tests


def print_result(result: TestResult) -> None:
    rows = "-" if result.rows is None else str(result.rows)
    print(
        f"[{result.mode.upper():4}] "
        f"{result.status:17} "
        f"{result.elapsed_ms:6} ms "
        f"rows={rows:>5}  "
        f"{result.api_name:<18} "
        f"{result.name}"
    )
    if not result.ok:
        print(f"       └─ {result.message}")


def write_reports(
    results: list[TestResult],
    output_dir: Path,
    endpoint: str,
    token_fingerprint: str,
    rpm: int,
) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = output_dir / f"tushare_validation_{stamp}.csv"
    json_path = output_dir / f"tushare_validation_{stamp}.json"

    csv_fields = [
        "mode", "name", "api_name", "category", "status", "ok", "rows",
        "elapsed_ms", "http_status", "api_code", "message",
        "returned_fields", "missing_fields", "sample",
    ]
    with csv_path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=csv_fields)
        writer.writeheader()
        for result in results:
            row = asdict(result)
            row["returned_fields"] = ",".join(result.returned_fields)
            row["missing_fields"] = ",".join(result.missing_fields)
            row["sample"] = json.dumps(result.sample, ensure_ascii=False, default=str)
            writer.writerow(row)

    status_counts = Counter(result.status for result in results)
    successful = sum(result.status in SUCCESS_STATUSES for result in results)
    auth_errors = sum(result.status == "AUTH_ERROR" for result in results)
    token_valid = successful > 0 and auth_errors == 0

    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "endpoint": endpoint,
        "token_fingerprint_sha256": token_fingerprint,
        "requests_per_minute": rpm,
        "summary": {
            "total": len(results),
            "successful_calls": successful,
            "hard_failures": sum(result.status in HARD_FAILURE_STATUSES for result in results),
            "token_valid": token_valid,
            "status_counts": dict(status_counts),
        },
        "results": [asdict(result) for result in results],
    }
    with json_path.open("w", encoding="utf-8") as file:
        json.dump(report, file, ensure_ascii=False, indent=2, default=str)

    return csv_path, json_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="批量检验 Tushare Token、代理接口、权限和数据返回情况"
    )
    parser.add_argument(
        "--endpoint",
        default=DEFAULT_ENDPOINT,
        help=f"API 地址，默认: {DEFAULT_ENDPOINT}",
    )
    parser.add_argument(
        "--mode",
        choices=("http", "sdk", "both"),
        default="both",
        help="检测方式，默认 both",
    )
    parser.add_argument(
        "--suite",
        choices=("core", "full"),
        default="core",
        help="core 测试常用接口；full 测试全部内置接口",
    )
    parser.add_argument(
        "--rpm",
        type=int,
        default=120,
        help="每分钟最多请求次数，默认 120",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=20.0,
        help="HTTP 单次超时秒数，默认 20",
    )
    parser.add_argument(
        "--only",
        help="只测指定接口名、测试名或分类，多个值用逗号分隔",
    )
    parser.add_argument(
        "--tests-file",
        type=Path,
        help="自定义测试项 JSON 文件；使用后替代内置测试项",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("tushare_validation_reports"),
        help="报告目录，默认 tushare_validation_reports",
    )
    parser.add_argument(
        "--no-fail-fast-auth",
        action="store_true",
        help="即使检测到 Token 鉴权失败，也继续执行后续接口",
    )
    return parser


def obtain_token() -> str:
    token = os.getenv("TUSHARE_TOKEN", "").strip()
    if not token:
        token = getpass.getpass("请输入 TUSHARE_TOKEN（输入内容不会回显）: ").strip()
    if not token:
        raise ValueError("Token 不能为空")
    return token


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.rpm <= 0:
        parser.error("--rpm 必须大于 0")
    if args.rpm > 150:
        parser.error("--rpm 不应高于套餐限制 150；建议设置为 120～140")
    if args.timeout <= 0:
        parser.error("--timeout 必须大于 0")

    try:
        token = obtain_token()
        tests = select_tests(args.suite, args.only, args.tests_file)
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        print(f"配置错误: {exc}", file=sys.stderr)
        return 2

    fingerprint = hashlib.sha256(token.encode("utf-8")).hexdigest()[:12]
    modes = ["http", "sdk"] if args.mode == "both" else [args.mode]
    limiter = RateLimiter(args.rpm)
    results: list[TestResult] = []

    print("=" * 92)
    print("Tushare Token / API 有效性检测")
    print(f"Endpoint : {args.endpoint}")
    print(f"Token ID : sha256:{fingerprint}（不显示明文）")
    print(f"模式     : {', '.join(modes)}")
    print(f"测试项   : {len(tests)}")
    print(f"限速     : {args.rpm} 次/分钟")
    print("=" * 92)

    session = requests.Session()
    pro = None
    if "sdk" in modes:
        try:
            pro = create_sdk_client(token, args.endpoint)
        except RuntimeError as exc:
            print(f"SDK 初始化失败: {safe_message(exc, token)}", file=sys.stderr)
            if modes == ["sdk"]:
                return 2
            modes.remove("sdk")

    fail_fast_auth = not args.no_fail_fast_auth

    for mode in modes:
        print(f"\n--- {mode.upper()} 检测 ---")
        for test in tests:
            if mode == "http":
                result = run_http_test(
                    session=session,
                    endpoint=args.endpoint,
                    token=token,
                    test=test,
                    timeout=args.timeout,
                    limiter=limiter,
                )
            else:
                result = run_sdk_test(
                    pro=pro,
                    token=token,
                    test=test,
                    limiter=limiter,
                )

            results.append(result)
            print_result(result)

            if fail_fast_auth and result.status == "AUTH_ERROR":
                print("检测到 Token 鉴权失败，已停止当前模式的后续请求。")
                break

    csv_path, json_path = write_reports(
        results=results,
        output_dir=args.output_dir,
        endpoint=args.endpoint,
        token_fingerprint=fingerprint,
        rpm=args.rpm,
    )

    counts = Counter(result.status for result in results)
    successful = sum(result.status in SUCCESS_STATUSES for result in results)
    auth_errors = sum(result.status == "AUTH_ERROR" for result in results)
    token_valid = successful > 0 and auth_errors == 0

    print("\n" + "=" * 92)
    print(f"Token 综合判定 : {'有效' if token_valid else '无法确认或无效'}")
    print(f"成功调用       : {successful}/{len(results)}")
    print("状态统计       : " + ", ".join(f"{key}={value}" for key, value in counts.items()))
    print(f"CSV 报告       : {csv_path.resolve()}")
    print(f"JSON 报告      : {json_path.resolve()}")
    print("=" * 92)

    hard_failures = [r for r in results if r.status in HARD_FAILURE_STATUSES]
    return 2 if hard_failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
