#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
用 DeepSeek（OpenAI 兼容接口）把「股票代码 + 简称」解析成上市公司**工商登记全称**，
并核对是否为上市公司。全称会作为别名加入匹配，显著提升 BOSS 抓取的准确率。

- 网络请求用 requests（项目已依赖）。
- 结果按股票代码缓存到本地 JSON，重复运行零额外调用。
- 请求构造 / 响应解析 / 缓存这些纯逻辑不依赖网络，可离线单测。

DeepSeek 接口：POST {base_url}/chat/completions ，与 OpenAI 格式一致。
默认 base_url=https://api.deepseek.com ，model=deepseek-chat 。
"""

from __future__ import annotations

import json
import os
import re
import time

DEFAULT_BASE_URL = "https://api.deepseek.com"
DEFAULT_MODEL = "deepseek-chat"
DEFAULT_CACHE_NAME = "deepseek_company_cache.json"

_SYSTEM_PROMPT = (
    "你是中国A股上市公司信息助手。用户给出股票代码和简称，"
    "你需要返回该证券对应主体的工商登记全称、18位统一社会信用代码，并判断它当前是否为A股上市公司。"
    "统一社会信用代码必须准确，不确定就留空，绝不编造。只输出一个 JSON 对象，不要多余文字。"
)


def build_prompt(ts_code, name):
    """构造给 DeepSeek 的用户消息。要求严格 JSON 输出。"""
    return (
        f"股票代码：{ts_code}\n"
        f"简称：{name}\n\n"
        "请返回如下 JSON（字段务必齐全）：\n"
        '{"full_name": "工商登记全称", "uscc": "统一社会信用代码(18位)", '
        '"is_listed": true, "short_name": "常用简称", '
        '"note": "如招聘主体与上市主体不同请在此说明"}\n'
        "要求：full_name 用规范的公司全称（含“股份有限公司”等）；"
        "uscc 为该上市主体的 18 位统一社会信用代码，若不确定则留空字符串，切勿编造；"
        "若该代码并非A股上市公司或无法确认，is_listed 置为 false。"
        "只输出 JSON。"
    )


def parse_response_content(content):
    """从模型返回文本里稳健地解析出 JSON 对象。

    兼容:
      - 直接就是 JSON
      - 被 ```json ... ``` 代码块包裹
      - 前后有额外说明文字（取第一个 { 到最后一个 }）
    返回 dict；解析失败返回 {}。
    """
    if not content:
        return {}
    text = str(content).strip()
    # 去掉 ``` 代码块围栏
    text = re.sub(r"^```[a-zA-Z]*\s*", "", text)
    text = re.sub(r"\s*```$", "", text).strip()
    # 先直接试
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except (json.JSONDecodeError, ValueError):
        pass
    # 再截取第一个 { 到最后一个 }
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        snippet = text[start:end + 1]
        try:
            obj = json.loads(snippet)
            if isinstance(obj, dict):
                return obj
        except (json.JSONDecodeError, ValueError):
            return {}
    return {}


def normalize_resolution(obj):
    """把解析出的原始 dict 规整成统一结构。"""
    full_name = str(obj.get("full_name") or "").strip()
    short_name = str(obj.get("short_name") or "").strip()
    note = str(obj.get("note") or "").strip()
    uscc = re.sub(r"\s+", "", str(obj.get("uscc") or "")).upper()
    # 只保留看起来像 18 位 USCC 的值，否则置空（避免把说明文字当成代码）
    if uscc and not re.fullmatch(r"[0-9A-Z]{18}", uscc):
        uscc = ""
    is_listed = obj.get("is_listed")
    if isinstance(is_listed, str):
        is_listed = is_listed.strip().lower() in {"true", "1", "yes", "是"}
    is_listed = bool(is_listed)
    return {
        "full_name": full_name,
        "short_name": short_name,
        "uscc": uscc,
        "is_listed": is_listed,
        "note": note,
    }


class DeepSeekClient:
    """极简 DeepSeek 客户端（OpenAI 兼容 chat/completions）。"""

    def __init__(self, api_key, base_url=DEFAULT_BASE_URL, model=DEFAULT_MODEL, timeout=40):
        if not api_key or not str(api_key).strip():
            raise ValueError("缺少 DeepSeek API Key")
        self.api_key = str(api_key).strip()
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.model = model or DEFAULT_MODEL
        self.timeout = timeout
        import requests  # 延迟导入，缺依赖时给清晰报错
        self._requests = requests

    def _endpoint(self):
        return f"{self.base_url}/chat/completions"

    def chat(self, system, user):
        """发一次对话，返回模型文本内容。失败抛异常。"""
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": 0,
            "stream": False,
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        resp = self._requests.post(self._endpoint(), headers=headers,
                                   json=payload, timeout=self.timeout)
        if resp.status_code != 200:
            raise RuntimeError(f"DeepSeek HTTP {resp.status_code}: {resp.text[:200]}")
        data = resp.json()
        return data["choices"][0]["message"]["content"]

    def resolve_company(self, ts_code, name):
        """解析单家公司，返回规整后的 dict。"""
        content = self.chat(_SYSTEM_PROMPT, build_prompt(ts_code, name))
        return normalize_resolution(parse_response_content(content))


# ============================================================
# 缓存
# ============================================================
def load_cache(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError, ValueError):
        return {}


def save_cache(path, cache):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)


def _apply_resolution_to_company(company, res):
    """把解析结果写回 company：登记 official_name / is_listed / uscc，并把全称加入别名。

    若 company 已带 uscc（来自 CSV，权威度更高），则保留 CSV 的，不被 DeepSeek 覆盖。
    """
    company["official_name"] = res.get("full_name", "")
    company["is_listed"] = res.get("is_listed", False)
    if not (company.get("uscc_expected") or "").strip():
        company["uscc_expected"] = res.get("uscc", "")
    aliases = list(company.get("aliases", []))
    for extra in (res.get("full_name"), res.get("short_name")):
        extra = (extra or "").strip()
        if extra and extra not in aliases and extra != company.get("name"):
            aliases.append(extra)
    company["aliases"] = aliases
    return company


def resolve_companies(companies, client, cache_path=None, log=print,
                      stop_flag=None, sleep_between=0.4):
    """给每家公司解析上市全称（带缓存），就地更新 companies。

    Args:
        companies: load_company_csv 的结果（list[dict]）
        client: DeepSeekClient（或任何有 resolve_company(ts_code, name) 的对象）
        cache_path: 缓存 JSON 路径（按 ts_code 缓存），None 则不缓存
    Returns: 统计 dict {done, listed, from_cache, failed}
    """
    cache = load_cache(cache_path) if cache_path else {}
    stats = {"done": 0, "listed": 0, "from_cache": 0, "failed": 0}

    for i, company in enumerate(companies, 1):
        if stop_flag is not None and stop_flag():
            log("DeepSeek 核对已中止。")
            break
        ts_code = company.get("ts_code", "")
        name = company.get("name", "")
        key = ts_code or name

        if key in cache and cache[key].get("full_name"):
            res = cache[key]
            stats["from_cache"] += 1
        else:
            try:
                res = client.resolve_company(ts_code, name)
            except Exception as e:  # noqa: BLE001
                log(f"  [{i}/{len(companies)}] {name} 解析失败：{e}")
                stats["failed"] += 1
                continue
            if key:
                cache[key] = res
                if cache_path:
                    save_cache(cache_path, cache)
            if sleep_between:
                time.sleep(sleep_between)

        _apply_resolution_to_company(company, res)
        stats["done"] += 1
        if res.get("is_listed"):
            stats["listed"] += 1
        flag = "上市" if res.get("is_listed") else "非上市/未确认"
        uscc_show = res.get("uscc") or "USCC未知"
        log(f"  [{i}/{len(companies)}] {name} → {res.get('full_name','(空)')}  [{flag}] {uscc_show}")

    log(f"DeepSeek 核对完成：处理 {stats['done']} 家（其中缓存命中 {stats['from_cache']}），"
        f"确认上市 {stats['listed']} 家，失败 {stats['failed']} 家。")
    return stats
