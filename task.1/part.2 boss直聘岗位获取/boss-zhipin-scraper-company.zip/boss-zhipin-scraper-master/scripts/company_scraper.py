#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
按「股票代码 + 公司名/别名」批量抓取 BOSS直聘岗位（含岗位描述全文）。

设计目标
--------
1. 输入一份 CSV（列：ts_code, name，可选 alias/别名），逐个公司抓取其在招岗位。
2. 复用 boss_cdp_raw.py 的 Chrome CDP 登录态 + 明文 API，绕过字体反爬。
3. 用公司名作为搜索词，再按 brandName（公司名/别名）过滤，只保留目标公司的岗位。
4. 进入每个岗位详情页抓取「岗位描述」全文，并与列表字段合并成一整行。
5. 导出一个包含全部所需字段的宽表 CSV（UTF-8-SIG，Excel 可直接打开）。

本模块把「纯逻辑」（CSV 解析 / 品牌匹配 / 记录合并 / CSV 导出）与「联网抓取」分开，
纯逻辑部分不依赖 Chrome / requests / websocket，可离线单元测试。

命令行用法
----------
  python3 scripts/company_scraper.py --companies companies.csv --city 全国 \
      --pages-per-company 3 --max-jobs-per-company 30 \
      --output ~/.boss-zhipin-scraper/job-result/company_jobs.csv
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import random
import re
import sys
import time
from datetime import datetime

# 让本文件既能作为脚本运行，也能被 GUI 以模块方式导入
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import boss_cdp_raw as boss  # noqa: E402

# ============================================================
# 常量
# ============================================================

# BOSS「全国」城市码（常用值；如个别接口不认，可在界面改用具体城市）
NATIONWIDE_CITY_CODE = "100010000"
NATIONWIDE_ALIASES = {"全国", "全国范围", "不限", "all", "nationwide"}

# 搜索接口每页条数与安全翻页上限（BOSS 搜索结果本身有上限，翻到底即止）
PAGE_SIZE = 30
SEARCH_HARD_MAX_PAGES = 20

# 「全国遍历」模式用的主要城市——只给名字，运行时用 resolve_city 转成城市码，
# 避免硬编码可能出错的数字码。可按需增删。
MAJOR_CITY_NAMES = [
    "北京", "上海", "广州", "深圳", "杭州", "成都", "南京", "武汉", "西安", "苏州",
    "天津", "重庆", "长沙", "郑州", "青岛", "宁波", "厦门", "福州", "济南", "合肥",
]

# 导出的宽表列（顺序即 CSV 列顺序）
COMPANY_CSV_COLUMNS = [
    "ts_code",          # 股票代码（来自输入 CSV）
    "query_name",       # 用于搜索/匹配的公司名（来自输入 CSV 的 name）
    "official_name",    # 上市公司工商全称（DeepSeek 核对，可空）
    "is_listed",        # 是否核对为上市公司（DeepSeek，可空）
    "uscc_expected",    # 期望的统一社会信用代码（DeepSeek/CSV）
    "uscc_scraped",     # 从公司页抓到的统一社会信用代码
    "name_verify",      # 名称核验：一致/不一致/无参考
    "uscc_verify",      # USCC核验：一致/不一致/页面无代码/无参考
    "verify_status",    # 三重核验综合结论
    "is_dispatch",      # 是否劳务派遣/外包
    "dispatch_reason",  # 判定为派遣的依据
    "matched_brand",    # BOSS 上实际命中的公司名（brandName）
    "title",            # 招聘标题
    "salary",           # 薪资（明文）
    "location",         # 工作地点
    "company_name",     # 公司名称（= matched_brand，冗余一列便于阅读）
    "company_scale",    # 公司人数 / 规模
    "company_stage",    # 融资阶段
    "company_industry", # 公司类型 / 行业
    "experience",       # 经验要求
    "degree",           # 学历要求
    "skills",           # 所需技能（列表技能 + 详情页技能标签，去重合并）
    "welfare",          # 工作福利
    "jd",               # 岗位描述（全文）
    "job_link",         # 招聘链接
    "company_link",     # 公司主页链接
    "salary_source",    # 薪资来源（api=明文）
    "scraped_at",       # 抓取时间
]

# 公司名归一化时可剥离的常见后缀（仅用于「严格匹配」模式）
COMPANY_SUFFIXES = [
    "股份有限公司", "有限责任公司", "有限公司", "集团股份", "控股集团",
    "集团", "股份", "控股", "公司", "(中国)", "（中国）",
]


# ============================================================
# 纯逻辑：输入 CSV 解析
# ============================================================
def _pick_column(fieldnames, candidates):
    """在表头里找第一个匹配的列名（大小写/空白不敏感）。"""
    if not fieldnames:
        return None
    norm = {(f or "").strip().lower(): f for f in fieldnames}
    for cand in candidates:
        key = cand.strip().lower()
        if key in norm:
            return norm[key]
    # 再做一次「包含」匹配，兼容 "证券代码"/"公司名称" 等
    for raw in fieldnames:
        low = (raw or "").strip().lower()
        for cand in candidates:
            if cand.strip().lower() in low:
                return raw
    return None


def _split_aliases(raw):
    """把别名字段拆成列表，支持 ; ； | 、 , ， 空格 分隔。"""
    if not raw:
        return []
    parts = re.split(r"[;；|、,，\s]+", str(raw).strip())
    return [p for p in (x.strip() for x in parts) if p]


# 依次尝试的编码。UTF-8 先试（严格，遇到非 UTF-8 字节会报错），
# 失败再退到中文常见编码。gb18030 是 gbk/gb2312 的超集，能覆盖绝大多数
# 用 Excel「另存为 CSV」得到的中文文件。
_CANDIDATE_ENCODINGS = ["utf-8-sig", "utf-8", "gb18030", "gbk", "big5"]


def _read_text_auto_encoding(path):
    """按字节读入并自动判定编码，返回 (文本, 使用的编码)。

    关键在顺序：先用 UTF-8「严格模式」解码，只有当文件确实不是 UTF-8
    （抛 UnicodeDecodeError）时才回退到 gb18030 等中文编码——因为 gb18030
    对任意字节都能“解出来”，若放前面会把 UTF-8 文件解成乱码。
    """
    with open(path, "rb") as f:
        raw = f.read()
    last_err = None
    for enc in _CANDIDATE_ENCODINGS:
        try:
            return raw.decode(enc), enc
        except (UnicodeDecodeError, LookupError) as e:
            last_err = e
            continue
    # 兜底：用 utf-8 替换非法字节，至少不崩（可能有个别乱码字符）
    return raw.decode("utf-8", errors="replace"), "utf-8(replace)"


def _make_reader(text):
    """根据内容猜测分隔符（逗号/制表符），返回 csv.DictReader。"""
    import io
    sample = text[:4096]
    delimiter = "\t" if sample.count("\t") > sample.count(",") else ","
    return csv.DictReader(io.StringIO(text), delimiter=delimiter)


def load_company_csv(path):
    """读取公司清单 CSV（自动识别 UTF-8 / GBK / GB18030 / BIG5 编码）。

    识别的列（大小写/中英文均可）：
      - 股票代码: ts_code / code / 股票代码 / 证券代码 / symbol
      - 公司名  : name / 公司名 / 公司名称 / 名称
      - 别名(可选): alias / aliases / 别名 / 品牌别名 / brand
    别名可用 ; ； | 、 , 空格 等分隔，多个别名都会参与匹配。

    返回: list[dict]，每项 {"ts_code", "name", "aliases": [...]}。
    另在返回列表上挂 .encoding 属性，便于界面/日志显示实际用了哪种编码。
    """
    text, encoding = _read_text_auto_encoding(path)
    reader = _make_reader(text)
    fields = reader.fieldnames or []
    code_col = _pick_column(fields, ["ts_code", "code", "股票代码", "证券代码", "symbol"])
    name_col = _pick_column(fields, ["name", "公司名称", "公司名", "名称", "brand_name"])
    alias_col = _pick_column(fields, ["alias", "aliases", "别名", "品牌别名", "brand", "简称"])
    uscc_col = _pick_column(fields, ["uscc", "统一社会信用代码", "信用代码", "社会信用代码"])

    if name_col is None:
        raise ValueError(
            f"输入 CSV 缺少公司名列（编码判定为 {encoding}）。识别到的表头为: {fields}\n"
            "请确保有一列名为 name / 公司名 / 公司名称"
        )

    companies = []
    seen = set()
    for row in reader:
        name = (row.get(name_col) or "").strip()
        if not name:
            continue
        ts_code = (row.get(code_col) or "").strip() if code_col else ""
        aliases = _split_aliases(row.get(alias_col)) if alias_col else []
        uscc = (row.get(uscc_col) or "").strip().upper() if uscc_col else ""
        key = (ts_code, name)
        if key in seen:
            continue
        seen.add(key)
        item = {"ts_code": ts_code, "name": name, "aliases": aliases}
        if uscc:
            item["uscc_expected"] = uscc
        companies.append(item)

    try:
        companies = _CompanyList(companies)
        companies.encoding = encoding
    except Exception:  # noqa: BLE001
        pass
    return companies


class _CompanyList(list):
    """带 .encoding 属性的普通 list，便于外部知道实际用的编码。"""
    encoding = "utf-8-sig"


# ============================================================
# 纯逻辑：品牌名匹配
# ============================================================
def _normalize_name(s):
    """归一化公司名：去空白、统一大小写、全角括号转半角。"""
    if not s:
        return ""
    s = str(s).strip().lower()
    s = s.replace("（", "(").replace("）", ")")
    s = re.sub(r"\s+", "", s)
    return s


def _strip_suffix(s):
    """剥离常见公司后缀，用于严格匹配。"""
    out = s
    for suf in COMPANY_SUFFIXES:
        out = out.replace(_normalize_name(suf), "")
    return out


def brand_matches(brand_name, targets, strict=False):
    """判断某岗位的 brandName 是否属于目标公司。

    Args:
        brand_name: 岗位所属公司名（BOSS 的 brandName）
        targets:    公司名 + 别名列表
        strict:     True 时用「剥后缀后完全相等」；False（默认）用双向包含。

    双向包含：目标名出现在 brand 里，或 brand 出现在目标名里（应对
    "招商银行" ↔ "招商银行股份有限公司" 这类），命中即算同一家公司。
    """
    b = _normalize_name(brand_name)
    if not b:
        return False
    norm_targets = [_normalize_name(t) for t in targets if t and t.strip()]
    norm_targets = [t for t in norm_targets if t]
    if not norm_targets:
        return False

    if strict:
        bs = _strip_suffix(b)
        for t in norm_targets:
            ts = _strip_suffix(t)
            if ts and (ts == bs):
                return True
        return False

    # 宽松匹配：先做原名双向包含，再做「剥后缀」后的双向包含（提高召回，
    # 例如 brand=「XX科技(北京)股份有限公司」目标=「XX科技」）。
    bs = _strip_suffix(b)
    for t in norm_targets:
        if t in b or b in t:
            return True
        ts = _strip_suffix(t)
        if ts and bs and (ts in bs or bs in ts):
            return True
    return False


# ============================================================
# 纯逻辑：统一社会信用代码(USCC) 提取 与 三重核验
# ============================================================
# USCC：18 位，数字 + 大写字母（国标排除 I O S V Z，这里用宽松集合便于比对）
_USCC_RE = re.compile(r"[0-9A-HJ-NP-RT-Z]{18}")
_USCC_LABEL_RE = re.compile(r"统一社会信用代码[\s:：]*([0-9A-Za-z]{18})")


def normalize_uscc(s):
    return re.sub(r"\s+", "", str(s or "")).upper()


def extract_uscc_from_text(text):
    """从公司页纯文本里提取统一社会信用代码。优先「标签+代码」，再全局兜底。"""
    if not text:
        return ""
    m = _USCC_LABEL_RE.search(text)
    if m:
        cand = normalize_uscc(m.group(1))
        if re.fullmatch(r"[0-9A-Z]{18}", cand):
            return cand
    # 兜底：全局找一个同时含字母和数字的 18 位串（企业码常以 91 开头）
    for m in _USCC_RE.finditer(text.upper()):
        cand = m.group(0)
        if any(c.isdigit() for c in cand) and any(c.isalpha() for c in cand):
            return cand
    return ""


def compute_verify_status(brand_name, official_name, uscc_scraped, uscc_expected):
    """三重核验：页面公司名 vs 全称、页面USCC vs 期望USCC。

    返回 (name_verify, uscc_verify, verify_status)。数据始终保留，仅打标注。
    """
    # 名称核验
    if official_name:
        name_ok = brand_matches(brand_name, [official_name])
        name_verify = "一致" if name_ok else "不一致"
    else:
        name_verify = "无参考"

    us, ue = normalize_uscc(uscc_scraped), normalize_uscc(uscc_expected)
    if ue and us:
        uscc_verify = "一致" if us == ue else "不一致"
    elif ue and not us:
        uscc_verify = "页面无代码"
    elif not ue and us:
        uscc_verify = "无期望代码"
    else:
        uscc_verify = "无参考"

    # 综合结论
    if uscc_verify == "不一致":
        status = "⚠️USCC不一致(疑似仿冒，已保留)"
    elif uscc_verify == "一致":
        status = "✅三重核验通过" if name_verify != "不一致" else "⚠️USCC符但名称异常"
    elif name_verify == "不一致":
        status = "⚠️名称不一致(无USCC可核)"
    elif uscc_verify == "页面无代码":
        status = "仅名称匹配(页面无USCC)"
    else:
        status = "未核验(缺参考USCC)"
    return name_verify, uscc_verify, status


# ============================================================
# 纯逻辑：劳务派遣识别
# ============================================================
# 可按需增删关键词
DISPATCH_JD_KEYWORDS = [
    "劳务派遣", "派遣", "劳务外包", "人事外包", "业务外包", "岗位外包", "外包岗",
    "第三方用工", "第三方派遣", "非自有员工", "非自有编制", "编制:派遣", "编制：派遣",
    "用工形式:派遣", "用工形式：派遣", "灵活用工",
]
DISPATCH_BRAND_KEYWORDS = [
    "人力资源", "劳务", "外包", "人力资源服务", "人才服务", "人事服务", "灵活用工", "用工服务",
]


def detect_dispatch(brand_name, jd_text="", title="", welfare=""):
    """判断是否为劳务派遣/外包岗位，返回 (is_dispatch: bool, reason: str)。"""
    reasons = []
    blob = " ".join([title or "", jd_text or "", welfare or ""])
    for kw in DISPATCH_JD_KEYWORDS:
        if kw in blob:
            reasons.append(f"文案含“{kw}”")
            break
    for kw in DISPATCH_BRAND_KEYWORDS:
        if kw in (brand_name or ""):
            reasons.append(f"招聘方为{kw}类公司")
            break
    return (len(reasons) > 0), "；".join(reasons)


# ============================================================
# 纯逻辑：把「列表岗位字段」+「详情页结果」合并成一整行
# ============================================================
def _merge_skills(list_skills, detail_tags):
    """合并列表技能字符串与详情页技能标签，去重保序。"""
    out = []
    seen = set()
    for chunk in (list_skills or "").split(" | "):
        chunk = chunk.strip()
        if chunk and chunk not in seen:
            seen.add(chunk)
            out.append(chunk)
    for tag in detail_tags or []:
        tag = (tag or "").strip()
        if tag and tag not in seen:
            seen.add(tag)
            out.append(tag)
    return " | ".join(out)


def _split_experience_degree(tags):
    """从列表页 tags（形如 '3-5年 | 本科'）里分出经验与学历。"""
    exp, deg = "", ""
    degree_words = {"初中及以下", "中专/中技", "高中", "大专", "本科", "硕士", "博士", "学历不限"}
    for t in (tags or "").split(" | "):
        t = t.strip()
        if not t:
            continue
        if t in degree_words:
            deg = t
        elif ("年" in t) or ("应届" in t) or ("在校" in t) or ("经验" in t):
            exp = t
    return exp, deg


def build_company_row(ts_code, query_name, job, jd_text="", detail_tags=None,
                      official_name="", is_listed="", uscc_expected="", uscc_scraped=""):
    """把单个岗位（列表字段 + 详情 JD + 核验信息）拼成导出用的一整行 dict。"""
    exp, deg = _split_experience_degree(job.get("tags", ""))
    brand = job.get("boss_name", "")
    welfare = job.get("welfare", "")
    title = job.get("title", "")

    name_verify, uscc_verify, verify_status = compute_verify_status(
        brand, official_name, uscc_scraped, uscc_expected)
    is_dispatch, dispatch_reason = detect_dispatch(brand, jd_text, title, welfare)

    return {
        "ts_code": ts_code,
        "query_name": query_name,
        "official_name": official_name or "",
        "is_listed": ("是" if is_listed is True else ("否" if is_listed is False else "")),
        "uscc_expected": normalize_uscc(uscc_expected),
        "uscc_scraped": normalize_uscc(uscc_scraped),
        "name_verify": name_verify,
        "uscc_verify": uscc_verify,
        "verify_status": verify_status,
        "is_dispatch": "是" if is_dispatch else "否",
        "dispatch_reason": dispatch_reason,
        "matched_brand": brand,
        "title": job.get("title", ""),
        "salary": job.get("salary", ""),
        "location": (job.get("location", "") or "").replace("\u00b7\u00b7", "\u00b7").strip("\u00b7"),
        "company_name": brand,
        "company_scale": job.get("company_scale", ""),
        "company_stage": job.get("company_stage", ""),
        "company_industry": job.get("company_industry", ""),
        "experience": exp,
        "degree": deg,
        "skills": _merge_skills(job.get("skills", ""), detail_tags),
        "welfare": job.get("welfare", ""),
        "jd": jd_text or "",
        "job_link": job.get("job_link", ""),
        "company_link": job.get("company_link", ""),
        "salary_source": job.get("salary_source", ""),
        "scraped_at": datetime.now().isoformat(timespec="seconds"),
    }


# ============================================================
# 纯逻辑：CSV / JSON 导出
# ============================================================
def write_company_csv(path, rows):
    """把宽表写入 CSV（UTF-8-SIG，Excel 直接可读）。"""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=COMPANY_CSV_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        for r in rows:
            writer.writerow({c: r.get(c, "") for c in COMPANY_CSV_COLUMNS})


def write_company_json(path, rows, meta=None):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    payload = {"meta": meta or {}, "rows": rows}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)


def resolve_city_code(city_input):
    """把城市输入解析为 (显示名, 城市码)，支持「全国」。"""
    if not city_input or str(city_input).strip().lower() in NATIONWIDE_ALIASES:
        return "全国", NATIONWIDE_CITY_CODE
    return boss.resolve_city(str(city_input).strip())


# ============================================================
# 联网抓取（需要 Chrome CDP + 登录态）
# ============================================================
def _default_logger(msg):
    print(msg, flush=True)


def search_company_page(cdp, sid, company_name, city_code, page, filters, page_size=PAGE_SIZE):
    """调一次搜索 API，返回本页所有岗位（未过滤品牌）。"""
    api_params = {
        "scene": "1",
        "query": company_name,
        "city": city_code,
        "page": page,
        "pageSize": page_size,
    }
    for k, v in (filters or {}).items():
        if v:
            api_params[k] = v
    from urllib.parse import urlencode
    api_url = f"{boss.API_JOB_LIST_PATH}?{urlencode(api_params)}"
    api_js = boss.FETCH_API_JS_TEMPLATE.replace("__API_URL__", api_url)
    val = cdp.eval_js(api_js, sid)
    return boss.parse_api_jobs_eval_value(val)


def _job_key(job):
    """跨城市/跨页去重用的稳定键：优先岗位 id，其次链接，最后标题。"""
    return job.get("encrypt_job_id") or job.get("job_link") or job.get("title", "")


def diagnose_company(cdp, sid, company, cities, filters, pages=2, log=_default_logger):
    """诊断：打印搜索前几页实际返回了哪些公司（brandName），用于排查漏抓。

    返回 (总返回条数, brandName 计数 Counter)。
    """
    from collections import Counter
    brand_counter = Counter()
    total = 0
    for city_name, city_code in cities:
        _warm_up_search(cdp, sid, company["name"], city_code, filters, log=log)
        for pg in range(1, pages + 1):
            try:
                jobs = search_company_page(cdp, sid, company["name"], city_code, pg, filters)
            except Exception as e:  # noqa: BLE001
                log(f"    [诊断] {city_name} 第 {pg} 页失败: {e}")
                break
            if not jobs:
                break
            total += len(jobs)
            for j in jobs:
                brand_counter[j.get("boss_name", "") or "(空)"] += 1
            if len(jobs) < PAGE_SIZE:
                break
            time.sleep(random.uniform(1.5, 3.0))

    targets = [company["name"]] + list(company.get("aliases", []))
    log(f"    [诊断] 搜索「{company['name']}」共返回 {total} 条，涉及 {len(brand_counter)} 家公司。")
    if total == 0:
        log("    [诊断] 接口没有返回任何岗位 → 可能是城市码/登录态问题，试试换具体城市或重登。")
    else:
        top = brand_counter.most_common(10)
        log("    [诊断] 返回最多的公司（brandName × 条数）：")
        for name, cnt in top:
            hit = "✓命中" if brand_matches(name, targets) else "  "
            log(f"        {hit} {name} × {cnt}")
        if not any(brand_matches(n, targets) for n in brand_counter):
            log("    [诊断] 以上没有一家匹配你的公司名/别名 →")
            log("            说明职位搜索这条通道没把这家公司排上来（关键词搜索的通病）。")
            log("            办法：① 在 CSV 别名列补它在 BOSS 上的招聘主体名；"
                "② 或用「公司主页直取」方式（见使用说明）。")
    return total, brand_counter


def _warm_up_search(cdp, sid, company_name, city_code, filters, log=_default_logger, wait=(5.0, 8.0)):
    """导航到真实搜索结果页，种下 BOSS 搜索所需的会话令牌/Cookie。

    这是关键一步：BOSS 的搜索 API 依赖打开搜索页时才会写入的令牌，
    只导航首页往往不够，会导致 API 返回空 jobList。参考 boss_cdp_raw.scrape_list。
    """
    try:
        url = boss.build_search_url(company_name, city_code, 1, filters or {})
        cdp.send("Page.navigate", {"url": url}, sid)
        time.sleep(random.uniform(*wait))
        try:
            cdp.eval_js("window.scrollBy(0,300)", sid)
        except Exception:  # noqa: BLE001
            pass
        time.sleep(random.uniform(0.5, 1.2))
    except Exception as e:  # noqa: BLE001
        log(f"    [预热] 导航搜索页失败: {e}")


def collect_company_jobs(cdp, sid, company, cities, filters,
                         strict=False, exhaustive=True, max_pages=SEARCH_HARD_MAX_PAGES,
                         require_listed=False, log=_default_logger, stop_flag=None):
    """搜索并按品牌过滤出某公司的岗位列表（跨城市聚合、翻页到底、去重）。

    Args:
        cities: [(城市名, 城市码), ...]
        exhaustive: True=翻到搜索结果末页为止（抓全部）；False=最多翻 max_pages 页
        max_pages: 每个城市的翻页安全上限
        require_listed: True 且已核对到上市全称时，只用全称做精确匹配，避免同名非上市公司误入
    """
    from collections import Counter
    official = (company.get("official_name") or "").strip()
    if require_listed and official:
        # 仅用上市全称精确匹配，避免同名非上市公司（如「太平洋保险」）误入
        targets = [official]
    else:
        targets = [company["name"]] + list(company.get("aliases", []))
    matched = []
    seen = set()
    all_brands = Counter()
    total_returned = 0

    hard_cap = SEARCH_HARD_MAX_PAGES if exhaustive else max(1, max_pages)

    for city_name, city_code in cities:
        if stop_flag is not None and stop_flag():
            break

        # 关键修复：先打开搜索页种令牌，再调 API
        _warm_up_search(cdp, sid, company["name"], city_code, filters, log=log)

        empty_streak = 0
        for pg in range(1, hard_cap + 1):
            if stop_flag is not None and stop_flag():
                break
            try:
                jobs = search_company_page(cdp, sid, company["name"], city_code, pg, filters)
            except Exception as e:  # noqa: BLE001
                log(f"    [!] {city_name} 第 {pg} 页搜索失败: {e}")
                break

            # 第 1 页就空：可能令牌没种上，重新预热并重试一次再下结论
            if not jobs and pg == 1:
                log(f"    第 1 页无数据，重新预热搜索页后重试…")
                _warm_up_search(cdp, sid, company["name"], city_code, filters, log=log, wait=(7.0, 10.0))
                try:
                    jobs = search_company_page(cdp, sid, company["name"], city_code, pg, filters)
                except Exception as e:  # noqa: BLE001
                    log(f"    [!] {city_name} 第 1 页重试失败: {e}")
                    jobs = []

            if not jobs:
                empty_streak += 1
                if empty_streak >= 2:
                    break
                continue
            empty_streak = 0
            total_returned += len(jobs)

            page_hits = 0
            for j in jobs:
                all_brands[j.get("boss_name", "") or "(空)"] += 1
                if not brand_matches(j.get("boss_name", ""), targets, strict=strict):
                    continue
                key = _job_key(j)
                if key in seen:
                    continue
                seen.add(key)
                matched.append(j)
                page_hits += 1

            city_tag = f"{city_name} " if len(cities) > 1 else ""
            log(f"    {city_tag}第 {pg} 页：返回 {len(jobs)} 条，命中本公司 {page_hits} 条（累计 {len(matched)}）")

            # 翻到底判定：本页不足一页，说明该城市搜索结果已到末页
            if len(jobs) < PAGE_SIZE:
                break
            time.sleep(random.uniform(2.0, 4.5))

        if len(cities) > 1:
            time.sleep(random.uniform(2.0, 4.0))

    # 一个岗位都没命中时，把实际返回的公司名打出来，方便诊断
    if not matched:
        if total_returned == 0:
            log("    [诊断] 搜索接口始终没返回岗位（已尝试重新预热搜索页）。"
                "可能是 BOSS 风控/令牌失效：稍等片刻重跑，或换具体城市、重新登录。")
        else:
            log(f"    [诊断] 搜到 {total_returned} 条但没有一条属于本公司。返回最多的公司：")
            for name, cnt in all_brands.most_common(8):
                log(f"        {name} × {cnt}")
            log("    [诊断] → 多半是该公司在 BOSS 的招聘主体名与清单不同，请在别名列补名后重抓。")

    return matched


def fetch_job_detail(cdp_port, job, log=_default_logger):
    """打开单个岗位详情页，返回 (jd_text, skill_tags)。失败返回 ("", [])。"""
    ws = None
    tid = None
    try:
        ws = boss.CDPSession(cdp_port)
        tid, sid = boss.create_page_session(ws)
        detail_url = boss.build_detail_url(job)
        ws.send("Page.navigate", {"url": detail_url}, sid)
        time.sleep(random.uniform(4.0, 7.0))

        # 轻量模拟滚动，帮助详情页渲染
        for _ in range(random.randint(2, 4)):
            ws.eval_js(f"window.scrollBy(0,{random.randint(200, 600)})", sid)
            time.sleep(random.uniform(0.6, 1.6))

        val = ws.eval_js(boss.EXTRACT_DETAIL_JS, sid)
        try:
            d = json.loads(val) if isinstance(val, str) else {"jd": "", "tags": []}
        except (json.JSONDecodeError, ValueError, TypeError):
            d = {"jd": "", "tags": []}

        try:
            jd = boss.extract_job_description(d)
        except boss.DetailLoginRequiredError:
            raise RuntimeError("登录态已失效：详情页被登录墙截断，请重新登录 BOSS 后再抓。")
        except boss.DetailExtractionError as e:
            log(f"      跳过无效详情页: {e}")
            return "", d.get("tags", [])
        return jd, d.get("tags", [])
    finally:
        if ws is not None:
            try:
                if tid is not None:
                    ws.send("Target.closeTarget", {"targetId": tid})
            except Exception:  # noqa: BLE001
                pass
            try:
                ws.close()
            except Exception:  # noqa: BLE001
                pass


def _build_cities(city_input, multi_city):
    """构建要搜索的城市列表 [(名, 码), ...]。"""
    city_name, city_code = resolve_city_code(city_input)
    is_nationwide = str(city_input).strip().lower() in NATIONWIDE_ALIASES or not city_input
    if is_nationwide and multi_city:
        cities = []
        for nm in MAJOR_CITY_NAMES:
            n, c = boss.resolve_city(nm)
            if c:
                cities.append((n, c))
        return cities or [("全国", NATIONWIDE_CITY_CODE)]
    return [(city_name, city_code)]


def fetch_company_uscc(cdp_port, company_link, log=_default_logger):
    """打开公司主页，抓取「工商信息」里的统一社会信用代码。失败返回 ""。

    做法：渲染公司页 → 取全文 innerText → 正则提取 USCC。对页面结构不敏感。
    """
    if not company_link:
        return ""
    ws = None
    tid = None
    try:
        ws = boss.CDPSession(cdp_port)
        tid, sid = boss.create_page_session(ws)
        ws.send("Page.navigate", {"url": company_link}, sid)
        time.sleep(random.uniform(4.0, 7.0))
        # 滚动促使工商信息区块渲染
        for _ in range(random.randint(2, 4)):
            try:
                ws.eval_js(f"window.scrollBy(0,{random.randint(300, 800)})", sid)
            except Exception:  # noqa: BLE001
                pass
            time.sleep(random.uniform(0.6, 1.4))
        try:
            text = ws.eval_js("document.body ? document.body.innerText : ''", sid)
        except Exception:  # noqa: BLE001
            text = ""
        if not isinstance(text, str):
            text = ""
        return extract_uscc_from_text(text)
    except Exception as e:  # noqa: BLE001
        log(f"      公司页 USCC 抓取失败: {e}")
        return ""
    finally:
        if ws is not None:
            try:
                if tid is not None:
                    ws.send("Target.closeTarget", {"targetId": tid})
            except Exception:  # noqa: BLE001
                pass
            try:
                ws.close()
            except Exception:  # noqa: BLE001
                pass


def run_company_scrape(
    companies,
    city_input="全国",
    pages_per_company=3,
    max_jobs_per_company=None,
    filters=None,
    strict_brand=False,
    fetch_jd=True,
    all_jobs=True,
    multi_city=False,
    require_listed=False,
    verify_uscc=False,
    cdp_port=boss.DEFAULT_CDP_PORT,
    output_csv=None,
    output_json=None,
    log=_default_logger,
    stop_flag=None,
    progress=None,
):
    """主流程：逐公司搜索 → 品牌过滤 → 抓详情 JD → 合并 → 增量落盘。

    Args:
        companies: load_company_csv 的返回值
        city_input: 城市名/代码/「全国」
        pages_per_company: all_jobs=False 时每家公司最多翻几页
        max_jobs_per_company: 每家公司最多抓多少岗位详情（None=不限）
        all_jobs: True=翻到底抓该公司全部岗位（推荐，忽略 pages_per_company）
        multi_city: True 且城市为「全国」时，遍历主要城市聚合（更全但很慢）
        strict_brand: 品牌严格匹配
        fetch_jd: 是否进入详情页抓岗位描述全文
        output_csv / output_json: 结果落盘路径
        log/stop_flag/progress: 回调

    Returns: rows(list[dict])
    """
    filters = filters or {}
    cities = _build_cities(city_input, multi_city)
    rows = []

    log(f"=== 按公司抓取 BOSS直聘 ===")
    city_desc = "、".join(n for n, _ in cities) if len(cities) <= 6 else f"{len(cities)} 个主要城市"
    log(f"公司数: {len(companies)} | 城市: {city_desc}"
        f" | 抓取范围: {'全部岗位(翻到底)' if all_jobs else f'最多 {pages_per_company} 页'}"
        f" | 每公司详情上限: {max_jobs_per_company or '不限'}"
        f" | 抓岗位描述: {'是' if fetch_jd else '否'} | 品牌匹配: {'严格' if strict_brand else '宽松'}")
    if filters:
        log(f"筛选: {filters}")
    log("")

    # 搜索阶段复用一个后台标签页
    cdp = boss.CDPSession(cdp_port)
    tid, sid = boss.create_page_session(cdp)
    cdp.send("Page.navigate", {"url": "https://www.zhipin.com/"}, sid)
    time.sleep(3)

    total = len(companies)
    done_jobs = 0
    brand_uscc_cache = {}
    if require_listed:
        kept = [c for c in companies if c.get("is_listed") is True]
        skipped = total - len(kept)
        if not any("is_listed" in c for c in companies):
            log("⚠️ 已勾选「仅上市公司」但公司尚未用 DeepSeek 核对，将无法判断，跳过全部。请先点「用 DeepSeek 核对全称」。")
        if skipped:
            log(f"「仅上市公司」：跳过未核对/非上市的 {skipped} 家，保留 {len(kept)} 家。")
        companies = kept
        total = len(companies)
    try:
        for ci, company in enumerate(companies, 1):
            if stop_flag is not None and stop_flag():
                log("已收到停止指令，提前结束。")
                break

            label = f"{company['name']}" + (f" [{company['ts_code']}]" if company["ts_code"] else "")
            if company.get("official_name"):
                label += f" · {company['official_name']}"
            log(f"[{ci}/{total}] {label}")

            matched = collect_company_jobs(
                cdp, sid, company, cities, filters,
                strict=strict_brand, exhaustive=all_jobs, max_pages=pages_per_company,
                require_listed=require_listed, log=log, stop_flag=stop_flag,
            )
            if not matched:
                log(f"    未命中任何岗位（可能该公司近期无在招 / 品牌名不同，可补充别名）")
            if max_jobs_per_company:
                matched = matched[:max_jobs_per_company]

            uscc_expected = company.get("uscc_expected", "")
            for ji, job in enumerate(matched, 1):
                if stop_flag is not None and stop_flag():
                    break
                jd_text, detail_tags = "", []
                if fetch_jd:
                    log(f"    ↳ 详情 {ji}/{len(matched)}: {job.get('title','')}")
                    try:
                        jd_text, detail_tags = fetch_job_detail(cdp_port, job, log=log)
                    except RuntimeError as e:
                        # 登录失效等致命错误：停止整轮，保留已抓数据
                        log(f"    [x] {e}")
                        raise
                    log(f"      岗位描述 {len(jd_text)} 字")
                    time.sleep(random.uniform(6.0, 12.0))

                # 三重核验：按品牌抓一次公司页 USCC（缓存复用）
                uscc_scraped = ""
                if verify_uscc:
                    brand_key = job.get("encrypt_brand_id") or job.get("company_link") or job.get("boss_name", "")
                    if brand_key in brand_uscc_cache:
                        uscc_scraped = brand_uscc_cache[brand_key]
                    else:
                        link = job.get("company_link") or (
                            f"https://www.zhipin.com/gongsi/{job.get('encrypt_brand_id')}.html"
                            if job.get("encrypt_brand_id") else "")
                        uscc_scraped = fetch_company_uscc(cdp_port, link, log=log)
                        brand_uscc_cache[brand_key] = uscc_scraped
                        time.sleep(random.uniform(3.0, 6.0))
                    if uscc_expected and uscc_scraped and normalize_uscc(uscc_expected) != normalize_uscc(uscc_scraped):
                        log(f"      ⚠️ USCC 不一致：页面 {uscc_scraped} ≠ 期望 {uscc_expected}（疑似仿冒，已保留标注）")

                rows.append(build_company_row(
                    company["ts_code"], company["name"], job,
                    jd_text=jd_text, detail_tags=detail_tags,
                    official_name=company.get("official_name", ""),
                    is_listed=company.get("is_listed", ""),
                    uscc_expected=uscc_expected,
                    uscc_scraped=uscc_scraped,
                ))
                done_jobs += 1

                # 增量落盘：异常/中止也保留已抓数据
                if output_csv:
                    write_company_csv(output_csv, rows)
                if output_json:
                    write_company_json(output_json, rows, meta={
                        "city": city_desc, "filters": filters,
                        "companies_total": total, "companies_done": ci,
                        "scraped_at": datetime.now().isoformat(timespec="seconds"),
                    })

            if progress is not None:
                progress(ci, total, done_jobs)

            if ci < total:
                time.sleep(random.uniform(4.0, 8.0))

    except RuntimeError:
        # 已在上面记录日志；保留已抓数据后向上抛
        pass
    except KeyboardInterrupt:
        log("\n中断（KeyboardInterrupt）")
    finally:
        try:
            cdp.send("Target.closeTarget", {"targetId": tid})
        except Exception:  # noqa: BLE001
            pass
        try:
            cdp.close()
        except Exception:  # noqa: BLE001
            pass

    log("")
    log(f"完成：共 {len(rows)} 条岗位。")
    if output_csv:
        write_company_csv(output_csv, rows)
        log(f"CSV 已保存: {output_csv}")
    if output_json:
        write_company_json(output_json, rows)
        log(f"JSON 已保存: {output_json}")
    return rows


# ============================================================
# 命令行入口
# ============================================================
def _default_output_csv():
    fn = f"company_jobs_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
    return os.path.join(boss.DEFAULT_RESULT_DIR, fn)


def main(argv=None):
    p = argparse.ArgumentParser(
        description="按「股票代码+公司名」批量抓取 BOSS直聘岗位（含岗位描述全文）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--companies", required=True, help="公司清单 CSV（列: ts_code, name[, 别名]）")
    p.add_argument("--city", default="全国", help="城市名/代码/全国（默认 全国）")
    p.add_argument("--pages-per-company", type=int, default=3,
                   help="仅当 --limit-pages 时生效：每公司最多翻页数（默认 3）")
    p.add_argument("--limit-pages", action="store_true",
                   help="只翻有限页（配合 --pages-per-company），默认是翻到底抓全部岗位")
    p.add_argument("--multi-city", action="store_true",
                   help="城市为「全国」时遍历主要城市聚合（更全但很慢）")
    p.add_argument("--max-jobs-per-company", type=int, default=None, help="每公司最多抓岗位数（默认不限）")
    p.add_argument("--no-jd", action="store_true", help="不抓岗位描述详情（只要列表字段，快很多）")
    p.add_argument("--strict-brand", action="store_true", help="品牌严格匹配（剥后缀后完全相等）")
    p.add_argument("--tushare-token", default=None,
                   help="Tushare token（提供则优先用 Tushare 核对全称+统一社会信用代码，最准）")
    p.add_argument("--deepseek-key", default=None, help="DeepSeek API Key（备选核对来源）")
    p.add_argument("--deepseek-base-url", default=None, help="DeepSeek base_url（默认官方）")
    p.add_argument("--deepseek-model", default=None, help="DeepSeek 模型（默认 deepseek-chat）")
    p.add_argument("--require-listed", action="store_true",
                   help="仅抓取 DeepSeek 核对为上市公司的公司（需配合 --deepseek-key）")
    p.add_argument("--verify-uscc", action="store_true",
                   help="逐公司抓取页面统一社会信用代码并与期望值三重核验（较慢，防仿冒）")
    p.add_argument("--cdp-port", type=int, default=boss.DEFAULT_CDP_PORT, help="Chrome CDP 端口")
    p.add_argument("--output", default=None, help="输出 CSV 路径")
    p.add_argument("--output-json", default=None, help="同时输出 JSON 路径（可选）")

    # 筛选（沿用 boss_cdp_raw 的代码含义）
    p.add_argument("--salary", default=None)
    p.add_argument("--scale", default=None)
    p.add_argument("--stage", default=None)
    p.add_argument("--experience", default=None)
    p.add_argument("--degree", default=None)
    p.add_argument("--industry", default=None)

    args = p.parse_args(argv)

    if not boss.require_runtime_dependencies("requests", "websocket"):
        return 1

    companies = load_company_csv(args.companies)
    if not companies:
        print("公司清单为空，请检查 CSV。")
        return 1
    print(f"已加载 {len(companies)} 家公司（编码识别为 {getattr(companies, 'encoding', 'utf-8-sig')}）。")

    # 可选：先用 Tushare 核对全称与统一社会信用代码（首选，最准）
    if args.tushare_token:
        try:
            import tushare_resolver as tsr
            client = tsr.TushareClient(args.tushare_token)
            cache_path = os.path.join(boss.DEFAULT_RESULT_DIR, tsr.DEFAULT_CACHE_NAME)
            print("用 Tushare 核对上市公司全称与统一社会信用代码...")
            tsr.resolve_companies_tushare(companies, client, cache_path=cache_path)
        except Exception as e:  # noqa: BLE001
            print(f"Tushare 核对失败（将回退到 DeepSeek/简称匹配）：{e}")

    # 可选：用 DeepSeek 核对（备选；不覆盖 Tushare/CSV 已填的 USCC）
    if args.deepseek_key:
        try:
            import deepseek_resolver as dsr
            client = dsr.DeepSeekClient(
                args.deepseek_key,
                base_url=args.deepseek_base_url or dsr.DEFAULT_BASE_URL,
                model=args.deepseek_model or dsr.DEFAULT_MODEL,
            )
            cache_path = os.path.join(boss.DEFAULT_RESULT_DIR, dsr.DEFAULT_CACHE_NAME)
            print("用 DeepSeek 核对上市公司全称...")
            dsr.resolve_companies(companies, client, cache_path=cache_path)
        except Exception as e:  # noqa: BLE001
            print(f"DeepSeek 核对失败（将跳过，仍按简称/别名匹配）：{e}")
    elif args.require_listed:
        print("⚠️ --require-listed 需要 --deepseek-key 才能判断是否上市，否则会跳过全部公司。")

    # 登录态检测
    print("检测登录状态...")
    result = boss.check_login_state(args.cdp_port)
    if result.status is boss.LoginProbeStatus.UNAUTHENTICATED:
        print("未检测到 BOSS 登录态。请先运行: python3 scripts/boss_cdp_raw.py --setup-chrome")
        return 1
    if result.status is boss.LoginProbeStatus.RESTRICTED:
        print(f"接口受限: {boss.describe_login_probe_result(result)}，请稍后再试。")
        return 1

    filters = {}
    for key in ["salary", "scale", "stage", "experience", "degree", "industry"]:
        v = getattr(args, key)
        if v:
            filters[key] = v

    output_csv = args.output or _default_output_csv()
    run_company_scrape(
        companies,
        city_input=args.city,
        pages_per_company=args.pages_per_company,
        max_jobs_per_company=args.max_jobs_per_company,
        filters=filters,
        strict_brand=args.strict_brand,
        fetch_jd=not args.no_jd,
        all_jobs=not args.limit_pages,
        multi_city=args.multi_city,
        require_listed=args.require_listed,
        verify_uscc=args.verify_uscc,
        cdp_port=args.cdp_port,
        output_csv=output_csv,
        output_json=args.output_json,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
