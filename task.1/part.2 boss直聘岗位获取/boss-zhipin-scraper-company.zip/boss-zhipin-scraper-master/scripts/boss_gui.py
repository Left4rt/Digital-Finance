#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BOSS直聘「按公司批量抓取」图形界面（tkinter，Python 自带）。

功能分区：
  1) 环境准备：启动专用 Chrome 并登录 / 检查登录状态 / 关闭 Chrome
  2) 公司清单：选择「股票代码 + 公司名/别名」CSV，预览已加载公司
  3) 抓取设置：城市、每公司页数、每公司岗位上限、是否抓岗位描述全文、筛选等
  4) 运行控制：开始 / 停止 / 进度条
  5) 实时日志 + 打开输出文件夹

依赖：仅需 Python 标准库中的 tkinter（Windows/macOS 官方 Python 均自带；
Linux 若缺失可执行  sudo apt install python3-tk）。实际抓取还需要
requests、websocket-client（见 requirements.txt）以及本机已安装 Chrome。

运行：
  python3 scripts/boss_gui.py
"""

from __future__ import annotations

import os
import sys
import queue
import threading
import contextlib
import traceback
from datetime import datetime

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

# 让 GUI 能找到同目录下的两个模块
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

import boss_cdp_raw as boss          # noqa: E402
import company_scraper as cs          # noqa: E402


# 薪资筛选下拉（展示名 -> 代码），沿用 boss_cdp_raw.SALARY_MAP
SALARY_CHOICES = [("不限", "")] + [(k, v) for k, v in boss.SALARY_MAP.items() if v != "0"]
SCALE_CHOICES = [("不限", "")] + list(boss.SCALE_MAP.items())


class BossScraperGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("BOSS直聘 · 按公司批量抓取岗位")
        self.root.geometry("920x760")
        self.root.minsize(820, 640)

        # 运行时状态
        self.companies = []
        self.csv_path = tk.StringVar()
        self.city = tk.StringVar(value="全国")
        self.pages = tk.IntVar(value=3)
        self.max_jobs = tk.StringVar(value="20")
        self.fetch_jd = tk.BooleanVar(value=True)
        self.all_jobs = tk.BooleanVar(value=True)
        self.multi_city = tk.BooleanVar(value=False)
        self.strict_brand = tk.BooleanVar(value=False)
        self.require_listed = tk.BooleanVar(value=False)
        self.verify_uscc = tk.BooleanVar(value=False)
        self.ds_key = tk.StringVar(value="")
        self.ds_base = tk.StringVar(value="https://api.deepseek.com")
        self.ds_model = tk.StringVar(value="deepseek-chat")
        self.ts_token = tk.StringVar(value="")
        self.cdp_port = tk.IntVar(value=boss.DEFAULT_CDP_PORT)
        self.salary_choice = tk.StringVar(value="不限")
        self.scale_choice = tk.StringVar(value="不限")
        self.out_dir = tk.StringVar(value=boss.DEFAULT_RESULT_DIR)
        self.status = tk.StringVar(value="就绪")

        self._log_queue = queue.Queue()
        self._stop_event = threading.Event()
        self._worker = None
        self._last_output_csv = None

        self._build_ui()
        self.root.after(120, self._drain_log)

    # --------------------------------------------------------
    # UI 构建
    # --------------------------------------------------------
    def _build_ui(self):
        pad = {"padx": 8, "pady": 4}
        outer = ttk.Frame(self.root, padding=10)
        outer.pack(fill="both", expand=True)

        # ---- 1. 环境准备 ----
        env = ttk.LabelFrame(outer, text="① 环境准备（首次使用先在这里登录）", padding=8)
        env.pack(fill="x", **pad)
        row = ttk.Frame(env); row.pack(fill="x")
        ttk.Label(row, text="CDP 端口:").pack(side="left")
        ttk.Entry(row, textvariable=self.cdp_port, width=8).pack(side="left", padx=(4, 16))
        ttk.Button(row, text="启动 Chrome 并登录", command=self.on_setup_chrome).pack(side="left", padx=4)
        ttk.Button(row, text="检查登录状态", command=self.on_check_login).pack(side="left", padx=4)
        ttk.Button(row, text="关闭专用 Chrome", command=self.on_stop_chrome).pack(side="left", padx=4)
        ttk.Label(env, text="提示：点“启动 Chrome 并登录”→ 在弹出的浏览器里登录 BOSS直聘 →"
                            " 回来点“检查登录状态”显示已登录即可。",
                  foreground="#666").pack(anchor="w", pady=(6, 0))

        # ---- 2. 公司清单 ----
        comp = ttk.LabelFrame(outer, text="② 公司清单（CSV：ts_code, name[, 别名]）", padding=8)
        comp.pack(fill="both", **pad)
        row = ttk.Frame(comp); row.pack(fill="x")
        ttk.Button(row, text="选择 CSV 文件…", command=self.on_choose_csv).pack(side="left")
        ttk.Entry(row, textvariable=self.csv_path).pack(side="left", fill="x", expand=True, padx=8)
        self.comp_count = ttk.Label(row, text="未加载")
        self.comp_count.pack(side="left")

        cols = ("ts_code", "name", "aliases")
        self.tree = ttk.Treeview(comp, columns=cols, show="headings", height=6)
        for c, w in zip(cols, (110, 200, 260)):
            self.tree.heading(c, text={"ts_code": "股票代码", "name": "公司名", "aliases": "别名"}[c])
            self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="x", pady=(6, 0))

        # ---- 2.5 上市公司核对（Tushare 首选 / DeepSeek 备选）----
        ds = ttk.LabelFrame(outer, text="②′ 上市公司核对（Tushare 首选 · 全称+统一社会信用代码）", padding=8)
        ds.pack(fill="x", **pad)
        tr = ttk.Frame(ds); tr.pack(fill="x")
        ttk.Label(tr, text="Tushare token:").pack(side="left")
        ttk.Entry(tr, textvariable=self.ts_token, show="•", width=40).pack(side="left", padx=(4, 12))
        ttk.Button(tr, text="用 Tushare 核对(全称+信用代码)", command=self.on_tushare_resolve).pack(side="left")
        dr = ttk.Frame(ds); dr.pack(fill="x", pady=(6, 0))
        ttk.Label(dr, text="DeepSeek Key:").pack(side="left")
        ttk.Entry(dr, textvariable=self.ds_key, show="•", width=26).pack(side="left", padx=(4, 10))
        ttk.Label(dr, text="模型:").pack(side="left")
        ttk.Entry(dr, textvariable=self.ds_model, width=13).pack(side="left", padx=(4, 10))
        ttk.Button(dr, text="用 DeepSeek 核对(备选)", command=self.on_deepseek_resolve).pack(side="left")
        dr2 = ttk.Frame(ds); dr2.pack(fill="x", pady=(4, 0))
        ttk.Checkbutton(dr2, text="仅抓取核对为上市公司的公司", variable=self.require_listed).pack(side="left")
        ttk.Checkbutton(dr2, text="三重核验统一社会信用代码(防仿冒)", variable=self.verify_uscc).pack(side="left", padx=12)
        ttk.Label(ds, text="推荐先填 Tushare token 点核对：全称与统一社会信用代码来自官方登记，最准；"
                          "DeepSeek 为备选，不覆盖 Tushare/CSV 已填的信用代码。结果按代码缓存。",
                  foreground="#666").pack(anchor="w", pady=(6, 0))

        # ---- 3. 抓取设置 ----
        cfg = ttk.LabelFrame(outer, text="③ 抓取设置", padding=8)
        cfg.pack(fill="x", **pad)
        r1 = ttk.Frame(cfg); r1.pack(fill="x", pady=2)
        ttk.Label(r1, text="城市:").pack(side="left")
        ttk.Entry(r1, textvariable=self.city, width=12).pack(side="left", padx=(4, 16))
        ttk.Label(r1, text="每公司详情上限:").pack(side="left")
        ttk.Entry(r1, textvariable=self.max_jobs, width=6).pack(side="left", padx=(4, 4))
        ttk.Label(r1, text="(留空=不限)", foreground="#666").pack(side="left")

        r2 = ttk.Frame(cfg); r2.pack(fill="x", pady=2)
        ttk.Checkbutton(r2, text="抓取该公司全部岗位（翻到底，推荐）", variable=self.all_jobs).pack(side="left")
        ttk.Checkbutton(r2, text="全国遍历主要城市（更全但很慢）", variable=self.multi_city).pack(side="left", padx=16)

        r2b = ttk.Frame(cfg); r2b.pack(fill="x", pady=2)
        ttk.Checkbutton(r2b, text="抓取岗位描述全文（较慢但完整）", variable=self.fetch_jd).pack(side="left")
        ttk.Checkbutton(r2b, text="品牌严格匹配", variable=self.strict_brand).pack(side="left", padx=16)
        ttk.Label(r2b, text="有限翻页时每公司页数:").pack(side="left", padx=(16, 4))
        ttk.Spinbox(r2b, from_=1, to=boss.MAX_PAGES, textvariable=self.pages, width=5).pack(side="left")

        r3 = ttk.Frame(cfg); r3.pack(fill="x", pady=2)
        ttk.Label(r3, text="薪资筛选:").pack(side="left")
        ttk.Combobox(r3, textvariable=self.salary_choice, width=10, state="readonly",
                     values=[c[0] for c in SALARY_CHOICES]).pack(side="left", padx=(4, 16))
        ttk.Label(r3, text="公司规模:").pack(side="left")
        ttk.Combobox(r3, textvariable=self.scale_choice, width=12, state="readonly",
                     values=[c[0] for c in SCALE_CHOICES]).pack(side="left", padx=(4, 16))

        r4 = ttk.Frame(cfg); r4.pack(fill="x", pady=2)
        ttk.Label(r4, text="输出文件夹:").pack(side="left")
        ttk.Entry(r4, textvariable=self.out_dir).pack(side="left", fill="x", expand=True, padx=8)
        ttk.Button(r4, text="选择…", command=self.on_choose_outdir).pack(side="left")

        # ---- 4. 运行控制 ----
        run = ttk.Frame(outer); run.pack(fill="x", **pad)
        self.start_btn = ttk.Button(run, text="▶ 开始抓取", command=self.on_start)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(run, text="■ 停止", command=self.on_stop, state="disabled")
        self.stop_btn.pack(side="left", padx=8)
        ttk.Button(run, text="诊断首个公司", command=self.on_diagnose).pack(side="left", padx=4)
        ttk.Button(run, text="打开输出文件夹", command=self.on_open_outdir).pack(side="left", padx=8)
        self.progress = ttk.Progressbar(run, mode="determinate", length=220)
        self.progress.pack(side="right")
        ttk.Label(run, textvariable=self.status).pack(side="right", padx=10)

        # ---- 5. 日志 ----
        logf = ttk.LabelFrame(outer, text="运行日志", padding=6)
        logf.pack(fill="both", expand=True, **pad)
        self.log_text = scrolledtext.ScrolledText(logf, height=14, wrap="word", state="disabled")
        self.log_text.pack(fill="both", expand=True)

        self.log("欢迎使用。使用顺序：① 登录 → ② 选择公司 CSV → ③ 设置 → ④ 开始抓取。")

    # --------------------------------------------------------
    # 日志
    # --------------------------------------------------------
    def log(self, msg):
        self._log_queue.put(str(msg))

    def _drain_log(self):
        try:
            while True:
                msg = self._log_queue.get_nowait()
                self.log_text.configure(state="normal")
                ts = datetime.now().strftime("%H:%M:%S")
                self.log_text.insert("end", f"[{ts}] {msg}\n")
                self.log_text.see("end")
                self.log_text.configure(state="disabled")
        except queue.Empty:
            pass
        self.root.after(120, self._drain_log)

    def set_status(self, text):
        self.status.set(text)

    # --------------------------------------------------------
    # 后台线程封装
    # --------------------------------------------------------
    def _run_in_thread(self, target, on_done=None):
        def wrapper():
            try:
                target()
            except Exception as e:  # noqa: BLE001
                self.log(f"[错误] {e}")
                self.log(traceback.format_exc())
            finally:
                if on_done:
                    self.root.after(0, on_done)
        t = threading.Thread(target=wrapper, daemon=True)
        t.start()
        return t

    class _QueueWriter:
        """把 stdout 重定向到日志队列。"""
        def __init__(self, put):
            self._put = put
            self._buf = ""

        def write(self, s):
            self._buf += s
            while "\n" in self._buf:
                line, self._buf = self._buf.split("\n", 1)
                if line.strip():
                    self._put(line)

        def flush(self):
            if self._buf.strip():
                self._put(self._buf)
            self._buf = ""

    # --------------------------------------------------------
    # 环境按钮
    # --------------------------------------------------------
    def on_setup_chrome(self):
        port = self.cdp_port.get()
        self.set_status("启动 Chrome 中…")
        self.log("启动专用 Chrome（不复制主浏览器 Cookie）。请在弹出的窗口登录 zhipin.com。")

        def task():
            writer = self._QueueWriter(self.log)
            with contextlib.redirect_stdout(writer), contextlib.redirect_stderr(writer):
                boss.run_setup_chrome(port, wait_login=False)
            self.log("Chrome 已启动。登录完成后请点“检查登录状态”。")

        self._run_in_thread(task, on_done=lambda: self.set_status("就绪"))

    def on_check_login(self):
        port = self.cdp_port.get()
        self.set_status("检查登录…")

        def task():
            try:
                result = boss.check_login_state(port)
            except Exception as e:  # noqa: BLE001
                self.log(f"[错误] 无法连接 Chrome CDP：{e}")
                self.log("请先点“启动 Chrome 并登录”。")
                return
            if result.status is boss.LoginProbeStatus.AVAILABLE:
                self.log("✅ 已登录，且接口返回明文薪资，可以开始抓取。")
            else:
                self.log(f"⚠️ {boss.describe_login_probe_result(result)}")

        self._run_in_thread(task, on_done=lambda: self.set_status("就绪"))

    def on_stop_chrome(self):
        def task():
            writer = self._QueueWriter(self.log)
            with contextlib.redirect_stdout(writer), contextlib.redirect_stderr(writer):
                boss.run_stop_chrome()
        self._run_in_thread(task)

    # --------------------------------------------------------
    # 公司 CSV
    # --------------------------------------------------------
    def on_choose_csv(self):
        path = filedialog.askopenfilename(
            title="选择公司清单 CSV",
            filetypes=[("CSV 文件", "*.csv"), ("所有文件", "*.*")],
        )
        if not path:
            return
        self.csv_path.set(path)
        try:
            self.companies = cs.load_company_csv(path)
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("读取失败", str(e))
            return
        enc = getattr(self.companies, "encoding", "utf-8-sig")
        self.comp_count.configure(text=f"已加载 {len(self.companies)} 家公司")
        self.log(f"已加载 {len(self.companies)} 家公司（编码识别为 {enc}）：{path}")
        if self.companies:
            self.log(f"示例：{self.companies[0]['ts_code']} {self.companies[0]['name']}")
        self._refresh_company_tree()

    def on_choose_outdir(self):
        d = filedialog.askdirectory(title="选择输出文件夹")
        if d:
            self.out_dir.set(d)

    def on_open_outdir(self):
        d = self.out_dir.get()
        os.makedirs(d, exist_ok=True)
        try:
            if sys.platform == "darwin":
                os.system(f'open "{d}"')
            elif os.name == "nt":
                os.startfile(d)  # type: ignore[attr-defined]
            else:
                os.system(f'xdg-open "{d}"')
        except Exception as e:  # noqa: BLE001
            self.log(f"无法打开文件夹：{e}")

    # --------------------------------------------------------
    # 抓取
    # --------------------------------------------------------
    def _collect_filters(self):
        filters = {}
        sal = dict(SALARY_CHOICES).get(self.salary_choice.get(), "")
        if sal:
            filters["salary"] = sal
        scale = dict(SCALE_CHOICES).get(self.scale_choice.get(), "")
        if scale:
            filters["scale"] = scale
        return filters

    def on_tushare_resolve(self):
        """用 Tushare 权威获取上市公司全称与统一社会信用代码，更新清单。"""
        if not self.companies:
            messagebox.showwarning("缺少公司清单", "请先选择公司 CSV 文件。")
            return
        token = self.ts_token.get().strip()
        if not token:
            messagebox.showwarning("缺少 token", "请先填入 Tushare token。")
            return
        self.set_status("Tushare 核对中…")
        self.log("开始用 Tushare 核对上市公司全称与统一社会信用代码…")

        def task():
            try:
                import tushare_resolver as tsr
                client = tsr.TushareClient(token)
                cache_path = os.path.join(self.out_dir.get() or boss.DEFAULT_RESULT_DIR,
                                          tsr.DEFAULT_CACHE_NAME)
                tsr.resolve_companies_tushare(self.companies, client, cache_path=cache_path,
                                              log=self.log, stop_flag=self._stop_event.is_set)
                self.root.after(0, self._refresh_company_tree)
            except Exception as e:  # noqa: BLE001
                self.log(f"[错误] Tushare 核对失败：{e}")

        self._run_in_thread(task, on_done=lambda: self.set_status("就绪"))

    def on_deepseek_resolve(self):
        """用 DeepSeek 核对上市公司全称，更新公司清单与预览。"""
        if not self.companies:
            messagebox.showwarning("缺少公司清单", "请先选择公司 CSV 文件。")
            return
        key = self.ds_key.get().strip()
        if not key:
            messagebox.showwarning("缺少 API Key", "请先填入 DeepSeek API Key。")
            return
        self.set_status("DeepSeek 核对中…")
        self.log("开始用 DeepSeek 核对上市公司全称…")

        def task():
            try:
                import deepseek_resolver as dsr
                client = dsr.DeepSeekClient(
                    key, base_url=self.ds_base.get().strip() or dsr.DEFAULT_BASE_URL,
                    model=self.ds_model.get().strip() or dsr.DEFAULT_MODEL,
                )
                cache_path = os.path.join(self.out_dir.get() or boss.DEFAULT_RESULT_DIR,
                                          dsr.DEFAULT_CACHE_NAME)
                dsr.resolve_companies(self.companies, client, cache_path=cache_path,
                                      log=self.log, stop_flag=self._stop_event.is_set)
                self.root.after(0, self._refresh_company_tree)
            except Exception as e:  # noqa: BLE001
                self.log(f"[错误] DeepSeek 核对失败：{e}")

        self._run_in_thread(task, on_done=lambda: self.set_status("就绪"))

    def _refresh_company_tree(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        for c in self.companies:
            mark = ""
            if c.get("is_listed") is True:
                mark = "✓上市 "
            elif "is_listed" in c:
                mark = "✗ "
            alias_show = "；".join(a for a in c.get("aliases", []))
            if c.get("official_name"):
                alias_show = f"[{c['official_name']}] " + alias_show
            if c.get("uscc_expected"):
                alias_show = f"USCC:{c['uscc_expected']} " + alias_show
            self.tree.insert("", "end", values=(c["ts_code"], mark + c["name"], alias_show))

    def on_diagnose(self):
        """对清单里第一家公司跑一次诊断：看搜索到底返回了哪些公司。"""
        if not self.companies:
            messagebox.showwarning("缺少公司清单", "请先选择公司 CSV 文件。")
            return
        company = self.companies[0]
        cities = cs._build_cities(self.city.get(), self.multi_city.get())
        filters = self._collect_filters()
        port = self.cdp_port.get()
        self.set_status("诊断中…")
        self.log(f"—— 诊断公司：{company['name']} ——")

        def task():
            cdp = None
            tid = None
            try:
                cdp = boss.CDPSession(port)
                tid, sid = boss.create_page_session(cdp)
                cdp.send("Page.navigate", {"url": "https://www.zhipin.com/"}, sid)
                import time as _t
                _t.sleep(3)
                cs.diagnose_company(cdp, sid, company, cities, filters, pages=2, log=self.log)
            except Exception as e:  # noqa: BLE001
                self.log(f"[错误] 诊断失败：{e}（请确认已启动 Chrome 并登录）")
            finally:
                if cdp is not None:
                    try:
                        if tid is not None:
                            cdp.send("Target.closeTarget", {"targetId": tid})
                    except Exception:  # noqa: BLE001
                        pass
                    try:
                        cdp.close()
                    except Exception:  # noqa: BLE001
                        pass

        self._run_in_thread(task, on_done=lambda: self.set_status("就绪"))

    def on_start(self):
        if not self.companies:
            messagebox.showwarning("缺少公司清单", "请先选择公司 CSV 文件。")
            return
        if self._worker and self._worker.is_alive():
            return

        max_jobs = self.max_jobs.get().strip()
        max_jobs = int(max_jobs) if max_jobs.isdigit() else None
        filters = self._collect_filters()
        out_dir = self.out_dir.get()
        os.makedirs(out_dir, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M")
        output_csv = os.path.join(out_dir, f"company_jobs_{stamp}.csv")
        output_json = os.path.join(out_dir, f"company_jobs_{stamp}.json")
        self._last_output_csv = output_csv

        self._stop_event.clear()
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.progress.configure(maximum=len(self.companies), value=0)
        self.set_status("抓取中…")

        params = dict(
            city_input=self.city.get(),
            pages_per_company=self.pages.get(),
            max_jobs_per_company=max_jobs,
            filters=filters,
            strict_brand=self.strict_brand.get(),
            fetch_jd=self.fetch_jd.get(),
            all_jobs=self.all_jobs.get(),
            multi_city=self.multi_city.get(),
            require_listed=self.require_listed.get(),
            verify_uscc=self.verify_uscc.get(),
            cdp_port=self.cdp_port.get(),
            output_csv=output_csv,
            output_json=output_json,
        )

        def progress_cb(done, total, jobs):
            self.root.after(0, lambda: self.progress.configure(value=done))
            self.root.after(0, lambda: self.set_status(f"公司 {done}/{total} · 岗位 {jobs}"))

        def task():
            cs.run_company_scrape(
                self.companies,
                log=self.log,
                stop_flag=self._stop_event.is_set,
                progress=progress_cb,
                **params,
            )
            self.log(f"输出 CSV：{output_csv}")

        self._worker = self._run_in_thread(task, on_done=self._on_scrape_done)

    def _on_scrape_done(self):
        self.start_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.set_status("完成")
        if self._last_output_csv and os.path.exists(self._last_output_csv):
            if messagebox.askyesno("完成", "抓取结束。是否打开输出文件夹？"):
                self.on_open_outdir()

    def on_stop(self):
        self._stop_event.set()
        self.log("已请求停止，将在当前岗位完成后退出（已抓数据已保存）。")
        self.set_status("停止中…")


def main():
    root = tk.Tk()
    # 尽量用系统主题
    try:
        style = ttk.Style()
        if sys.platform == "darwin" and "aqua" in style.theme_names():
            style.theme_use("aqua")
        elif "vista" in style.theme_names():
            style.theme_use("vista")
        elif "clam" in style.theme_names():
            style.theme_use("clam")
    except Exception:  # noqa: BLE001
        pass
    BossScraperGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
