#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
用 Tushare 的 stock_company 接口，按股票代码权威地获取：
  - com_name : 上市公司工商全称
  - com_id   : 统一社会信用代码(USCC)

比 DeepSeek 更准（直接来自官方登记数据），作为核对首选来源。
HTTP 直连 http://api.tushare.pro ，用 requests（项目已依赖），无需安装 tushare 包。

请求格式（POST JSON）:
  {"api_name":"stock_company","token":"...","params":{"exchange":"SSE"},
   "fields":"ts_code,com_name,com_id"}
返回:
  {"code":0,"msg":"","data":{"fields":[...],"items":[[...],...]}}

结果按 ts_code 缓存，重复运行零额外调用。请求构造/响应解析/回填等纯逻辑可离线单测。
"""

from __future__ import annotations

import os
import re
import time

# 复用 deepseek_resolver 的缓存读写，保持一致
try:
    from deepseek_resolver import load_cache, save_cache
except Exception:  # noqa: BLE001
    import json

    def load_cache(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def save_cache(path, cache):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)

DEFAULT_API_URL = "http://api.tushare.pro"
DEFAULT_CACHE_NAME = "tushare_company_cache.json"

# 交易所后缀 → Tushare exchange 代码
SUFFIX_EXCHANGE = {"SH": "SSE", "SZ": "SZSE", "BJ": "BSE"}


def exchange_of(ts_code):
    """从 ts_code（如 600036.SH）推断交易所代码（SSE/SZSE/BSE）。"""
    if not ts_code or "." not in ts_code:
        return ""
    suffix = ts_code.rsplit(".", 1)[-1].strip().upper()
    return SUFFIX_EXCHANGE.get(suffix, "")


def parse_tushare_payload(payload):
    """把 Tushare 返回的 {data:{fields,items}} 解析成 list[dict]。

    失败/无数据返回 []；接口报错（code!=0）抛 RuntimeError。
    """
    if not isinstance(payload, dict):
        return []
    code = payload.get("code")
    try:
        code_int = int(code)
    except (TypeError, ValueError):
        code_int = 0 if code is None else 1
    if code_int != 0:
        msg = payload.get("msg") or "(接口未返回原因)"
        raise RuntimeError(f"Tushare 接口错误(code={code}): {msg}")
    data = payload.get("data") or {}
    fields = data.get("fields") or []
    items = data.get("items") or []
    out = []
    for row in items:
        out.append({fields[i]: row[i] for i in range(min(len(fields), len(row)))})
    return out


def is_permission_error(err):
    """判断是否为积分/权限类错误（据此给用户明确提示、并触发降级）。"""
    s = str(err)
    return any(k in s for k in ["权限", "积分", "permission", "没有访问", "doc_id=108", "抱歉"])


def normalize_uscc(s):
    return re.sub(r"\s+", "", str(s or "")).upper()


class TushareClient:
    """极简 Tushare HTTP 客户端。"""

    def __init__(self, token, api_url=DEFAULT_API_URL, timeout=30):
        if not token or not str(token).strip():
            raise ValueError("缺少 Tushare token")
        self.token = str(token).strip()
        self.api_url = api_url or DEFAULT_API_URL
        self.timeout = timeout
        import requests
        self._requests = requests

    def query(self, api_name, params=None, fields=""):
        body = {
            "api_name": api_name,
            "token": self.token,
            "params": params or {},
            "fields": fields,
        }
        resp = self._requests.post(self.api_url, json=body, timeout=self.timeout)
        if resp.status_code != 200:
            raise RuntimeError(f"Tushare HTTP {resp.status_code}: {resp.text[:200]}")
        return parse_tushare_payload(resp.json())

    def stock_company(self, ts_code=None, exchange=None,
                      fields="ts_code,com_name,com_id"):
        params = {}
        if ts_code:
            params["ts_code"] = ts_code
        if exchange:
            params["exchange"] = exchange
        return self.query("stock_company", params=params, fields=fields)

    def stock_basic(self, list_status="L", fields="ts_code,name,fullname"):
        """低门槛接口，取公司全称(fullname) 作为降级来源（不含 USCC）。"""
        return self.query("stock_basic", params={"list_status": list_status}, fields=fields)


def _apply_record_to_company(company, rec):
    """把 Tushare 记录写回 company：official_name / uscc_expected / is_listed / 别名。

    CSV 里已填的 uscc_expected 优先级更高，不被覆盖。
    """
    com_name = str(rec.get("com_name") or "").strip()
    com_id = normalize_uscc(rec.get("com_id"))
    if com_name:
        company["official_name"] = com_name
        aliases = list(company.get("aliases", []))
        if com_name not in aliases and com_name != company.get("name"):
            aliases.append(com_name)
        company["aliases"] = aliases
    if com_id and not (company.get("uscc_expected") or "").strip():
        company["uscc_expected"] = com_id
    company["is_listed"] = True  # 能在 stock_company 查到即为上市主体
    return company


def resolve_companies_tushare(companies, client, cache_path=None, log=print,
                             stop_flag=None, sleep_between=0.3):
    """用 Tushare 给每家公司填全称与 USCC（带缓存），就地更新 companies。

    先按交易所批量拉取（少量请求），对仍缺失的再按 ts_code 单查兜底。
    Returns: 统计 dict {done, listed, from_cache, failed, not_found}
    """
    cache = load_cache(cache_path) if cache_path else {}
    stats = {"done": 0, "listed": 0, "from_cache": 0, "failed": 0, "not_found": 0}

    with_code = [c for c in companies if (c.get("ts_code") or "").strip()]
    missing = [c for c in with_code if c["ts_code"] not in cache]
    company_perm_ok = True
    hinted = False

    def _hint_once():
        nonlocal hinted
        if not hinted:
            hinted = True
            log("  ⚠️ stock_company 接口需要 Tushare 积分权限。请到 tushare.pro 完善资料/提升积分；"
                "本次将改用 stock_basic 仅补全「公司全称」（无统一社会信用代码，USCC 可由 CSV 手填或 BOSS 页面核验）。")

    # 1) 按交易所批量拉取 stock_company（全称 + USCC）
    exchanges = sorted({exchange_of(c["ts_code"]) for c in missing if exchange_of(c["ts_code"])})
    for ex in exchanges:
        if stop_flag is not None and stop_flag():
            log("Tushare 核对已中止。")
            break
        try:
            log(f"  拉取 {ex} 上市公司工商信息…")
            recs = client.stock_company(exchange=ex)
        except Exception as e:  # noqa: BLE001
            log(f"  [!] 拉取 {ex} 失败：{e}")
            stats["failed"] += 1
            if is_permission_error(e):
                company_perm_ok = False
                _hint_once()
            continue
        for r in recs:
            ts = (r.get("ts_code") or "").strip()
            if ts:
                cache[ts] = {"com_name": r.get("com_name", ""), "com_id": r.get("com_id", "")}
        if cache_path:
            save_cache(cache_path, cache)
        if sleep_between:
            time.sleep(sleep_between)

    # 2) stock_company 仍缺失的按单个 ts_code 兜底（有权限时才试）
    if company_perm_ok:
        for c in missing:
            ts = c["ts_code"]
            if ts in cache:
                continue
            if stop_flag is not None and stop_flag():
                break
            try:
                recs = client.stock_company(ts_code=ts)
            except Exception as e:  # noqa: BLE001
                if is_permission_error(e):
                    company_perm_ok = False
                    _hint_once()
                    break
                log(f"  [!] 查询 {ts} 失败：{e}")
                stats["failed"] += 1
                continue
            if recs:
                r = recs[0]
                cache[ts] = {"com_name": r.get("com_name", ""), "com_id": r.get("com_id", "")}
                if cache_path:
                    save_cache(cache_path, cache)
            if sleep_between:
                time.sleep(sleep_between)

    # 3) 降级：对仍拿不到全称的公司，用 stock_basic 补全称（无 USCC）
    still_missing = [c for c in with_code
                     if not (cache.get(c["ts_code"], {}).get("com_name"))]
    if still_missing and (stop_flag is None or not stop_flag()):
        try:
            log("  用 stock_basic 补全公司全称（降级方案）…")
            basics = client.stock_basic()
            bmap = {(r.get("ts_code") or "").strip(): r for r in basics}
            for c in still_missing:
                r = bmap.get(c["ts_code"])
                full = (r or {}).get("fullname") or (r or {}).get("name") or ""
                if full:
                    prev = cache.get(c["ts_code"], {})
                    cache[c["ts_code"]] = {"com_name": full, "com_id": prev.get("com_id", "")}
            if cache_path:
                save_cache(cache_path, cache)
        except Exception as e:  # noqa: BLE001
            log(f"  [!] stock_basic 降级也失败：{e}")

    # 4) 回填
    for c in companies:
        ts = (c.get("ts_code") or "").strip()
        rec = cache.get(ts)
        if not rec or not (rec.get("com_name") or rec.get("com_id")):
            if ts:
                stats["not_found"] += 1
            continue
        _apply_record_to_company(c, rec)
        stats["done"] += 1
        stats["listed"] += 1
        uscc_show = normalize_uscc(rec.get("com_id")) or "USCC空(需CSV/核验补)"
        log(f"  {c.get('name')} [{ts}] → {rec.get('com_name','(空)')}  {uscc_show}")

    log(f"Tushare 核对完成：成功 {stats['done']} 家，未找到 {stats['not_found']} 家，"
        f"失败请求 {stats['failed']} 次。")
    return stats
