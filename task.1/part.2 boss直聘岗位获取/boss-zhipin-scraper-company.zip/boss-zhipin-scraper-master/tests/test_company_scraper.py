#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""company_scraper 纯逻辑单元测试（无需网络 / Chrome）。"""

import os
import sys
import json
import pathlib
import tempfile
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

# 桩掉可选依赖，让 boss_cdp_raw 能被 company_scraper 导入
sys.modules.setdefault("websocket", mock.Mock())
sys.modules.setdefault("requests", mock.Mock())

import company_scraper as cs  # noqa: E402


class LoadCsvTests(unittest.TestCase):
    def _write(self, text, encoding="utf-8-sig"):
        f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False, encoding=encoding)
        f.write(text)
        f.close()
        return f.name

    def test_tab_delimited_and_dedup(self):
        path = self._write("ts_code\tname\n002657.SZ\t中科金财\n600036.SH\t招商银行\n002657.SZ\t中科金财\n")
        comps = cs.load_company_csv(path)
        self.assertEqual(len(comps), 2)
        self.assertEqual(comps[0]["ts_code"], "002657.SZ")
        self.assertEqual(comps[0]["name"], "中科金财")

    def test_comma_chinese_headers_with_aliases(self):
        path = self._write("股票代码,公司名称,品牌别名\n601099.SH,太平洋,太平洋证券;PACIFIC\n")
        comps = cs.load_company_csv(path)
        self.assertEqual(comps[0]["aliases"], ["太平洋证券", "PACIFIC"])

    def test_missing_name_column_raises(self):
        path = self._write("code,foo\n1,2\n")
        with self.assertRaises(ValueError):
            cs.load_company_csv(path)

    def _write_bytes(self, text, encoding):
        f = tempfile.NamedTemporaryFile("wb", suffix=".csv", delete=False)
        f.write(text.encode(encoding))
        f.close()
        return f.name

    def test_gbk_encoding(self):
        """Windows Excel 存的中文 CSV 常是 GBK，应能正确识别。"""
        text = "ts_code,name,别名\n002657.SZ,中科金财,\n601099.SH,太平洋,太平洋证券\n"
        comps = cs.load_company_csv(self._write_bytes(text, "gbk"))
        self.assertEqual([c["name"] for c in comps], ["中科金财", "太平洋"])
        self.assertEqual(comps[1]["aliases"], ["太平洋证券"])

    def test_gb2312_encoding(self):
        text = "ts_code,name\n600036.SH,招商银行\n"
        comps = cs.load_company_csv(self._write_bytes(text, "gb2312"))
        self.assertEqual(comps[0]["name"], "招商银行")

    def test_utf8_not_misdetected(self):
        """UTF-8 文件不能被误判成 GBK（否则中文会乱码）。"""
        text = "ts_code,name\n300663.SZ,科蓝软件\n"
        comps = cs.load_company_csv(self._write_bytes(text, "utf-8"))
        self.assertEqual(comps[0]["name"], "科蓝软件")

    def test_gbk_tab_delimited(self):
        text = "ts_code\tname\n300663.SZ\t科蓝软件\n"
        comps = cs.load_company_csv(self._write_bytes(text, "gbk"))
        self.assertEqual(comps[0]["name"], "科蓝软件")


class BrandMatchTests(unittest.TestCase):
    def test_bidirectional_contains(self):
        self.assertTrue(cs.brand_matches("招商银行股份有限公司", ["招商银行"]))
        self.assertTrue(cs.brand_matches("招商银行", ["招商银行股份有限公司"]))

    def test_alias_disambiguates(self):
        self.assertTrue(cs.brand_matches("太平洋保险", ["太平洋"]))          # 宽松会误伤
        self.assertFalse(cs.brand_matches("太平洋保险", ["太平洋证券"]))     # 用别名可区分

    def test_negative(self):
        self.assertFalse(cs.brand_matches("平安银行", ["招商银行"]))

    def test_strict(self):
        self.assertTrue(cs.brand_matches("招商银行股份有限公司", ["招商银行"], strict=True))
        self.assertFalse(cs.brand_matches("招商证券", ["招商银行"], strict=True))

    def test_loose_suffix_stripped(self):
        # 双向包含不成立，但剥后缀后一致，宽松模式应命中
        self.assertTrue(cs.brand_matches("中科金财科技股份有限公司", ["中科金财科技有限公司"]))


class CityBuildTests(unittest.TestCase):
    def test_single_nationwide(self):
        self.assertEqual(cs._build_cities("全国", multi_city=False),
                         [("全国", cs.NATIONWIDE_CITY_CODE)])

    def test_multi_city_expands(self):
        cities = cs._build_cities("全国", multi_city=True)
        self.assertGreater(len(cities), 5)
        names = [n for n, _ in cities]
        self.assertIn("北京", names)


class ExhaustivePagingTests(unittest.TestCase):
    def _run_collect(self, pages, exhaustive=True, max_pages=20):
        """pages: dict page->list[job]. 返回 collect 的命中列表与调用到的页码。"""
        called = []

        def fake_search(cdp, sid, name, city_code, page, filters, page_size=cs.PAGE_SIZE):
            called.append(page)
            return pages.get(page, [])

        company = {"ts_code": "x", "name": "赢时胜", "aliases": []}
        with mock.patch.object(cs, "search_company_page", fake_search), \
             mock.patch.object(cs, "time") as t:
            t.sleep = lambda *a, **k: None
            matched = cs.collect_company_jobs(
                mock.Mock(), "sid", company, [("上海", "101020100")], {},
                exhaustive=exhaustive, max_pages=max_pages, log=lambda m: None,
            )
        return matched, called

    def test_pages_until_short_page(self):
        full = [{"boss_name": "赢时胜信息技术", "job_link": f"j{p}_{i}", "encrypt_job_id": f"e{p}_{i}"}
                for p in range(3) for i in range(cs.PAGE_SIZE)]
        # page1、page2 各满 30 条，page3 只有 5 条（末页）
        pages = {
            1: [{"boss_name": "赢时胜信息技术", "encrypt_job_id": f"e1_{i}", "job_link": f"j1_{i}"} for i in range(cs.PAGE_SIZE)],
            2: [{"boss_name": "赢时胜信息技术", "encrypt_job_id": f"e2_{i}", "job_link": f"j2_{i}"} for i in range(cs.PAGE_SIZE)],
            3: [{"boss_name": "赢时胜信息技术", "encrypt_job_id": f"e3_{i}", "job_link": f"j3_{i}"} for i in range(5)],
        }
        matched, called = self._run_collect(pages)
        self.assertEqual(called, [1, 2, 3])           # 翻到末页才停
        self.assertEqual(len(matched), cs.PAGE_SIZE * 2 + 5)  # 全部命中

    def test_dedup_across_pages(self):
        job = {"boss_name": "赢时胜信息技术", "encrypt_job_id": "same", "job_link": "same"}
        pages = {1: [job], 2: [job]}  # page1 不足 30 → 直接停
        matched, called = self._run_collect(pages)
        self.assertEqual(called, [1])
        self.assertEqual(len(matched), 1)

    def test_empty_first_page_then_warmup_retry(self):
        """首页返回空，预热重试后拿到数据，应能正常抓到。"""
        calls = {"n": 0}

        def fake_search(cdp, sid, name, city_code, page, filters, page_size=cs.PAGE_SIZE):
            calls["n"] += 1
            # 第 1 次（page1 首试）空；第 2 次（预热后重试）返回 1 条命中
            if calls["n"] == 1:
                return []
            return [{"boss_name": "赢时胜信息技术", "encrypt_job_id": "e1", "job_link": "j1"}]

        with mock.patch.object(cs, "search_company_page", fake_search), \
             mock.patch.object(cs, "_warm_up_search", lambda *a, **k: None), \
             mock.patch.object(cs, "time") as t:
            t.sleep = lambda *a, **k: None
            matched = cs.collect_company_jobs(
                mock.Mock(), "sid", {"ts_code": "x", "name": "赢时胜", "aliases": []},
                [("上海", "101020100")], {}, log=lambda m: None,
            )
        self.assertEqual(len(matched), 1)      # 重试后成功拿到
        self.assertGreaterEqual(calls["n"], 2)  # page1 试了两次

    def test_diagnostics_when_no_match(self):
        logs = []
        pages = {1: [{"boss_name": "完全不相干公司", "encrypt_job_id": "e1", "job_link": "j1"}]}

        def fake_search(cdp, sid, name, city_code, page, filters, page_size=cs.PAGE_SIZE):
            return pages.get(page, [])

        with mock.patch.object(cs, "search_company_page", fake_search), \
             mock.patch.object(cs, "time") as t:
            t.sleep = lambda *a, **k: None
            matched = cs.collect_company_jobs(
                mock.Mock(), "sid", {"ts_code": "x", "name": "赢时胜", "aliases": []},
                [("上海", "101020100")], {}, log=logs.append,
            )
        self.assertEqual(matched, [])
        joined = "\n".join(logs)
        self.assertIn("完全不相干公司", joined)   # 诊断把实际返回的公司名打出来了


class RowBuildTests(unittest.TestCase):
    def test_split_experience_degree(self):
        self.assertEqual(cs._split_experience_degree("3-5年 | 本科"), ("3-5年", "本科"))
        self.assertEqual(cs._split_experience_degree("应届生"), ("应届生", ""))

    def test_merge_skills_dedup(self):
        self.assertEqual(cs._merge_skills("Java | MySQL", ["MySQL", "Redis"]), "Java | MySQL | Redis")

    def test_build_row_and_csv(self):
        job = {
            "title": "风控工程师", "salary": "20-40K", "location": "上海·浦东·陆家嘴",
            "boss_name": "招商银行股份有限公司", "company_scale": "10000人以上",
            "company_stage": "已上市", "company_industry": "银行", "tags": "3-5年 | 本科",
            "skills": "Java | 风控", "welfare": "五险一金 | 年终奖",
            "job_link": "https://www.zhipin.com/job_detail/abc.html",
            "company_link": "https://www.zhipin.com/gongsi/xyz.html", "salary_source": "api",
        }
        row = cs.build_company_row("600036.SH", "招商银行", job, jd_text="岗位描述全文", detail_tags=["Python"])
        self.assertEqual(row["ts_code"], "600036.SH")
        self.assertEqual(row["company_name"], "招商银行股份有限公司")
        self.assertEqual((row["experience"], row["degree"]), ("3-5年", "本科"))
        self.assertEqual(row["skills"], "Java | 风控 | Python")
        self.assertEqual(row["jd"], "岗位描述全文")

        out = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False)
        out.close()
        cs.write_company_csv(out.name, [row])
        data = open(out.name, encoding="utf-8-sig").read()
        self.assertTrue(data.startswith("ts_code"))
        self.assertIn("岗位描述全文", data)


class CityResolveTests(unittest.TestCase):
    def test_nationwide(self):
        _, code = cs.resolve_city_code("全国")
        self.assertEqual(code, cs.NATIONWIDE_CITY_CODE)
        _, code = cs.resolve_city_code("")
        self.assertEqual(code, cs.NATIONWIDE_CITY_CODE)


class PipelineTests(unittest.TestCase):
    def test_end_to_end_with_mocked_cdp(self):
        def fake_search(cdp, sid, name, city, page, filters, page_size=30):
            if name == "招商银行" and page == 1:
                return [
                    {"title": "风控工程师", "salary": "25-45K", "location": "上海·浦东·陆家嘴",
                     "boss_name": "招商银行股份有限公司", "company_scale": "10000人以上",
                     "company_stage": "已上市", "company_industry": "银行", "tags": "3-5年 | 本科",
                     "skills": "Java | 风控", "welfare": "五险一金", "salary_source": "api",
                     "job_link": "https://www.zhipin.com/job_detail/j1.html",
                     "company_link": "https://www.zhipin.com/gongsi/b1.html"},
                    {"title": "客户经理", "boss_name": "某某保险代理有限公司", "tags": "1-3年 | 大专",
                     "salary_source": "api", "job_link": "https://www.zhipin.com/job_detail/other.html"},
                ]
            return []

        with mock.patch.object(cs, "search_company_page", fake_search), \
             mock.patch.object(cs, "fetch_job_detail", lambda port, job, log=None: ("职位描述\n负责风控。" * 20, ["Python"])), \
             mock.patch.object(cs.boss, "CDPSession", lambda port: mock.Mock()), \
             mock.patch.object(cs.boss, "create_page_session", lambda cdp, background=True: ("tid", "sid")):
            out = tempfile.NamedTemporaryFile(suffix=".csv", delete=False)
            out.close()
            rows = cs.run_company_scrape(
                [{"ts_code": "600036.SH", "name": "招商银行", "aliases": []}],
                city_input="全国", pages_per_company=2, fetch_jd=True,
                output_csv=out.name, log=lambda m: None,
            )
        self.assertEqual(len(rows), 1)          # 只保留命中品牌的岗位
        self.assertEqual(rows[0]["company_name"], "招商银行股份有限公司")
        self.assertIn("职位描述", rows[0]["jd"])
        self.assertIn("Python", rows[0]["skills"])
        data = open(out.name, encoding="utf-8-sig").read()
        self.assertNotIn("某某保险", data)      # 非目标公司被过滤


class VerificationAndDispatchTests(unittest.TestCase):
    def test_uscc_extract_labelled(self):
        t = "工商信息 统一社会信用代码：91110108551385082Q 法定代表人 张三"
        self.assertEqual(cs.extract_uscc_from_text(t), "91110108551385082Q")

    def test_uscc_extract_fallback(self):
        self.assertEqual(cs.extract_uscc_from_text("注册号 91310000132200821H 成立"), "91310000132200821H")

    def test_uscc_extract_none(self):
        self.assertEqual(cs.extract_uscc_from_text("这里没有代码 123"), "")

    def test_verify_mismatch_flagged(self):
        _, uv, st = cs.compute_verify_status(
            "太平洋证券股份有限公司", "太平洋证券股份有限公司",
            "910000000000000012", "910000000000000099")
        self.assertEqual(uv, "不一致")
        self.assertIn("仿冒", st)

    def test_verify_pass(self):
        _, uv, st = cs.compute_verify_status(
            "太平洋证券股份有限公司", "太平洋证券股份有限公司",
            "910000000000000012", "910000000000000012")
        self.assertEqual(uv, "一致")
        self.assertIn("通过", st)

    def test_verify_name_mismatch_no_uscc(self):
        nv, uv, _ = cs.compute_verify_status(
            "山寨太平洋科技有限公司", "太平洋证券股份有限公司", "", "910000000000000012")
        self.assertEqual(nv, "不一致")
        self.assertEqual(uv, "页面无代码")

    def test_dispatch_by_brand(self):
        d, r = cs.detect_dispatch("某某人力资源有限公司", "负责客户对接", "客户经理", "")
        self.assertTrue(d)
        self.assertIn("人力资源", r)

    def test_dispatch_by_jd(self):
        d, r = cs.detect_dispatch("招商银行股份有限公司", "本岗位为劳务派遣制", "柜员", "")
        self.assertTrue(d)
        self.assertIn("劳务派遣", r)

    def test_not_dispatch(self):
        d, _ = cs.detect_dispatch("招商银行股份有限公司", "正式编制 五险一金", "风控", "")
        self.assertFalse(d)

    def test_csv_uscc_column(self):
        f = tempfile.NamedTemporaryFile("wb", suffix=".csv", delete=False)
        f.write("ts_code,name,统一社会信用代码\n601099.SH,太平洋,910000000000000012\n".encode("gbk"))
        f.close()
        comps = cs.load_company_csv(f.name)
        self.assertEqual(comps[0]["uscc_expected"], "910000000000000012")

    def test_build_row_verify_columns(self):
        job = {"title": "柜员", "boss_name": "山寨太平洋人力资源有限公司", "welfare": "", "salary_source": "api"}
        row = cs.build_company_row(
            "601099.SH", "太平洋", job, jd_text="本岗位为劳务派遣",
            official_name="太平洋证券股份有限公司",
            uscc_expected="910000000000000012", uscc_scraped="910000000000000099")
        self.assertEqual(row["uscc_verify"], "不一致")
        self.assertIn("仿冒", row["verify_status"])
        self.assertEqual(row["is_dispatch"], "是")


if __name__ == "__main__":
    unittest.main(verbosity=2)
