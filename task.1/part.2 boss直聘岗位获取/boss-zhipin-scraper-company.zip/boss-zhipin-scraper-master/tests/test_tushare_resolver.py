#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tushare_resolver 单元测试（无需真实网络）。"""

import sys
import pathlib
import tempfile
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.modules.setdefault("requests", mock.Mock())

import tushare_resolver as tsr  # noqa: E402


class ParsePayloadTests(unittest.TestCase):
    def test_parse_ok(self):
        payload = {"code": 0, "data": {"fields": ["ts_code", "com_name", "com_id"],
                                       "items": [["600036.SH", "招商银行股份有限公司", "911000001000078140"]]}}
        recs = tsr.parse_tushare_payload(payload)
        self.assertEqual(recs[0]["com_name"], "招商银行股份有限公司")
        self.assertEqual(recs[0]["com_id"], "911000001000078140")

    def test_error_raises(self):
        with self.assertRaises(RuntimeError):
            tsr.parse_tushare_payload({"code": 40001, "msg": "token无效"})

    def test_empty(self):
        self.assertEqual(tsr.parse_tushare_payload({"code": 0, "data": {}}), [])


class ExchangeTests(unittest.TestCase):
    def test_suffix_map(self):
        self.assertEqual(tsr.exchange_of("600036.SH"), "SSE")
        self.assertEqual(tsr.exchange_of("300663.SZ"), "SZSE")
        self.assertEqual(tsr.exchange_of("871981.BJ"), "BSE")
        self.assertEqual(tsr.exchange_of("badcode"), "")


class ClientTests(unittest.TestCase):
    def test_request_body_and_parse(self):
        class Resp:
            status_code = 200
            def json(self):
                return {"code": 0, "data": {"fields": ["ts_code", "com_name", "com_id"],
                                            "items": [["600036.SH", "招商银行股份有限公司", "911000001000078140"]]}}
        req = mock.Mock()
        req.post = mock.Mock(return_value=Resp())
        c = tsr.TushareClient("mytoken")
        c._requests = req
        recs = c.stock_company(exchange="SSE")
        self.assertEqual(recs[0]["com_id"], "911000001000078140")
        _, kwargs = req.post.call_args
        self.assertEqual(kwargs["json"]["api_name"], "stock_company")
        self.assertEqual(kwargs["json"]["token"], "mytoken")
        self.assertEqual(kwargs["json"]["params"]["exchange"], "SSE")

    def test_missing_token(self):
        with self.assertRaises(ValueError):
            tsr.TushareClient("")


class ResolveTests(unittest.TestCase):
    def _client(self):
        class Resp:
            status_code = 200
            def __init__(self, p): self._p = p
            def json(self): return self._p

        def post(url, json=None, timeout=None):
            ex = json["params"].get("exchange")
            if ex == "SSE":
                return Resp({"code": 0, "data": {"fields": ["ts_code", "com_name", "com_id"],
                            "items": [["600036.SH", "招商银行股份有限公司", "911000001000078140"]]}})
            return Resp({"code": 0, "data": {"fields": ["ts_code", "com_name", "com_id"],
                        "items": [["601099.SH", "太平洋证券股份有限公司", "91530000216685230K"]]}})
        req = mock.Mock()
        req.post = mock.Mock(side_effect=post)
        c = tsr.TushareClient("tok")
        c._requests = req
        return c

    def test_bulk_resolve_and_csv_precedence(self):
        cache = tempfile.NamedTemporaryFile(suffix=".json", delete=False)
        cache.close()
        comps = [
            {"ts_code": "600036.SH", "name": "招商银行", "aliases": []},
            {"ts_code": "601099.SH", "name": "太平洋", "aliases": ["太平洋证券"], "uscc_expected": "KEEPFROMCSV12345A"},
        ]
        stats = tsr.resolve_companies_tushare(comps, self._client(), cache_path=cache.name,
                                              log=lambda m: None, sleep_between=0)
        self.assertEqual(comps[0]["official_name"], "招商银行股份有限公司")
        self.assertEqual(comps[0]["uscc_expected"], "911000001000078140")
        self.assertTrue(comps[0]["is_listed"])
        self.assertIn("招商银行股份有限公司", comps[0]["aliases"])
        # CSV 已填的 USCC 不被覆盖
        self.assertEqual(comps[1]["uscc_expected"], "KEEPFROMCSV12345A")
        self.assertEqual(stats["done"], 2)

    def test_second_run_uses_cache(self):
        cache = tempfile.NamedTemporaryFile(suffix=".json", delete=False)
        cache.close()
        comps = [{"ts_code": "600036.SH", "name": "招商银行", "aliases": []}]
        client = self._client()
        tsr.resolve_companies_tushare(comps, client, cache_path=cache.name, log=lambda m: None, sleep_between=0)
        calls_after_first = client._requests.post.call_count
        # 第二次：缓存命中，不应再发请求
        comps2 = [{"ts_code": "600036.SH", "name": "招商银行", "aliases": []}]
        tsr.resolve_companies_tushare(comps2, client, cache_path=cache.name, log=lambda m: None, sleep_between=0)
        self.assertEqual(client._requests.post.call_count, calls_after_first)
        self.assertEqual(comps2[0]["uscc_expected"], "911000001000078140")


    def test_permission_error_falls_back_to_stock_basic(self):
        class Resp:
            status_code = 200
            def __init__(self, p): self._p = p
            def json(self): return self._p

        def post(url, json=None, timeout=None):
            api = json["api_name"]
            if api == "stock_company":
                return Resp({"code": 40203, "msg": "抱歉，您没有访问该接口的权限 doc_id=108"})
            if api == "stock_basic":
                return Resp({"code": 0, "data": {"fields": ["ts_code", "name", "fullname"],
                            "items": [["600036.SH", "招商银行", "招商银行股份有限公司"]]}})
            return Resp({"code": 0, "data": {"fields": [], "items": []}})

        req = mock.Mock()
        req.post = mock.Mock(side_effect=post)
        c = tsr.TushareClient("tok")
        c._requests = req
        cache = tempfile.NamedTemporaryFile(suffix=".json", delete=False)
        cache.close()
        comps = [{"ts_code": "600036.SH", "name": "招商银行", "aliases": []}]
        logs = []
        tsr.resolve_companies_tushare(comps, c, cache_path=cache.name, log=logs.append, sleep_between=0)
        self.assertEqual(comps[0]["official_name"], "招商银行股份有限公司")  # 降级取到全称
        self.assertEqual(comps[0].get("uscc_expected", ""), "")            # 降级无 USCC
        self.assertTrue(any(("积分" in x or "权限" in x) for x in logs))    # 有明确提示


if __name__ == "__main__":
    unittest.main(verbosity=2)
