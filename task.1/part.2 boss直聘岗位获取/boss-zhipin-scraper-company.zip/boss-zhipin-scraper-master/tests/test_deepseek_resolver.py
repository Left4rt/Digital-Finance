#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""deepseek_resolver 与「仅上市公司」逻辑的单元测试（无需真实网络）。"""

import os
import sys
import json
import pathlib
import tempfile
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.modules.setdefault("websocket", mock.Mock())
sys.modules.setdefault("requests", mock.Mock())

import deepseek_resolver as dsr  # noqa: E402
import company_scraper as cs      # noqa: E402


class ParseTests(unittest.TestCase):
    def test_plain_json(self):
        r = dsr.parse_response_content('{"full_name":"太平洋证券股份有限公司","is_listed":true}')
        self.assertEqual(r["full_name"], "太平洋证券股份有限公司")

    def test_code_fenced(self):
        r = dsr.parse_response_content('```json\n{"full_name":"X股份有限公司","is_listed":"是"}\n```')
        self.assertEqual(r["full_name"], "X股份有限公司")

    def test_surrounding_text(self):
        r = dsr.parse_response_content('好的：{"full_name":"Y公司","is_listed":false} 以上')
        self.assertEqual(r["full_name"], "Y公司")

    def test_garbage(self):
        self.assertEqual(dsr.parse_response_content("这不是json"), {})

    def test_normalize_is_listed_variants(self):
        self.assertTrue(dsr.normalize_resolution({"is_listed": "是"})["is_listed"])
        self.assertTrue(dsr.normalize_resolution({"is_listed": True})["is_listed"])
        self.assertFalse(dsr.normalize_resolution({"is_listed": "false"})["is_listed"])


class ClientTests(unittest.TestCase):
    def test_request_and_parse(self):
        class Resp:
            status_code = 200
            def json(self):
                return {"choices": [{"message": {"content": '{"full_name":"招商银行股份有限公司","is_listed":true}'}}]}
        req = mock.Mock()
        req.post = mock.Mock(return_value=Resp())
        c = dsr.DeepSeekClient("sk-abc")
        c._requests = req
        r = c.resolve_company("600036.SH", "招商银行")
        self.assertEqual(r["full_name"], "招商银行股份有限公司")
        self.assertTrue(r["is_listed"])
        _, kwargs = req.post.call_args
        self.assertEqual(kwargs["headers"]["Authorization"], "Bearer sk-abc")
        self.assertEqual(kwargs["json"]["model"], "deepseek-chat")

    def test_missing_key_raises(self):
        with self.assertRaises(ValueError):
            dsr.DeepSeekClient("")


class ResolveCompaniesTests(unittest.TestCase):
    class FakeClient:
        def resolve_company(self, ts, name):
            table = {
                "601099.SH": {"full_name": "太平洋证券股份有限公司", "is_listed": True, "short_name": "太平洋证券", "note": ""},
                "002657.SZ": {"full_name": "中科金财科技股份有限公司", "is_listed": True, "short_name": "中科金财", "note": ""},
            }
            return table.get(ts, {"full_name": "", "is_listed": False, "short_name": "", "note": ""})

    def test_resolve_apply_and_cache(self):
        comps = [
            {"ts_code": "601099.SH", "name": "太平洋", "aliases": ["太平洋证券"]},
            {"ts_code": "002657.SZ", "name": "中科金财", "aliases": []},
        ]
        cache = tempfile.NamedTemporaryFile(suffix=".json", delete=False)
        cache.close()
        stats = dsr.resolve_companies(comps, self.FakeClient(), cache_path=cache.name,
                                      log=lambda m: None, sleep_between=0)
        self.assertEqual(stats["listed"], 2)
        self.assertIn("太平洋证券股份有限公司", comps[0]["aliases"])
        self.assertEqual(comps[0]["official_name"], "太平洋证券股份有限公司")
        self.assertTrue(comps[0]["is_listed"])
        # 第二次全部命中缓存
        stats2 = dsr.resolve_companies(comps, self.FakeClient(), cache_path=cache.name,
                                       log=lambda m: None, sleep_between=0)
        self.assertEqual(stats2["from_cache"], 2)


class RequireListedTests(unittest.TestCase):
    def test_official_only_matching_precision(self):
        """require_listed 下只用上市全称匹配，避免同名非上市公司误入。"""
        def fake_search(cdp, sid, name, city_code, page, filters, page_size=cs.PAGE_SIZE):
            if page == 1:
                return [
                    {"boss_name": "太平洋证券股份有限公司", "encrypt_job_id": "e1", "job_link": "j1"},
                    {"boss_name": "中国太平洋保险(集团)股份有限公司", "encrypt_job_id": "e2", "job_link": "j2"},
                ]
            return []

        company = {"ts_code": "601099.SH", "name": "太平洋", "aliases": ["太平洋证券"],
                   "official_name": "太平洋证券股份有限公司", "is_listed": True}
        with mock.patch.object(cs, "search_company_page", fake_search), \
             mock.patch.object(cs, "_warm_up_search", lambda *a, **k: None), \
             mock.patch.object(cs, "time") as t:
            t.sleep = lambda *a, **k: None
            matched = cs.collect_company_jobs(
                mock.Mock(), "sid", company, [("上海", "101020100")], {},
                require_listed=True, log=lambda m: None,
            )
        self.assertEqual(len(matched), 1)
        self.assertEqual(matched[0]["boss_name"], "太平洋证券股份有限公司")

    def test_run_skips_non_listed(self):
        comps = [
            {"ts_code": "1", "name": "上市公司甲", "aliases": [], "official_name": "甲股份有限公司", "is_listed": True},
            {"ts_code": "2", "name": "非上市乙", "aliases": [], "official_name": "", "is_listed": False},
        ]

        def fake_search(cdp, sid, name, city_code, page, filters, page_size=cs.PAGE_SIZE):
            if name == "上市公司甲" and page == 1:
                return [{"boss_name": "甲股份有限公司", "encrypt_job_id": "e1", "job_link": "j1", "salary_source": "api", "title": "岗位"}]
            return []

        out = tempfile.NamedTemporaryFile(suffix=".csv", delete=False)
        out.close()
        with mock.patch.object(cs, "search_company_page", fake_search), \
             mock.patch.object(cs, "_warm_up_search", lambda *a, **k: None), \
             mock.patch.object(cs, "fetch_job_detail", lambda p, j, log=None: ("职位描述" * 40, [])), \
             mock.patch.object(cs.boss, "CDPSession", lambda port: mock.Mock()), \
             mock.patch.object(cs.boss, "create_page_session", lambda cdp, background=True: ("tid", "sid")), \
             mock.patch.object(cs, "time") as t:
            t.sleep = lambda *a, **k: None
            rows = cs.run_company_scrape(
                comps, city_input="全国", require_listed=True, fetch_jd=True,
                output_csv=out.name, log=lambda m: None,
            )
        # 只抓了上市公司甲，非上市乙被跳过
        self.assertEqual({r["query_name"] for r in rows}, {"上市公司甲"})
        self.assertEqual(rows[0]["is_listed"], "是")


if __name__ == "__main__":
    unittest.main(verbosity=2)
